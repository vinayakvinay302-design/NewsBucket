# NewsBucket

An AI-first, trust-transparent news platform — personalized feed, grounded
AI summaries, source-comparison clustering, real-time breaking news and
live sports, in 12+ languages.

This repository is organized as a monorepo covering every layer of the
product: mobile, web, admin, backend microservices, infrastructure, and
the full 16-phase engineering documentation set the codebase was built from.

## Repository Structure

```
newsbucket/
├── apps/
│   ├── mobile/        # Flutter app (iOS + Android)
│   ├── web/            # Next.js consumer web app
│   └── admin/           # Next.js admin/moderation dashboard
├── services/
│   ├── auth-service/     # Firebase token exchange, JWT issuance
│   ├── news-service/     # Article CRUD, feed reads, clustering
│   ├── ai-service/       # Summarization, Chat with News (RAG), ranking
│   ├── ingestion-service/# RSS/publisher ingestion, dedup, source verification
│   └── sports-service/   # Live scores, WebSocket fan-out, fantasy stats
├── packages/
│   └── design-tokens/   # Single source of truth for color/type/spacing tokens
├── database/
│   └── schema.sql        # Full production Postgres schema
├── infra/
│   ├── terraform/        # AWS infrastructure as code
│   └── k8s/               # Kubernetes manifests per service
├── .github/workflows/    # CI/CD pipelines
├── prototype/            # Zero-dependency runnable demo (see prototype/README.md)
└── docs/                  # Full 16-phase PRD, design system, and architecture docs
```

## Quick Start

**Run the zero-dependency prototype (works immediately, no installs):**
```bash
cd prototype
node server.js
# open http://localhost:8080
```

**Local full-stack development:**
```bash
docker compose up -d          # Postgres, Redis, Elasticsearch
cd services/news-service && npm install && npm run start:dev
cd apps/web && npm install && npm run dev
cd apps/mobile && flutter pub get && flutter run
```

## Documentation

Start with `docs/01-PRD.md` and `docs/02-UIUX-Design-System.md` — every
downstream technical decision in this repo traces back to a requirement or
persona defined there. The full phase index is in `docs/16-Documentation.md`.

## Status

The `prototype/` app is a real, running vertical slice. The `services/*` and
`apps/*` directories contain production-pattern scaffolding — real
architecture, real working code for the core flows (feed, article detail,
Chat with News, live scores, ingestion/dedup) — intended as the actual
foundation to build out the remaining endpoints/screens against, not a
finished, deployed system. See `docs/` for what's specified vs. what's
implemented here.

## License

See `LICENSE`.
