# Design Tokens

Single source of truth for color, typography, spacing, radius, breakpoints,
and motion — referenced by both `apps/mobile` (generated into Dart
`ThemeData`) and `apps/web`/`apps/admin` (generated into Tailwind config /
CSS variables), per docs/02-UIUX-Design-System.md Section 13.

Do not hardcode a color, spacing, or type value anywhere in the app code —
add it here first, then consume it via the generated theme/config.
