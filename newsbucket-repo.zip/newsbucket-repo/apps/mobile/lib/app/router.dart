import 'package:go_router/go_router.dart';
import '../features/feed/presentation/home_feed_screen.dart';

// Route table per docs/02-UIUX-Design-System.md Section 3 (Navigation
// Architecture) -- bottom tab bar destinations plus the article-detail
// full-screen push. Extend with the remaining 76 screens in
// docs/02-UIUX-Design-System.md Section 2 following this same pattern.
final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(path: '/', builder: (context, state) => const HomeFeedScreen()),
    // GoRoute(path: '/article/:id', builder: (context, state) => ArticleDetailScreen(id: state.pathParameters['id']!)),
    // GoRoute(path: '/discover', builder: ...),
    // GoRoute(path: '/sports', builder: ...),
    // GoRoute(path: '/bookmarks', builder: ...),
    // GoRoute(path: '/profile', builder: ...),
  ],
);
