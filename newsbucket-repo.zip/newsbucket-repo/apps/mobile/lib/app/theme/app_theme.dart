import 'package:flutter/material.dart';
import 'design_tokens.dart';

// Light / Dark ThemeData per docs/02-UIUX-Design-System.md Sections 4-6.
// A third `amoled()` ThemeData (true-black surfaces, hairline elevation
// borders per Section 4) is applied when the user selects AMOLED mode in
// Settings, switching ThemeMode manually rather than via system brightness.
class AppTheme {
  static ThemeData light() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      scaffoldBackgroundColor: DesignTokens.lightBackground,
      colorScheme: ColorScheme.fromSeed(
        seedColor: DesignTokens.brandPrimaryLight,
        brightness: Brightness.light,
        primary: DesignTokens.brandPrimaryLight,
        surface: DesignTokens.lightSurface,
      ),
      fontFamily: 'Inter',
      textTheme: _textTheme(DesignTokens.lightTextPrimary, DesignTokens.lightTextSecondary),
    );
  }

  static ThemeData dark() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: DesignTokens.darkBackground,
      colorScheme: ColorScheme.fromSeed(
        seedColor: DesignTokens.brandPrimaryDark,
        brightness: Brightness.dark,
        primary: DesignTokens.brandPrimaryDark,
        surface: DesignTokens.darkSurface,
      ),
      fontFamily: 'Inter',
      textTheme: _textTheme(DesignTokens.darkTextPrimary, DesignTokens.darkTextSecondary),
    );
  }

  static TextTheme _textTheme(Color primary, Color secondary) {
    return TextTheme(
      titleLarge: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: primary, height: 1.3),
      bodyMedium: TextStyle(fontSize: 15, color: secondary, height: 1.5),
      labelSmall: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.6, color: primary),
      labelMedium: TextStyle(fontSize: 12, color: secondary),
    );
  }
}
