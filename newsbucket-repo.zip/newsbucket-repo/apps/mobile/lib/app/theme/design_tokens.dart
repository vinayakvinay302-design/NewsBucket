import 'package:flutter/material.dart';

// Generated from packages/design-tokens/tokens.json -- per
// docs/02-UIUX-Design-System.md Section 13, do not hardcode a color or
// spacing value anywhere else in this app; edit the JSON source and
// regenerate this file instead.
class DesignTokens {
  // Light theme
  static const lightBackground = Color(0xFFFFFFFF);
  static const lightSurface = Color(0xFFF7F8FA);
  static const lightTextPrimary = Color(0xFF1A1D21);
  static const lightTextSecondary = Color(0xFF5B6470);
  static const lightBorder = Color(0xFFE7E9EC);

  // Dark theme
  static const darkBackground = Color(0xFF121316);
  static const darkSurface = Color(0xFF1B1D21);
  static const darkTextPrimary = Color(0xFFF2F3F5);
  static const darkTextSecondary = Color(0xFFA6ADB8);
  static const darkBorder = Color(0xFF2A2D32);

  // AMOLED theme
  static const amoledBackground = Color(0xFF000000);

  // Brand
  static const brandPrimaryLight = Color(0xFF1652F0);
  static const brandPrimaryDark = Color(0xFF5B8CFF);
  static const brandAccentLight = Color(0xFFFF6B35);
  static const brandAccentDark = Color(0xFFFF8659);

  // Semantic (trust)
  static const factualityHigh = Color(0xFF1B9E5B);
  static const factualityMedium = Color(0xFFE8A93A);
  static const factualityLow = Color(0xFFE5484D);

  static const spacingUnit = 4.0;
  static const radiusCard = 16.0;
}
