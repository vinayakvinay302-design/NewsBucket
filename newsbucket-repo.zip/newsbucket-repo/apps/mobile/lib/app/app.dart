import 'package:flutter/material.dart';
import 'router.dart';
import 'theme/app_theme.dart';

class NewsBucketApp extends StatelessWidget {
  const NewsBucketApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'NewsBucket',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.system,
      routerConfig: appRouter,
    );
  }
}
