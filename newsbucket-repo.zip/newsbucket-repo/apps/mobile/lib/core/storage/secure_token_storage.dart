import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Backs the JWT access/refresh token pair referenced by AuthInterceptor,
/// per docs/12-Security.md Section 1. Uses platform Keychain/Keystore via
/// flutter_secure_storage -- tokens are never written to SharedPreferences
/// or any unencrypted storage.
class SecureTokenStorage {
  final _storage = const FlutterSecureStorage();
  static const _accessKey = 'nb_access_token';
  static const _refreshKey = 'nb_refresh_token';

  Future<String?> readAccessToken() => _storage.read(key: _accessKey);
  Future<String?> readRefreshToken() => _storage.read(key: _refreshKey);

  Future<void> saveTokens({required String accessToken, required String refreshToken}) async {
    await _storage.write(key: _accessKey, value: accessToken);
    await _storage.write(key: _refreshKey, value: refreshToken);
  }

  Future<void> clearTokens() async {
    await _storage.delete(key: _accessKey);
    await _storage.delete(key: _refreshKey);
  }
}
