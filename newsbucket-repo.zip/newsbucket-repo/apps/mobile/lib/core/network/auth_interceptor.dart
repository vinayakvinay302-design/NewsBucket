// core/network/auth_interceptor.dart
import 'package:dio/dio.dart';
import '../storage/secure_token_storage.dart';

/// Attaches the current access token to every request, and transparently
/// refreshes + retries once on a 401 before surfacing the error upstream.
class AuthInterceptor extends Interceptor {
  final Dio _dio;
  final SecureTokenStorage _storage = SecureTokenStorage();
  bool _isRefreshing = false;

  AuthInterceptor(this._dio);

  @override
  Future<void> onRequest(RequestOptions options, RequestInterceptorHandler handler) async {
    final token = await _storage.readAccessToken();
    if (token != null) {
      options.headers['Authorization'] = 'Bearer $token';
    }
    handler.next(options);
  }

  @override
  Future<void> onError(DioException err, ErrorInterceptorHandler handler) async {
    final isAuthError = err.response?.statusCode == 401;
    final alreadyRetried = err.requestOptions.extra['retried'] == true;

    if (isAuthError && !alreadyRetried && !_isRefreshing) {
      _isRefreshing = true;
      try {
        final refreshToken = await _storage.readRefreshToken();
        if (refreshToken == null) {
          _isRefreshing = false;
          return handler.next(err);
        }
        final response = await _dio.post('/v1/auth/refresh',
            data: {'refresh_token': refreshToken});
        await _storage.saveTokens(
          accessToken: response.data['data']['access_token'],
          refreshToken: response.data['data']['refresh_token'],
        );
        final retryOptions = err.requestOptions;
        retryOptions.extra['retried'] = true;
        retryOptions.headers['Authorization'] =
            'Bearer ${response.data['data']['access_token']}';
        final retryResponse = await _dio.fetch(retryOptions);
        _isRefreshing = false;
        return handler.resolve(retryResponse);
      } catch (_) {
        _isRefreshing = false;
        await _storage.clearTokens();
        return handler.next(err); // caller routes to login screen
      }
    }
    handler.next(err);
  }
}
