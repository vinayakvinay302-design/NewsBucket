import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app/app.dart';
import 'core/network/api_client.dart';
import 'features/feed/application/feed_providers.dart';
import 'features/feed/data/repositories/feed_repository.dart';

void main() {
  // Firebase.initializeApp(), crash reporting, and other non-critical
  // startup work is deferred until after the first frame renders, per
  // docs/14-Performance.md Section 2 ("deferred initialization").
  final apiClient = ApiClient.create(baseUrl: const String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://api.newsbucket.com',
  ));

  runApp(
    ProviderScope(
      overrides: [
        feedRepositoryProvider.overrideWithValue(FeedRepository(apiClient)),
      ],
      child: const NewsBucketApp(),
    ),
  );
}
