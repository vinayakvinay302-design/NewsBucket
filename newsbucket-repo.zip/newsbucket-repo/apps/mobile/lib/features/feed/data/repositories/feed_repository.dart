// features/feed/data/repositories/feed_repository.dart
import '../../../../core/network/api_client.dart';
import '../models/article_model.dart';

class FeedPage {
  final List<ArticleSummary> articles;
  final String? nextCursor;
  FeedPage({required this.articles, required this.nextCursor});
}

class FeedRepository {
  final ApiClient _client;
  FeedRepository(this._client);

  Future<FeedPage> getHomeFeed({String? cursor}) async {
    final response = await _client.dio.get('/v1/feed/home',
        queryParameters: {if (cursor != null) 'cursor': cursor, 'limit': 20});
    final items = (response.data['data'] as List)
        .map((json) => ArticleSummary.fromJson(json as Map<String, dynamic>))
        .toList();
    return FeedPage(
      articles: items,
      nextCursor: response.data['meta']['next_cursor'] as String?,
    );
  }
}
