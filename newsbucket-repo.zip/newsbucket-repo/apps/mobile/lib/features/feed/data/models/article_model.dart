// features/feed/data/models/article_model.dart
class ArticleSummary {
  final String id;
  final String headline;
  final String? heroImageUrl;
  final String categorySlug;
  final String publisherName;
  final DateTime publishedAt;
  final double? factualityScore;
  final String? biasRating;
  final String oneLineSummary;

  ArticleSummary({
    required this.id,
    required this.headline,
    required this.categorySlug,
    required this.publisherName,
    required this.publishedAt,
    required this.oneLineSummary,
    this.heroImageUrl,
    this.factualityScore,
    this.biasRating,
  });

  factory ArticleSummary.fromJson(Map<String, dynamic> json) {
    return ArticleSummary(
      id: json['id'] as String,
      headline: json['headline'] as String,
      heroImageUrl: json['hero_image_url'] as String?,
      categorySlug: json['category_slug'] as String,
      publisherName: json['publisher_name'] as String,
      publishedAt: DateTime.parse(json['published_at'] as String),
      factualityScore: (json['factuality_score'] as num?)?.toDouble(),
      biasRating: json['bias_rating'] as String?,
      oneLineSummary: json['ai_summary']?['one_line'] as String? ?? '',
    );
  }
}
