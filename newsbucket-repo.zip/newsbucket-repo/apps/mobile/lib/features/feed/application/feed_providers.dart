// features/feed/application/feed_providers.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/repositories/feed_repository.dart';
import '../data/models/article_model.dart';

final feedRepositoryProvider = Provider<FeedRepository>((ref) {
  throw UnimplementedError('Overridden in ProviderScope at app bootstrap');
});

class FeedState {
  final List<ArticleSummary> articles;
  final String? nextCursor;
  final bool isLoadingMore;
  final bool isRefreshing;
  final String? errorMessage;

  const FeedState({
    this.articles = const [],
    this.nextCursor,
    this.isLoadingMore = false,
    this.isRefreshing = false,
    this.errorMessage,
  });

  FeedState copyWith({
    List<ArticleSummary>? articles,
    String? nextCursor,
    bool? isLoadingMore,
    bool? isRefreshing,
    String? errorMessage,
  }) {
    return FeedState(
      articles: articles ?? this.articles,
      nextCursor: nextCursor ?? this.nextCursor,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
      isRefreshing: isRefreshing ?? this.isRefreshing,
      errorMessage: errorMessage,
    );
  }
}

class HomeFeedNotifier extends StateNotifier<FeedState> {
  final FeedRepository _repository;
  bool _hasMore = true;

  HomeFeedNotifier(this._repository) : super(const FeedState()) {
    loadInitial();
  }

  Future<void> loadInitial() async {
    state = state.copyWith(isRefreshing: true, errorMessage: null);
    try {
      final page = await _repository.getHomeFeed();
      _hasMore = page.nextCursor != null;
      state = FeedState(
        articles: page.articles,
        nextCursor: page.nextCursor,
        isRefreshing: false,
      );
    } catch (e) {
      state = state.copyWith(isRefreshing: false, errorMessage: e.toString());
    }
  }

  Future<void> loadMore() async {
    if (!_hasMore || state.isLoadingMore) return;
    state = state.copyWith(isLoadingMore: true);
    try {
      final page = await _repository.getHomeFeed(cursor: state.nextCursor);
      _hasMore = page.nextCursor != null;
      state = state.copyWith(
        articles: [...state.articles, ...page.articles],
        nextCursor: page.nextCursor,
        isLoadingMore: false,
      );
    } catch (e) {
      state = state.copyWith(isLoadingMore: false, errorMessage: e.toString());
    }
  }
}

final homeFeedProvider =
    StateNotifierProvider<HomeFeedNotifier, FeedState>((ref) {
  return HomeFeedNotifier(ref.watch(feedRepositoryProvider));
});
