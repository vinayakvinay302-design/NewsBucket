// features/feed/presentation/home_feed_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../application/feed_providers.dart';
import 'widgets/article_card.dart';
import '../../../shared/widgets/skeleton_loader.dart';

class HomeFeedScreen extends ConsumerStatefulWidget {
  const HomeFeedScreen({super.key});

  @override
  ConsumerState<HomeFeedScreen> createState() => _HomeFeedScreenState();
}

class _HomeFeedScreenState extends ConsumerState<HomeFeedScreen> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (_scrollController.position.pixels >
        _scrollController.position.maxScrollExtent - 800) {
      ref.read(homeFeedProvider.notifier).loadMore();
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final feedState = ref.watch(homeFeedProvider);

    if (feedState.isRefreshing && feedState.articles.isEmpty) {
      return const SkeletonLoader(itemCount: 6);
    }

    if (feedState.errorMessage != null && feedState.articles.isEmpty) {
      return _ErrorState(
        onRetry: () => ref.read(homeFeedProvider.notifier).loadInitial(),
      );
    }

    return RefreshIndicator(
      onRefresh: () => ref.read(homeFeedProvider.notifier).loadInitial(),
      child: ListView.separated(
        controller: _scrollController,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        itemCount: feedState.articles.length + (feedState.isLoadingMore ? 1 : 0),
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          if (index >= feedState.articles.length) {
            return const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
            );
          }
          final article = feedState.articles[index];
          return ArticleCard(
            article: article,
            heroTag: 'article-hero-${article.id}',
            onTap: () => Navigator.of(context).pushNamed(
              '/article/${article.id}',
              arguments: {'heroTag': 'article-hero-${article.id}'},
            ),
          );
        },
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final VoidCallback onRetry;
  const _ErrorState({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off_rounded, size: 48),
          const SizedBox(height: 12),
          Text('Couldn\'t load your feed', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          FilledButton(onPressed: onRetry, child: const Text('Retry')),
        ],
      ),
    );
  }
}
