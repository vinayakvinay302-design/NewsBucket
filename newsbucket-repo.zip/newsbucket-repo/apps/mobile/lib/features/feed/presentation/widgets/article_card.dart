// features/feed/presentation/widgets/article_card.dart
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../data/models/article_model.dart';
import '../../../../shared/widgets/factuality_badge.dart';

class ArticleCard extends StatelessWidget {
  final ArticleSummary article;
  final String heroTag;
  final VoidCallback onTap;

  const ArticleCard({
    super.key,
    required this.article,
    required this.heroTag,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Semantics(
      button: true,
      label: '${article.headline}, from ${article.publisherName}',
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (article.heroImageUrl != null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Hero(
                    tag: heroTag,
                    child: AspectRatio(
                      aspectRatio: 16 / 9,
                      child: CachedNetworkImage(
                        imageUrl: article.heroImageUrl!,
                        fit: BoxFit.cover,
                        placeholder: (_, __) => Container(color: theme.colorScheme.surfaceVariant),
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              Text(
                article.categorySlug.toUpperCase(),
                style: theme.textTheme.labelSmall?.copyWith(
                  letterSpacing: 0.6,
                  color: theme.colorScheme.primary,
                ),
              ),
              const SizedBox(height: 4),
              Text(article.headline, style: theme.textTheme.titleLarge, maxLines: 3),
              const SizedBox(height: 6),
              Text(article.oneLineSummary,
                  style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant)),
              const SizedBox(height: 10),
              Row(
                children: [
                  Text(article.publisherName, style: theme.textTheme.labelMedium),
                  const SizedBox(width: 8),
                  Text('•', style: theme.textTheme.labelMedium),
                  const SizedBox(width: 8),
                  Text(_relativeTime(article.publishedAt), style: theme.textTheme.labelMedium),
                  const Spacer(),
                  if (article.factualityScore != null)
                    FactualityBadge(score: article.factualityScore!),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _relativeTime(DateTime time) {
    final diff = DateTime.now().difference(time);
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}
