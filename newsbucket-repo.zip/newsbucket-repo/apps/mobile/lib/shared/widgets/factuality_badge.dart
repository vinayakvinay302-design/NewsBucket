import 'package:flutter/material.dart';
import '../../app/theme/design_tokens.dart';

/// Factuality badge -- color always paired with an icon and numeric label,
/// never color alone, per the accessibility rule in
/// docs/02-UIUX-Design-System.md Section 9.
class FactualityBadge extends StatelessWidget {
  final double score;
  const FactualityBadge({super.key, required this.score});

  @override
  Widget build(BuildContext context) {
    final Color color = score >= 8.5
        ? DesignTokens.factualityHigh
        : score >= 6.5
            ? DesignTokens.factualityMedium
            : DesignTokens.factualityLow;
    final String label = score >= 8.5 ? 'High factuality' : score >= 6.5 ? 'Medium factuality' : 'Low factuality';

    return Semantics(
      label: '$label, $score out of 10',
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(999)),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.circle, size: 8, color: color),
            const SizedBox(width: 4),
            Text(score.toStringAsFixed(1), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: color)),
          ],
        ),
      ),
    );
  }
}
