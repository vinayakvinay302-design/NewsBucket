// test/features/feed/home_feed_screen_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:newsbucket/features/feed/presentation/home_feed_screen.dart';
import 'package:newsbucket/features/feed/application/feed_providers.dart';
import 'package:newsbucket/features/feed/data/repositories/feed_repository.dart';
import 'mocks/mock_feed_repository.dart';

void main() {
  testWidgets('shows skeleton loader while feed is refreshing with no cached articles',
      (tester) async {
    final mockRepo = MockFeedRepository()..willHang();

    await tester.pumpWidget(
      ProviderScope(
        overrides: [feedRepositoryProvider.overrideWithValue(mockRepo)],
        child: const MaterialApp(home: HomeFeedScreen()),
      ),
    );

    expect(find.byType(SkeletonLoader), findsOneWidget);
  });

  testWidgets('shows error state with retry button when initial load fails',
      (tester) async {
    final mockRepo = MockFeedRepository()..willFailWith('Network error');

    await tester.pumpWidget(
      ProviderScope(
        overrides: [feedRepositoryProvider.overrideWithValue(mockRepo)],
        child: const MaterialApp(home: HomeFeedScreen()),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text("Couldn't load your feed"), findsOneWidget);
    expect(find.widgetWithText(FilledButton, 'Retry'), findsOneWidget);
  });

  testWidgets('renders article cards once feed loads successfully', (tester) async {
    final mockRepo = MockFeedRepository()..willReturnSampleArticles(3);

    await tester.pumpWidget(
      ProviderScope(
        overrides: [feedRepositoryProvider.overrideWithValue(mockRepo)],
        child: const MaterialApp(home: HomeFeedScreen()),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.byType(ArticleCard), findsNWidgets(3));
  });
}
