// lib/api/articles.ts
import { cache } from 'react';

export interface AiSummary {
  oneLine: string;
  bullets: string[];
  eli5: string;
}

export interface Article {
  id: string;
  headline: string;
  bodyHtml: string;
  heroImageUrl?: string;
  clusterId: string;
  aiSummary: AiSummary;
  factualityScore?: number;
  biasRating?: string;
}

// react `cache()` dedupes this fetch across generateMetadata + the page render
export const fetchArticle = cache(async (id: string, lang: string): Promise<Article | null> => {
  const res = await fetch(`${process.env.NEWSBUCKET_API_URL}/v1/articles/${id}?lang=${lang}`, {
    next: { revalidate: 300 }, // 5-minute ISR, matches Phase 4 cache policy
  });
  if (res.status === 404) return null;
  if (!res.ok) throw new Error(`Failed to fetch article ${id}: ${res.status}`);
  const json = await res.json();
  return {
    id: json.data.id,
    headline: json.data.headline,
    bodyHtml: json.data.body_html,
    heroImageUrl: json.data.hero_image_url,
    clusterId: json.data.cluster_id,
    aiSummary: {
      oneLine: json.data.ai_summary.one_line,
      bullets: json.data.ai_summary.bullets,
      eli5: json.data.ai_summary.eli5,
    },
    factualityScore: json.data.factuality_score,
    biasRating: json.data.bias_rating,
  };
});
