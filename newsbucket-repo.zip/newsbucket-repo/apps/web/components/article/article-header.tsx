import type { Article } from '@/lib/api/articles';

// Referenced by app/[lang]/article/[id]/page.tsx per docs/07-App-Implementation.md.
// Renders headline, byline, publisher, and trust badges per the "Article
// Detail" spec in docs/02-UIUX-Design-System.md Section 12.
export function ArticleHeader({ article }: { article: Article }) {
  return (
    <header>
      <h1 className="text-2xl font-semibold leading-tight">{article.headline}</h1>
      <div className="mt-2 flex items-center gap-2 text-sm text-neutral-500">
        {article.factualityScore != null && (
          <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-emerald-700">
            ● {article.factualityScore.toFixed(1)}
          </span>
        )}
        {article.biasRating && <span>Bias: {article.biasRating.replace('_', ' ')}</span>}
      </div>
    </header>
  );
}
