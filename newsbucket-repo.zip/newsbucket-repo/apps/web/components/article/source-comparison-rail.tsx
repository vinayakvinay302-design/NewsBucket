// "Other outlets covering this" rail per docs/02-UIUX-Design-System.md
// Section 12 and docs/06-API-Documentation.md GET /v1/articles/:id/sources.
export async function SourceComparisonRail({ clusterId }: { clusterId: string | null }) {
  if (!clusterId) return null;
  return (
    <div className="mt-6">
      <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-brand-primary">
        Other outlets covering this
      </div>
      {/* Fetch sibling articles via lib/api/articles.ts and render source chips here. */}
    </div>
  );
}
