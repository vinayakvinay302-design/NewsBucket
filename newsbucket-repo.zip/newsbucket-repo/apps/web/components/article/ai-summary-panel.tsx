'use client';
import { useState } from 'react';
import type { AiSummary } from '@/lib/api/articles';

// Bullets / Full / ELI5 toggle per docs/02-UIUX-Design-System.md Section 12.
export function AiSummaryPanel({ summary }: { summary: AiSummary }) {
  const [mode, setMode] = useState<'bullets' | 'full' | 'eli5'>('bullets');
  return (
    <div className="my-4 rounded-2xl border border-neutral-200 p-4 dark:border-neutral-800">
      <div className="mb-3 flex gap-2 text-xs">
        {(['bullets', 'full', 'eli5'] as const).map((m) => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={`rounded-lg border px-3 py-1 ${mode === m ? 'bg-brand-primary text-white' : ''}`}
          >
            {m === 'eli5' ? 'ELI5' : m[0].toUpperCase() + m.slice(1)}
          </button>
        ))}
      </div>
      {mode === 'bullets' && (
        <ul className="list-disc space-y-1 pl-5 text-sm">
          {summary.bullets.map((b, i) => <li key={i}>{b}</li>)}
        </ul>
      )}
      {mode === 'full' && <p className="text-sm">{summary.oneLine}</p>}
      {mode === 'eli5' && <p className="text-sm">{summary.eli5}</p>}
    </div>
  );
}
