'use client';
import { useState } from 'react';

interface Citation { source_article_id: string; excerpt: string; }
interface ChatTurn { role: 'user' | 'assistant'; text: string; citations?: Citation[]; }

// Opens the Chat with News bottom sheet and calls
// POST /v1/articles/:id/chat per docs/06-API-Documentation.md Section 3,
// rendering the grounding/refusal contract from docs/08-AI-Features.md.
export function ChatWithNewsButton({ articleId }: { articleId: string }) {
  const [open, setOpen] = useState(false);
  const [turns, setTurns] = useState<ChatTurn[]>([]);
  const [input, setInput] = useState('');

  async function ask() {
    if (!input.trim()) return;
    const question = input;
    setTurns((t) => [...t, { role: 'user', text: question }]);
    setInput('');
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/v1/articles/${articleId}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question }),
    });
    const json = await res.json();
    setTurns((t) => [...t, { role: 'assistant', text: json.data.answer, citations: json.data.citations }]);
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-6 right-6 rounded-full bg-brand-primary px-4 py-2 text-sm font-semibold text-white shadow-lg"
      >
        💬 Chat with News
      </button>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40" onClick={() => setOpen(false)}>
          <div
            className="max-h-[80vh] w-full max-w-[720px] rounded-t-2xl bg-white p-4 dark:bg-neutral-900"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between">
              <strong>Chat with News</strong>
              <button onClick={() => setOpen(false)}>✕</button>
            </div>
            <div className="max-h-[50vh] overflow-y-auto text-sm">
              {turns.map((t, i) => (
                <p key={i} className={t.role === 'user' ? 'text-right text-brand-primary' : ''}>
                  {t.text}
                </p>
              ))}
            </div>
            <div className="mt-2 flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && ask()}
                className="flex-1 rounded-lg border px-3 py-2 text-sm"
                placeholder="Ask a question about this article…"
              />
              <button onClick={ask} className="rounded-lg bg-brand-primary px-4 py-2 text-sm text-white">Ask</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
