// app/[lang]/article/[id]/page.tsx
import { notFound } from 'next/navigation';
import { ArticleHeader } from '@/components/article/article-header';
import { AiSummaryPanel } from '@/components/article/ai-summary-panel';
import { ChatWithNewsButton } from '@/components/article/chat-with-news-button';
import { SourceComparisonRail } from '@/components/article/source-comparison-rail';
import { fetchArticle } from '@/lib/api/articles';

interface PageProps {
  params: { lang: string; id: string };
}

export async function generateMetadata({ params }: PageProps) {
  const article = await fetchArticle(params.id, params.lang);
  if (!article) return {};
  return {
    title: `${article.headline} | NewsBucket`,
    description: article.aiSummary.oneLine,
    openGraph: {
      images: article.heroImageUrl ? [article.heroImageUrl] : [],
    },
  };
}

export default async function ArticleDetailPage({ params }: PageProps) {
  const article = await fetchArticle(params.id, params.lang);
  if (!article) notFound();

  return (
    <article className="mx-auto max-w-[720px] px-4 py-6">
      <ArticleHeader article={article} />
      <AiSummaryPanel summary={article.aiSummary} />
      <div
        className="prose prose-neutral mt-6 dark:prose-invert"
        dangerouslySetInnerHTML={{ __html: article.bodyHtml }}
      />
      <ChatWithNewsButton articleId={article.id} />
      <SourceComparisonRail clusterId={article.clusterId} />
    </article>
  );
}
