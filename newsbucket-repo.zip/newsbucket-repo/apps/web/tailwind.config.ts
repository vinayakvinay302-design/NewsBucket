import type { Config } from 'tailwindcss';
import tokens from '../../packages/design-tokens/tokens.json';

// Tailwind config generated from the shared design-token source, per
// docs/02-UIUX-Design-System.md Section 13 -- do not hand-edit colors here,
// edit packages/design-tokens/tokens.json instead.
const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          primary: tokens.color.light.brandPrimary,
          accent: tokens.color.light.brandAccent,
        },
        surface: tokens.color.light.surface,
      },
      fontFamily: { sans: ['Inter', 'Noto Sans', 'sans-serif'] },
    },
  },
  plugins: [require('@tailwindcss/typography')],
};
export default config;
