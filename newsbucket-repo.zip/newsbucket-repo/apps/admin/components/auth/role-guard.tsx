// admin-app/components/auth/role-guard.tsx
'use client';

import { useSession } from '@/hooks/use-session';
import { redirect } from 'next/navigation';

interface RoleGuardProps {
  allowedRoles: string[];
  children: React.ReactNode;
}

// Client-side guard is UX-only (fast redirect); the actual security
// boundary is enforced server-side by every /v1/admin/* endpoint checking
// the JWT role claim independently, per Phase 6 auth requirements. This
// component must never be treated as the authorization mechanism itself.
export function RoleGuard({ allowedRoles, children }: RoleGuardProps) {
  const { user, isLoading } = useSession();

  if (isLoading) return null;
  if (!user || !allowedRoles.some((role) => user.roles.includes(role))) {
    redirect('/unauthorized');
  }
  return <>{children}</>;
}
