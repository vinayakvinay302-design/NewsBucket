'use client';
import { useState } from 'react';
import type { ModerationItem } from '@/hooks/use-moderation-queue';

export function ModerationItemRow({
  item,
  onResolve,
}: {
  item: ModerationItem;
  onResolve: (resolution: string, note: string) => Promise<void>;
}) {
  const [note, setNote] = useState('');
  return (
    <div className="flex items-center justify-between py-3 text-sm">
      <div>
        <div className="font-medium">{item.articleId}</div>
        <div className="text-neutral-500">{item.flagReason}</div>
      </div>
      <div className="flex gap-2">
        <input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Resolution note"
          className="rounded border px-2 py-1 text-xs"
        />
        <button onClick={() => onResolve('resolved_ok', note)} className="rounded bg-emerald-600 px-2 py-1 text-xs text-white">Approve</button>
        <button onClick={() => onResolve('resolved_corrected', note)} className="rounded bg-amber-500 px-2 py-1 text-xs text-white">Correct</button>
        <button onClick={() => onResolve('resolved_removed', note)} className="rounded bg-red-600 px-2 py-1 text-xs text-white">Remove</button>
      </div>
    </div>
  );
}
