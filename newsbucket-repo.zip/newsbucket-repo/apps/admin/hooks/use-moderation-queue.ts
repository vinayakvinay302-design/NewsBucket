'use client';
import { useCallback, useEffect, useState } from 'react';

export interface ModerationItem {
  id: string;
  articleId: string;
  flagReason: string;
  status: 'pending' | 'reviewing' | 'resolved_ok' | 'resolved_corrected' | 'resolved_removed';
  createdAt: string;
}

// Calls GET/POST /v1/admin/moderation/* per docs/06-API-Documentation.md
// Section 9 and docs/11-Admin-Dashboard.md Section 2.
export function useModerationQueue(status: 'pending' | 'reviewing') {
  const [items, setItems] = useState<ModerationItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const refetch = useCallback(async () => {
    setIsLoading(true);
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/v1/admin/moderation/queue?status=${status}`, {
      credentials: 'include',
    });
    const json = await res.json();
    setItems(json.data ?? []);
    setIsLoading(false);
  }, [status]);

  useEffect(() => { refetch(); }, [refetch]);

  async function resolveItem(id: string, resolution: string, note: string) {
    await fetch(`${process.env.NEXT_PUBLIC_API_URL}/v1/admin/moderation/${id}/resolve`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resolution, note }),
    });
  }

  return { items, isLoading, resolveItem, refetch };
}
