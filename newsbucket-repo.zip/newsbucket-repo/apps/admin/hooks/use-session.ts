'use client';
import { useEffect, useState } from 'react';

export interface SessionUser { id: string; roles: string[]; displayName: string; }

// Reads the admin session from the JWT issued by auth-service, per
// docs/12-Security.md Section 1 -- the role check here is UX-only; the
// real authorization boundary is each /v1/admin/* endpoint checking the
// JWT role claim independently, as documented in role-guard.tsx.
export function useSession() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch('/api/session')
      .then((r) => (r.ok ? r.json() : null))
      .then(setUser)
      .finally(() => setIsLoading(false));
  }, []);

  return { user, isLoading };
}
