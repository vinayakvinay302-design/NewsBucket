// admin-app/app/moderation/queue/page.tsx
'use client';

import { useState } from 'react';
import { useModerationQueue } from '@/hooks/use-moderation-queue';
import { ModerationItemRow } from '@/components/moderation/moderation-item-row';
import { RoleGuard } from '@/components/auth/role-guard';

export default function ModerationQueuePage() {
  const [statusFilter, setStatusFilter] = useState<'pending' | 'reviewing'>('pending');
  const { items, isLoading, resolveItem, refetch } = useModerationQueue(statusFilter);

  return (
    <RoleGuard allowedRoles={['admin', 'moderator']}>
      <div className="p-6">
        <h1 className="text-lg font-medium">Moderation queue</h1>
        <div className="mt-4 flex gap-2">
          {(['pending', 'reviewing'] as const).map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={statusFilter === status ? 'font-medium underline' : ''}
            >
              {status}
            </button>
          ))}
        </div>
        {isLoading ? (
          <div className="mt-6 text-sm text-neutral-500">Loading queue…</div>
        ) : (
          <div className="mt-6 divide-y">
            {items.map((item) => (
              <ModerationItemRow
                key={item.id}
                item={item}
                onResolve={async (resolution, note) => {
                  await resolveItem(item.id, resolution, note);
                  await refetch();
                }}
              />
            ))}
          </div>
        )}
      </div>
    </RoleGuard>
  );
}
