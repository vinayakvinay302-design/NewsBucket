import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

// Reads the admin JWT from an httpOnly cookie (set at admin login) and
// returns the decoded user/role claims to the client for UX-only display,
// per docs/12-Security.md Section 1 -- the actual authorization boundary
// is enforced server-side by every /v1/admin/* endpoint independently.
export async function GET() {
  const token = cookies().get('nb_admin_session')?.value;
  if (!token) return NextResponse.json(null, { status: 401 });

  // Production: verify + decode the JWT here (or call
  // GET /v1/auth/me on auth-service) rather than trusting the cookie blindly.
  return NextResponse.json({ id: 'placeholder', roles: ['moderator'], displayName: 'Moderator' });
}
