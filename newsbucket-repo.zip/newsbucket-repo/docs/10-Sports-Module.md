# NewsBucket — Phase 10: Sports Module
**Version 1.0 | Phase 10 of 16**
**Owner: Backend Architect (Sports Service)**

---

## 1. Data Providers & Coverage

- Cricket: ball-by-ball commercial sports-data API (live scores, IPL, international series) + wire-service match reports.
- Football: commercial sports-data API covering FIFA, UEFA Champions League, Premier League, and major domestic leagues.
- Basketball/American Football: NBA and NFL official/commercial statistics feeds.
- Motorsport: Formula 1 timing-data feed for live sessions and standings.
- Other: kabaddi (Pro Kabaddi League feed), chess (major tournament PGN/live-move feeds), tennis (ATP/WTA live scoring feed), esports (major tournament APIs per title).
- All third-party sports data normalized into one common internal schema (Section 2) so the mobile/web clients never need sport-specific parsing logic — one client-side data model across all sports.

## 2. Normalized Sports Data Model

```sql
CREATE TABLE sports_competitions (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sport         VARCHAR(30) NOT NULL,  -- cricket, football, nba, nfl, f1, kabaddi, chess, tennis
    name          VARCHAR(200) NOT NULL,
    season        VARCHAR(20),
    provider_ref  VARCHAR(100) NOT NULL, -- external provider's competition id
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sports_teams (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sport         VARCHAR(30) NOT NULL,
    name          VARCHAR(200) NOT NULL,
    short_name    VARCHAR(20),
    logo_url      TEXT,
    provider_ref  VARCHAR(100) NOT NULL
);

CREATE TABLE sports_players (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sport         VARCHAR(30) NOT NULL,
    team_id       UUID REFERENCES sports_teams(id),
    full_name     VARCHAR(200) NOT NULL,
    photo_url     TEXT,
    provider_ref  VARCHAR(100) NOT NULL,
    career_stats  JSONB NOT NULL DEFAULT '{}'
);

CREATE TABLE sports_matches (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sport            VARCHAR(30) NOT NULL,
    competition_id   UUID NOT NULL REFERENCES sports_competitions(id),
    home_team_id     UUID NOT NULL REFERENCES sports_teams(id),
    away_team_id     UUID NOT NULL REFERENCES sports_teams(id),
    status           VARCHAR(20) NOT NULL CHECK (status IN ('scheduled','live','completed','postponed','abandoned')),
    scheduled_at     TIMESTAMPTZ NOT NULL,
    venue            VARCHAR(200),
    current_state    JSONB NOT NULL DEFAULT '{}',  -- sport-specific live state, e.g. score/overs/innings
    provider_ref     VARCHAR(100) NOT NULL,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sports_matches_status ON sports_matches(sport, status, scheduled_at);
CREATE UNIQUE INDEX idx_sports_matches_provider_ref ON sports_matches(sport, provider_ref);

CREATE TABLE sports_standings (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    competition_id   UUID NOT NULL REFERENCES sports_competitions(id),
    team_id          UUID NOT NULL REFERENCES sports_teams(id),
    rank             INT NOT NULL,
    points           INT NOT NULL,
    stats            JSONB NOT NULL DEFAULT '{}',
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (competition_id, team_id)
);
```

- `current_state` and `career_stats` are intentionally JSONB — cricket's live state (overs, wickets, run rate) and F1's live state (lap, sector times, tyre stint) are structurally different, and normalizing them into rigid columns would force lossy compromises. The API layer defines a per-sport TypeScript discriminated union on top of this flexible storage, so clients get full type safety despite the flexible schema.

## 3. Live Score Ingestion & Fan-out Worker

```typescript
// sports-service/src/workers/live-score-poller.worker.ts
import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { SportsProviderClient } from '../providers/sports-provider.client';
import { MatchRepository } from '../matches/match.repository';
import { WebSocketGateway } from '../realtime/websocket.gateway';
import { EventPublisher } from '../events/event-publisher';

@Injectable()
export class LiveScorePoller {
  private readonly logger = new Logger(LiveScorePoller.name);

  constructor(
    private readonly provider: SportsProviderClient,
    private readonly matches: MatchRepository,
    private readonly gateway: WebSocketGateway,
    private readonly events: EventPublisher,
  ) {}

  // Runs every 5 seconds for matches currently marked 'live'; a separate,
  // much slower cron (60s) handles 'scheduled' matches to detect kickoff.
  @Cron('*/5 * * * * *')
  async pollLiveMatches(): Promise<void> {
    const liveMatches = await this.matches.findByStatus('live');
    if (liveMatches.length === 0) return;

    const updates = await this.provider.fetchLiveStates(liveMatches.map((m) => m.providerRef));

    for (const update of updates) {
      const match = liveMatches.find((m) => m.providerRef === update.providerRef);
      if (!match) continue;

      const hasChanged = JSON.stringify(match.currentState) !== JSON.stringify(update.state);
      if (!hasChanged) continue;

      await this.matches.updateState(match.id, update.state, update.status);

      // Push only the diff over WebSocket, not the full match object --
      // keeps the real-time payload small for the number-flash micro-
      // interaction defined in the Phase 2 design system to feel instant.
      this.gateway.broadcastToRoom(`match:${match.id}`, 'score_update', {
        matchId: match.id,
        state: update.state,
        status: update.status,
      });

      if (update.status === 'completed' && match.status !== 'completed') {
        await this.events.publish('sports.match.completed', { matchId: match.id });
      }
    }
  }
}
```

## 4. WebSocket Gateway (Multi-instance Fan-out via Redis Adapter)

```typescript
// sports-service/src/realtime/websocket.gateway.ts
import {
  WebSocketGateway as WsGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import { RedisClient } from '../cache/redis.client';

@WsGateway({ namespace: '/v1/ws/sports', cors: { origin: true } })
export class WebSocketGateway implements OnGatewayConnection {
  @WebSocketServer() server: Server;

  constructor(private readonly redis: RedisClient) {}

  afterInit(server: Server) {
    // Redis adapter is what makes this horizontally scalable: a client
    // connected to pod A receives a broadcast published from pod B, because
    // both pods share the same Redis pub/sub channel rather than only
    // being able to reach sockets held in their own process memory.
    const pubClient = this.redis.duplicate();
    const subClient = this.redis.duplicate();
    server.adapter(createAdapter(pubClient, subClient));
  }

  handleConnection(client: Socket) {
    const { matchId } = client.handshake.query;
    if (typeof matchId === 'string') {
      client.join(`match:${matchId}`);
    }
  }

  @SubscribeMessage('subscribe_match')
  handleSubscribe(client: Socket, matchId: string) {
    client.join(`match:${matchId}`);
  }

  broadcastToRoom(room: string, event: string, payload: unknown) {
    this.server.to(room).emit(event, payload);
  }
}
```

## 5. Fantasy Stats & Commentary

- Fantasy-relevant player stats (Phase 6: `GET /v1/sports/:sport/fantasy/:matchId`) are computed as a derived read model from `current_state`, refreshed on the same 5-second poll cycle, cached in Redis for 4 seconds to absorb read fan-out from many concurrent fantasy-app viewers during a single match.
- Ball-by-ball / play-by-play commentary is stored as an append-only `match_events` table (partitioned by match, TTL-archived after each season) and streamed to clients via the same WebSocket room, so scoreboard and commentary stay perfectly in sync without a separate polling path.

## 6. Push Notification Integration

- Users can follow specific teams/players (stored in a sports-follow table analogous to `user_interests`); the Notification Service (Phase 4) subscribes to `sports.match.completed` and score-milestone events (e.g., wicket, goal, touchdown) filtered against each user's follows before dispatching FCM push — never a blanket push to all users for every event, keeping notification relevance high and unsubscribe/opt-out rates low.

---

*Sports data feeds the same feed-ranking, search, and notification systems built in Phases 4–9. Proceeding to Phase 11 (Admin Dashboard).*
