# NewsBucket — Phase 5: Production Database Schema
**Version 1.0 | Phase 5 of 16**
**Owner: Database Architect**

---

## 1. Schema Design Principles

- Third normal form (3NF) for all transactional tables; denormalized read models live only in Redis/Elasticsearch, never in Postgres.
- Every table has `id UUID`, `created_at`, `updated_at`; mutable domain tables also carry `deleted_at` for soft deletes (never hard-delete user content — required for audit and moderation history).
- Every foreign key is indexed; every column used in a `WHERE`/`ORDER BY` on a hot path has a supporting index, verified via `EXPLAIN ANALYZE` in CI on a production-sized dataset snapshot.
- Partitioning by `created_at` (monthly range partitions) on high-volume tables: `articles`, `user_events`, `audit_logs`.
- Row-Level Security (RLS) enabled on all user-owned tables (`bookmarks`, `read_history`, `notification_preferences`) so application bugs can never leak one user's data to another at the query layer.

## 2. Core Schema (PostgreSQL DDL)

```sql
-- ============================================================
-- EXTENSIONS
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "pgcrypto";       -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "pg_trgm";        -- fuzzy text search fallback
CREATE EXTENSION IF NOT EXISTS "vector";         -- pgvector for embeddings

-- ============================================================
-- AUTH DOMAIN
-- ============================================================
CREATE TABLE users (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firebase_uid        VARCHAR(128) NOT NULL UNIQUE,
    phone_number        VARCHAR(20) UNIQUE,
    email               VARCHAR(255) UNIQUE,
    display_name        VARCHAR(100),
    avatar_url          TEXT,
    preferred_language  VARCHAR(10) NOT NULL DEFAULT 'en',
    country_code        VARCHAR(2) NOT NULL DEFAULT 'IN',
    subscription_tier    VARCHAR(20) NOT NULL DEFAULT 'free'
                         CHECK (subscription_tier IN ('free','premium','premium_annual')),
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at          TIMESTAMPTZ
);
CREATE UNIQUE INDEX idx_users_firebase_uid ON users(firebase_uid) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_subscription_tier ON users(subscription_tier) WHERE deleted_at IS NULL;

CREATE TABLE user_roles (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role        VARCHAR(30) NOT NULL CHECK (role IN ('user','moderator','admin','publisher_partner')),
    granted_by  UUID REFERENCES users(id),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (user_id, role)
);
CREATE INDEX idx_user_roles_user_id ON user_roles(user_id);

CREATE TABLE refresh_tokens (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash      VARCHAR(255) NOT NULL,
    device_id       VARCHAR(128),
    ip_address      INET,
    user_agent      TEXT,
    expires_at      TIMESTAMPTZ NOT NULL,
    revoked_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_refresh_tokens_user_id ON refresh_tokens(user_id) WHERE revoked_at IS NULL;
CREATE INDEX idx_refresh_tokens_expiry ON refresh_tokens(expires_at) WHERE revoked_at IS NULL;

-- ============================================================
-- NEWS DOMAIN
-- ============================================================
CREATE TABLE publishers (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name                 VARCHAR(200) NOT NULL,
    slug                 VARCHAR(200) NOT NULL UNIQUE,
    logo_url             TEXT,
    website_url          TEXT,
    trust_score          NUMERIC(4,2) CHECK (trust_score BETWEEN 0 AND 10),
    bias_rating          VARCHAR(20) CHECK (bias_rating IN ('left','lean_left','center','lean_right','right','unrated')),
    is_verified_partner  BOOLEAN NOT NULL DEFAULT FALSE,
    revenue_share_pct    NUMERIC(5,2) DEFAULT 0,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_publishers_trust_score ON publishers(trust_score);

CREATE TABLE categories (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug        VARCHAR(100) NOT NULL UNIQUE,
    parent_id   UUID REFERENCES categories(id),
    sort_order  INT NOT NULL DEFAULT 0
);

CREATE TABLE category_translations (
    category_id  UUID NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    language     VARCHAR(10) NOT NULL,
    label        VARCHAR(150) NOT NULL,
    PRIMARY KEY (category_id, language)
);

-- Partitioned by month on created_at
CREATE TABLE articles (
    id                  UUID NOT NULL DEFAULT gen_random_uuid(),
    publisher_id        UUID NOT NULL REFERENCES publishers(id),
    category_id         UUID NOT NULL REFERENCES categories(id),
    cluster_id          UUID,
    original_language   VARCHAR(10) NOT NULL,
    headline            TEXT NOT NULL,
    dek                 TEXT,
    body_html           TEXT NOT NULL,
    canonical_url       TEXT NOT NULL,
    hero_image_url      TEXT,
    author_name         VARCHAR(200),
    factuality_score    NUMERIC(4,2) CHECK (factuality_score BETWEEN 0 AND 10),
    is_breaking         BOOLEAN NOT NULL DEFAULT FALSE,
    status              VARCHAR(20) NOT NULL DEFAULT 'published'
                        CHECK (status IN ('draft','published','corrected','retracted','removed')),
    published_at        TIMESTAMPTZ NOT NULL,
    corrected_at        TIMESTAMPTZ,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at          TIMESTAMPTZ,
    PRIMARY KEY (id, created_at)
) PARTITION BY RANGE (created_at);

CREATE TABLE articles_2026_07 PARTITION OF articles
    FOR VALUES FROM ('2026-07-01') TO ('2026-08-01');
CREATE TABLE articles_2026_08 PARTITION OF articles
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');
-- additional monthly partitions created automatically via a scheduled
-- Kubernetes CronJob one month ahead of need (see Phase 15).

CREATE INDEX idx_articles_category_published ON articles(category_id, published_at DESC);
CREATE INDEX idx_articles_publisher ON articles(publisher_id);
CREATE INDEX idx_articles_cluster ON articles(cluster_id);
CREATE INDEX idx_articles_breaking ON articles(is_breaking, published_at DESC) WHERE is_breaking = TRUE;
CREATE UNIQUE INDEX idx_articles_canonical_url ON articles(canonical_url, created_at);

CREATE TABLE article_clusters (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    representative_article_id UUID,
    topic_label    TEXT,
    source_count   INT NOT NULL DEFAULT 1,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE article_ai_metadata (
    article_id          UUID PRIMARY KEY,
    article_created_at  TIMESTAMPTZ NOT NULL,
    summary_one_line     TEXT,
    summary_bullets      JSONB,
    summary_eli5         TEXT,
    entities             JSONB,
    bias_rating          VARCHAR(20),
    bias_confidence      NUMERIC(4,2),
    fake_news_confidence NUMERIC(4,2),
    embedding             vector(1536),
    model_version         VARCHAR(50) NOT NULL,
    generated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    FOREIGN KEY (article_id, article_created_at) REFERENCES articles(id, created_at)
);
CREATE INDEX idx_article_ai_embedding ON article_ai_metadata USING ivfflat (embedding vector_cosine_ops);

CREATE TABLE article_corrections (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    article_id    UUID NOT NULL,
    article_created_at TIMESTAMPTZ NOT NULL,
    correction_text TEXT NOT NULL,
    corrected_by  UUID REFERENCES users(id),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    FOREIGN KEY (article_id, article_created_at) REFERENCES articles(id, created_at)
);

-- ============================================================
-- USER PERSONALIZATION DOMAIN (Row-Level Security enabled)
-- ============================================================
CREATE TABLE user_interests (
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    category_id  UUID NOT NULL REFERENCES categories(id),
    weight       NUMERIC(4,3) NOT NULL DEFAULT 1.0,
    source       VARCHAR(20) NOT NULL DEFAULT 'explicit' CHECK (source IN ('explicit','implicit')),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, category_id)
);
ALTER TABLE user_interests ENABLE ROW LEVEL SECURITY;
CREATE POLICY user_interests_owner_policy ON user_interests
    USING (user_id = current_setting('app.current_user_id')::uuid);

CREATE TABLE bookmarks (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    article_id   UUID NOT NULL,
    article_created_at TIMESTAMPTZ NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (user_id, article_id)
);
ALTER TABLE bookmarks ENABLE ROW LEVEL SECURITY;
CREATE POLICY bookmarks_owner_policy ON bookmarks
    USING (user_id = current_setting('app.current_user_id')::uuid);
CREATE INDEX idx_bookmarks_user ON bookmarks(user_id, created_at DESC);

CREATE TABLE read_history (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    article_id   UUID NOT NULL,
    article_created_at TIMESTAMPTZ NOT NULL,
    dwell_seconds INT,
    read_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE read_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY read_history_owner_policy ON read_history
    USING (user_id = current_setting('app.current_user_id')::uuid);
CREATE INDEX idx_read_history_user ON read_history(user_id, read_at DESC);

CREATE TABLE notification_preferences (
    user_id            UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    breaking_news      BOOLEAN NOT NULL DEFAULT TRUE,
    category_alerts    JSONB NOT NULL DEFAULT '{}',
    quiet_hours_start  TIME,
    quiet_hours_end    TIME,
    daily_briefing_time TIME,
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE notification_preferences ENABLE ROW LEVEL SECURITY;
CREATE POLICY notif_prefs_owner_policy ON notification_preferences
    USING (user_id = current_setting('app.current_user_id')::uuid);

-- ============================================================
-- SUBSCRIPTIONS / BILLING DOMAIN
-- ============================================================
CREATE TABLE subscriptions (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id           UUID NOT NULL REFERENCES users(id),
    plan              VARCHAR(20) NOT NULL CHECK (plan IN ('premium_monthly','premium_annual')),
    status            VARCHAR(20) NOT NULL CHECK (status IN ('active','cancelled','past_due','expired')),
    provider          VARCHAR(20) NOT NULL CHECK (provider IN ('play_store','app_store','stripe')),
    provider_txn_id   VARCHAR(255) NOT NULL,
    current_period_start TIMESTAMPTZ NOT NULL,
    current_period_end   TIMESTAMPTZ NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_subscriptions_user ON subscriptions(user_id, status);
CREATE UNIQUE INDEX idx_subscriptions_provider_txn ON subscriptions(provider, provider_txn_id);

-- ============================================================
-- AUDIT & COMPLIANCE DOMAIN
-- ============================================================
CREATE TABLE audit_logs (
    id            BIGSERIAL,
    actor_user_id UUID,
    actor_role    VARCHAR(30),
    action        VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    resource_id   UUID,
    before_state  JSONB,
    after_state   JSONB,
    ip_address    INET,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
) PARTITION BY RANGE (created_at);

CREATE TABLE audit_logs_2026_07 PARTITION OF audit_logs
    FOR VALUES FROM ('2026-07-01') TO ('2026-08-01');
CREATE INDEX idx_audit_logs_actor ON audit_logs(actor_user_id, created_at DESC);
CREATE INDEX idx_audit_logs_resource ON audit_logs(resource_type, resource_id);

CREATE TABLE moderation_queue (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    article_id      UUID NOT NULL,
    article_created_at TIMESTAMPTZ NOT NULL,
    flag_reason     VARCHAR(50) NOT NULL CHECK (flag_reason IN
                     ('fake_news_ml','user_report','bias_review','copyright','other')),
    flag_source     VARCHAR(50),
    status          VARCHAR(20) NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','reviewing','resolved_ok','resolved_corrected','resolved_removed')),
    assigned_to     UUID REFERENCES users(id),
    resolved_at     TIMESTAMPTZ,
    resolution_note TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_moderation_queue_status ON moderation_queue(status, created_at);

-- ============================================================
-- ANALYTICS DOMAIN (high-volume, partitioned, short retention path to warehouse)
-- ============================================================
CREATE TABLE user_events (
    id            BIGSERIAL,
    user_id       UUID,
    session_id    UUID NOT NULL,
    event_type    VARCHAR(50) NOT NULL,
    event_payload JSONB,
    platform      VARCHAR(20),
    app_version   VARCHAR(20),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
) PARTITION BY RANGE (created_at);

CREATE TABLE user_events_2026_07 PARTITION OF user_events
    FOR VALUES FROM ('2026-07-01') TO ('2026-08-01');
CREATE INDEX idx_user_events_user_time ON user_events(user_id, created_at DESC);
CREATE INDEX idx_user_events_type_time ON user_events(event_type, created_at DESC);
```

## 3. Retention & Lifecycle Policies

- `user_events` and `audit_logs` partitions older than 13 months (analytics) / 7 years (audit) are detached and archived to S3 Glacier via a scheduled job, then dropped from Postgres — keeps hot-path tables small and fast.
- `articles` partitions are never dropped, only moved to a cheaper storage tier (Aurora I/O-Optimized → standard) after 12 months, since historical articles remain readable/searchable indefinitely (supports the "trust and correction history" requirement).
- Soft-deleted rows (`deleted_at IS NOT NULL`) are excluded from all application queries via a mandatory view layer (`v_articles_active`, `v_users_active`) that the NestJS repositories query against, never the raw table — prevents accidental resurrection of deleted content in feeds/search.

## 4. Read/Write Routing

- All `INSERT`/`UPDATE`/`DELETE` statements route to the Aurora primary instance.
- Feed, search-support, and analytics read queries route to Aurora read replicas via a read/write-splitting connection pool (PgBouncer in transaction mode) sitting in front of each service's database connections.
- Replica lag is monitored; if lag exceeds 500ms, the Recommendation Service temporarily falls back to reading from primary for that request to avoid serving stale personalization data.

---

*This schema is the foundation for Phase 6 (REST API Documentation). Proceeding to Phase 6.*
