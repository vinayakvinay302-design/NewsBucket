# NewsBucket — Phase 12: Security
**Version 1.0 | Phase 12 of 16**
**Owner: Security Engineer**

---

## 1. Authentication & Authorization

- Firebase Auth handles credential storage, OTP delivery, and abuse detection (leaked-password checks, rate-limited OTP attempts) — NewsBucket never stores raw passwords or OTP codes.
- NestJS backend issues short-lived (15 min) JWT access tokens signed with RS256 (asymmetric — the public key is distributed to services for verification, the private signing key never leaves the Authentication Service).
- Refresh tokens (30-day TTL) are single-use and rotated on every refresh; reuse of an already-rotated refresh token immediately revokes the entire token family for that device, since reuse is a strong signal of token theft.
- Role-based access control enforced server-side on every request via a NestJS `@Roles()` guard — client-side role checks (e.g., the Admin Dashboard `RoleGuard`) are UX-only, never the actual security boundary.
- Admin-role accounts require hardware-key (WebAuthn/FIDO2) 2FA; standard user accounts support OTP or app-based 2FA optionally.

## 2. Data Protection

- Encryption at rest: AWS RDS/Aurora, ElastiCache, and S3 all use AES-256 encryption with AWS KMS-managed keys; a separate KMS key per environment (prod/staging/dev) so a staging key compromise cannot affect production data.
- Encryption in transit: TLS 1.3 enforced at the ALB/CloudFront layer; internal service-to-service traffic within the EKS cluster uses mTLS via a service mesh (Istio/Linkerd) so a compromised pod cannot silently sniff plaintext internal traffic.
- PII minimization: phone numbers and emails are the only direct identifiers stored; analytics events (Phase 5 `user_events`) reference `user_id` (UUID) only, never phone/email directly, so the analytics pipeline can be handed to a data team with reduced PII exposure.
- Field-level encryption for especially sensitive fields (e.g., payment provider transaction identifiers) using envelope encryption via KMS, in addition to at-rest disk encryption.

## 3. OWASP Top 10 Mitigations (Applied Specifically)

| Risk | Mitigation |
|---|---|
| Injection (SQLi) | Parameterized queries exclusively via the ORM (Prisma/TypeORM); no raw string-concatenated SQL anywhere in the codebase, enforced by a lint rule and code-review checklist item. |
| Broken authentication | Firebase Auth + rotated refresh tokens (Section 1); brute-force lockout on repeated failed verification attempts. |
| Sensitive data exposure | Encryption per Section 2; API responses never include internal IDs, provider transaction secrets, or other users' data — enforced by response DTOs that explicitly allow-list fields, never a raw entity serialization. |
| XML External Entities (XXE) | No XML parsing of untrusted input anywhere in the ingestion pipeline; RSS feeds parsed with an XXE-hardened parser configuration (external entity resolution disabled). |
| Broken access control | Server-side RBAC (Section 1) plus Postgres Row-Level Security (Phase 5) as a second, independent enforcement layer — even a bug in application-layer authorization cannot leak another user's bookmarks/history, because the database itself refuses the query. |
| Security misconfiguration | Infrastructure defined entirely via Terraform (Phase 15) and code-reviewed; no manual console changes permitted in production; automated configuration drift detection. |
| Cross-Site Scripting (XSS) | All user-generated content (comments/reports, if introduced later) is sanitized server-side before storage AND output-encoded client-side; article body HTML from publishers passes through a strict allow-list sanitizer (Phase 9) before ever being rendered. |
| Insecure deserialization | All API payloads validated against strict DTO schemas (`class-validator` in NestJS) before any processing; unknown/extra fields rejected, not silently ignored. |
| Using components with known vulnerabilities | Automated dependency scanning (Dependabot/Snyk) in CI, blocking merges on critical/high CVEs; scheduled monthly dependency-freshness review. |
| Insufficient logging & monitoring | Every auth event, admin action, and moderation decision is logged to the immutable `audit_logs` table (Phase 5) plus structured logs to Loki; Alertmanager rules page on anomalous patterns (e.g., spike in failed logins from a single IP). |

## 4. API & Network Security

- AWS WAF in front of the API Gateway with managed rule sets for SQLi/XSS patterns, plus custom rate-based rules to catch credential-stuffing and scraping attempts.
- CSRF protection on the Admin Dashboard (cookie-based session component) via double-submit CSRF tokens; the mobile/consumer-web API is header-token-based (JWT in Authorization header, not cookies) and therefore not CSRF-exposed by design.
- Rate limiting per Phase 4 Section 5, with a stricter, separate limit tier specifically for authentication endpoints to blunt credential-stuffing/OTP-abuse attempts.
- Network segmentation: public-facing services in public subnets behind the ALB only; databases, caches, and internal services live in private subnets with no direct internet route, reachable only via the internal service mesh.

## 5. Secrets Management

- All secrets (database credentials, API keys for third-party providers, KMS-wrapped signing keys) live in AWS Secrets Manager, synced into Kubernetes via the External Secrets Operator — never in environment variables committed to source control or baked into container images.
- Automatic secret rotation configured for database credentials (30-day rotation) and third-party API keys where the provider supports it.
- CI/CD pipeline secrets (deployment credentials) are scoped per-environment with least-privilege IAM roles, and GitHub Actions uses OIDC federation to assume AWS roles rather than long-lived static AWS access keys.

## 6. Backups & Disaster Recovery

- Aurora PostgreSQL: automated daily snapshots plus continuous point-in-time recovery (5-minute RPO), retained 35 days, cross-region replicated for disaster recovery.
- S3: versioning enabled on all buckets containing user-generated or billing-relevant content, with MFA-delete required on the production bucket to prevent accidental or malicious bulk deletion.
- Quarterly disaster-recovery drills: full failover to the secondary region executed against a staging replica of production traffic, with RTO/RPO measured and reported, not just assumed.

## 7. Compliance

- India DPDP Act: data residency in `ap-south-1`, documented data-processing register, user-facing consent flows for data collection, and a functioning right-to-erasure pipeline (cascading soft-delete → scheduled hard-delete after the legally required retention window).
- GDPR (for EU/NRI users, per Persona 4): equivalent consent, access, and erasure rights extended globally rather than geo-fenced only to EU users, since maintaining two different privacy postures is both operationally complex and a poor trust signal.
- IT Rules 2021 (India intermediary rules): defined grievance-redressal officer, published takedown-request SLA, and a transparency report published per the roadmap in Phase 1.
- Annual third-party penetration test and OWASP ASVS Level 2 audit, with findings tracked to remediation in the same sprint-planning system as regular engineering work — not a separate, ignored spreadsheet.

---

*Security controls from this phase are validated by the test suite defined in Phase 13. Proceeding to Phase 13.*
