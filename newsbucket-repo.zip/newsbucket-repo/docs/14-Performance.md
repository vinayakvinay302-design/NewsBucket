# NewsBucket — Phase 14: Performance Optimization
**Version 1.0 | Phase 14 of 16**
**Owner: Performance Engineer**

---

## 1. The Sub-1-Second Budget

Time-to-interactive is broken into an explicit budget, so "under 1 second" is engineered, not hoped for:

| Stage | Budget | Technique |
|---|---|---|
| DNS + TLS handshake | 80ms | CloudFront edge termination, HTTP/3 (QUIC) where supported. |
| First byte (feed API or SSR page) | 150ms | Edge-cached responses (Section 3); origin only hit on cache miss. |
| First contentful paint | 250ms | Skeleton screens ship immediately from cached shell; no blocking data fetch before first paint. |
| Feed data hydration | 300ms | Personalized feed served from precomputed Redis features (Phase 8 ranking), not live computation. |
| Interactive (scrollable, tappable) | 200ms | Progressive hydration (Next.js RSC streaming; Flutter first-frame optimization). |
| **Total** | **~980ms** | Measured continuously in production via Real User Monitoring, not just synthetic lab tests. |

## 2. Mobile (Flutter) Performance

- Impeller rendering engine enabled — eliminates shader-compilation jank on first animation, a common cause of dropped frames on Android mid-range devices.
- Image loading via `cached_network_image` with memory + disk cache tiers, pre-sized to the exact display resolution (no downloading a 2000px image to show in a 400px card).
- Lazy widget construction: feed uses `ListView.builder` (never `ListView(children: [...])`), so only visible + near-visible cards are built.
- App startup: deferred initialization — Firebase, analytics SDKs, and non-critical services initialize after first frame render, not blocking the splash-to-home transition.
- App size budget enforced in CI: any PR that increases the release APK/IPA size beyond a defined threshold fails the build and requires explicit justification.

## 3. Web (Next.js) Performance

- Static generation + Incremental Static Regeneration for category/trending pages (60s revalidation) — most traffic never touches the origin server at all.
- React Server Components for the article body render — zero client JS shipped for content that doesn't need interactivity.
- Image optimization pipeline auto-generates responsive `srcset`s in AVIF/WebP with graceful fallback.
- Route-based code splitting by default (Next.js App Router); heavy client components (Chat with News, charts) are dynamically imported and only loaded when the user actually opens them.
- Core Web Vitals tracked continuously: LCP < 1.0s, INP < 100ms, CLS < 0.05 — enforced as release-blocking budgets in Lighthouse CI, not just dashboards someone might check later.

## 4. Caching Architecture (Layered)

1. **Browser/app cache:** immutable static assets cached forever with content-hashed filenames.
2. **CDN edge cache (CloudFront):** category/trending pages, images, and public API responses for anonymous reads.
3. **Application cache (Redis):** personalized feed responses (30s TTL), article detail (5 min TTL, invalidated on correction), search results (60s TTL) — all defined in Phase 4.
4. **Database query cache:** Postgres shared buffers tuned for the working-set size of hot tables (recent `articles` partitions); Aurora's own buffer cache handles the rest.
- Cache invalidation is event-driven, not just TTL-based, for anything correctness-sensitive (a correction/retraction always purges the relevant cache key immediately, regardless of remaining TTL) — speed never trumps accuracy for the trust-critical content.

## 5. Offline Reading & Progressive Enhancement

- Users can explicitly download articles/categories for offline reading (Phase 2 Downloads screen); downloaded content stored via Isar (Flutter) with full-text, images, and AI summary cached locally.
- Feed gracefully degrades on poor connectivity: cached last-known feed shown immediately with a subtle "showing saved content, tap to refresh" affordance, rather than a blocking spinner or blank error screen.
- Service Worker on the web app caches the app shell and recently viewed articles for offline/flaky-connectivity resilience, following a stale-while-revalidate strategy.

## 6. Database & Query Optimization

- Every hot-path query verified via `EXPLAIN ANALYZE` against a production-sized dataset in CI (Phase 5) — index additions/removals are reviewed against real query plans, not guessed.
- Connection pooling via PgBouncer in transaction mode in front of every service's Aurora connections, since raw Postgres connections are expensive and microservices at this scale would otherwise exhaust `max_connections`.
- N+1 query prevention enforced via a lint rule requiring explicit eager-loading (`relations: [...]` in the ORM) on any repository method that returns a list with related entities.
- Read replicas absorb all feed/search/analytics read traffic (Phase 5 Section 4); only writes and read-your-own-write-sensitive paths (e.g., immediately after a bookmark action) hit the primary.

## 7. Real-Time Performance (WebSockets)

- Breaking-news and live-score payloads are diffs, not full objects (Phase 10 Section 3) — keeps message size minimal for fast serialization/deserialization and low bandwidth on constrained mobile networks.
- Redis pub/sub adapter (Phase 10 Section 4) allows horizontal scaling of WebSocket gateway pods without a single pod becoming a connection bottleneck; connection count per pod monitored with an HPA custom metric to scale ahead of a big match/breaking event.

## 8. Continuous Performance Monitoring

- Real User Monitoring (RUM) embedded in both Flutter and Next.js clients, reporting actual field performance (not just synthetic lab scores) segmented by device tier, network type, and country — since a median urban-4G user in Bengaluru and a rural-3G user in Nagpur have very different real experiences, and averaging them together would hide the second group's problems.
- Performance regression budget enforced in CI: Lighthouse CI (web) and a custom Flutter frame-timing benchmark (mobile) run on every PR; a build that regresses LCP or frame-build-time beyond threshold fails, forcing the regression to be justified or fixed before merge, not discovered post-release.

---

*Performance-optimized services deploy via the pipeline defined in Phase 15. Proceeding to Phase 15.*
