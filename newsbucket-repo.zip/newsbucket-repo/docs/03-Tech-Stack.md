# NewsBucket — Phase 3: Technology Stack
**Version 1.0 | Phase 3 of 16 | Line-by-Line Format**
**Owners: Cloud Architect, Backend Architect, Flutter Lead, React/Next.js Lead, DevOps Engineer**

---

## 1. Selection Principles

- Every choice must be provable at 100M-MAU scale — reference customers or documented case studies required, not just popularity.
- Every choice must have a mature managed-service option on AWS to reduce operational burden at the current team size.
- Every choice must have strong hiring liquidity — we are not betting the company on a niche stack no one can be hired for.
- Prefer boring, battle-tested technology for the critical path (auth, payments, data). Reserve innovation budget for the AI layer, where differentiation actually lives.
- Every layer must support both quick iteration pre-PMF and horizontal scale post-PMF without a rewrite.

## 2. Mobile — Flutter

- Single codebase for Android and iOS — critical for a small team shipping 81 screens without doubling engineering headcount.
- Near-native rendering performance via Skia/Impeller — required to hit sub-1-second perceived load and 60fps feed scrolling.
- Strong offline-first support (Hive/Isar local storage) — needed for the offline-reading and downloads features.
- Mature FCM and WebSocket plugin ecosystem — needed for real-time breaking news and live scores.
- Excellent RTL and ICU localization support out of the box — needed for Urdu and 12+ language targets.
- Widely adopted at scale by comparable consumer apps (e.g., Google Pay, BMW, Alibaba's Xianyu) — proven at hundreds of millions of installs.
- Trade-off accepted: slightly larger app binary size than fully native — mitigated with deferred components and app-size analysis in CI.

## 3. Web — Next.js

- Server-side rendering and static generation — required for sub-1-second first paint and strong SEO on public article pages.
- App Router with React Server Components — reduces client JS shipped for content-heavy pages like article detail.
- Native support for edge middleware — used for geo/language routing at the CDN edge before origin is hit.
- Built-in image optimization pipeline — required given the feed is image-heavy.
- Incremental Static Regeneration — lets category/trending pages be cached at the edge and revalidated on a short interval instead of hitting origin on every request.
- Deployable to Vercel or self-hosted on AWS via containerized Node — keeps optionality open, avoids lock-in to a single hosting vendor.

## 4. Backend — NestJS

- Opinionated, modular architecture — enforces the Clean Architecture / DDD module boundaries required by the NFRs.
- First-class TypeScript — one language across backend, web, and shared validation/DTO logic, reducing context-switching cost and duplicated type definitions.
- Built-in support for dependency injection, guards, interceptors, and pipes — maps directly onto our cross-cutting concerns (auth, rate limiting, logging, validation).
- Native support for both REST and WebSocket gateways in the same framework — avoids running a second framework just for real-time.
- Mature ecosystem for queues (BullMQ), caching (Redis), and ORM (Prisma/TypeORM) integration.
- Strong testing ergonomics (built-in testing module) — directly supports the >85% coverage NFR.

## 5. Database — PostgreSQL

- ACID compliance — non-negotiable for user accounts, subscriptions, and payment records.
- Native JSONB support — allows flexible schema evolution for AI-generated metadata (summaries, entities, embeddings' metadata) without a second document database for most use cases.
- Mature partitioning and read-replica support — required for scaling reads to 100M MAU.
- pgvector extension available — allows storing and querying embeddings directly in Postgres for smaller-scale similarity search, reducing the number of distinct data stores where possible.
- Managed via AWS RDS/Aurora PostgreSQL — gives us automated failover, point-in-time recovery, and multi-AZ replication without building it ourselves.
- Enormous operational knowledge base and hiring pool versus niche databases.

## 6. Caching — Redis

- Sub-millisecond reads for feed pagination cursors, session tokens, and rate-limit counters.
- Native pub/sub — used as the backbone for fanning out real-time breaking-news and live-score events to WebSocket gateway instances.
- Sorted sets — natural fit for trending/leaderboard-style ranking (trending articles, live match commentary ordering).
- Managed via AWS ElastiCache — multi-AZ, automatic failover, cluster mode for horizontal scaling.

## 7. Search — Elasticsearch

- Full-text search across headlines, body text, and entities in 12+ languages, with language-specific analyzers.
- Near-real-time indexing — new articles searchable within seconds of ingestion.
- Powers "related articles" and "source comparison" clustering via more-like-this queries and shared-entity matching.
- Aggregation framework used for trending-topic detection and category-level analytics.
- Managed via Amazon OpenSearch Service (Elasticsearch-compatible) — reduces operational burden of cluster management, patching, and scaling.

## 8. Real-time — WebSockets

- Persistent, bidirectional connections for breaking news push, live sports scores, and live commentary — much lower latency than polling.
- NestJS WebSocket Gateway on the backend, paired with a horizontally scalable connection layer (see Section 13 — Socket.IO with Redis adapter for multi-instance fanout).
- Fallback to Server-Sent Events / long-polling for constrained network environments — ensures graceful degradation rather than feature loss.

## 9. Cloud — AWS

- Broadest managed-service coverage for every layer in this stack (RDS, ElastiCache, OpenSearch, EKS, S3, CloudFront, SQS/SNS) — minimizes custom infrastructure code.
- Strong presence and data-residency options in the ap-south-1 (Mumbai) region — required for India data-residency compliance under the DPDP Act.
- Mature auto-scaling, multi-AZ, and multi-region tooling — directly required by the 99.95% uptime and 100M-MAU NFRs.
- Deepest talent pool among cloud providers for hiring DevOps/SRE at scale.

## 10. Containers & Orchestration — Docker + Kubernetes

- Docker gives us reproducible, immutable build artifacts across dev, staging, and production — eliminates "works on my machine" class of issues.
- Kubernetes (via AWS EKS) gives us declarative auto-scaling, self-healing, and rolling deployments — required for zero-downtime releases at scale.
- Horizontal Pod Autoscaler tied to custom metrics (queue depth, request latency) — required to absorb breaking-news traffic spikes without over-provisioning baseline capacity.
- Namespace-per-environment and namespace-per-domain isolation supports the microservices boundaries defined in Phase 4.

## 11. Monitoring — Grafana + Prometheus

- Prometheus scrapes metrics from every service and Kubernetes node — gives us the "100% of services emit metrics" NFR out of the box.
- Grafana dashboards give a single pane of glass across infrastructure, application, and business metrics (e.g., feed latency next to DAU next to Premium conversions).
- Alertmanager integrated with Prometheus for SLO-based alerting (paging on error-budget burn rate, not just raw thresholds).
- Complemented by distributed tracing (OpenTelemetry → Grafana Tempo) for cross-service request tracing, and centralized logging (Grafana Loki) for the "100% structured logs" NFR.

## 12. CI/CD — GitHub Actions

- Native integration with our GitHub-hosted monorepo/polyrepo — no separate CI system to maintain.
- Matrix builds across Flutter (Android/iOS), Next.js, and NestJS services in parallel.
- Environments and required-reviewers gating for production deploys — supports change-management and audit requirements.
- Reusable workflows shared across all microservices — enforces consistent lint/test/build/scan steps everywhere (see Phase 13 for the full pipeline).

## 13. Authentication — Firebase Auth + JWT

- Firebase Auth handles OTP/phone-based auth (dominant login method in the target Indian market), social login, and email/password with battle-tested security and abuse protection (rate limiting, reCAPTCHA, leaked-password checks).
- Backend issues short-lived JWT access tokens plus refresh tokens after verifying the Firebase ID token — keeps our own services stateless and cloud-agnostic for authorization logic, while offloading the hardest part of auth (credential storage, OTP delivery, fraud signals) to Firebase.
- Role-based claims embedded in JWT for admin/moderation dashboard access control.

## 14. Storage — AWS S3

- Object storage for article images, user-uploaded avatars, podcast/audio files, and offline-download packages.
- Lifecycle policies to transition older media to cheaper storage tiers (Infrequent Access, Glacier) automatically.
- Served through CloudFront CDN with signed URLs for any access-controlled content (e.g., Premium-exclusive downloads).

## 15. Notifications — Firebase Cloud Messaging (FCM)

- Cross-platform push (Android, iOS, Web) from a single integration — avoids maintaining separate APNs and FCM pipelines directly.
- Topic-based messaging used for category-level breaking news subscriptions at scale, without per-user fan-out logic in our own services for broad alerts.
- Data-only messages used for silent background sync (e.g., pre-fetching a breaking article before the user opens the app).

## 16. Supporting Technology Choices (not explicitly listed by name, but required to deliver the PRD)

- **Message queue — AWS SQS + SNS**: decouples ingestion, AI processing, and notification fan-out; smooths breaking-news traffic spikes across the pipeline.
- **AI/ML serving — a mix of managed LLM APIs (for summarization, chat, translation) and self-hosted models (for embeddings, classification, bias/factuality scoring) on AWS**, detailed fully in Phase 8.
- **Vector database — pgvector for moderate scale, with a path to a dedicated vector store (e.g., OpenSearch k-NN, already available via our existing Elasticsearch layer) if similarity-search volume outgrows Postgres.**
- **Feature flagging / experimentation — for safe rollout of ranking-algorithm and UI changes to a fraction of traffic before full release.**
- **Infrastructure as Code — Terraform**, used to define 100% of AWS infrastructure (detailed in Phase 15), so environments are reproducible and reviewable via pull request.
- **Secrets management — AWS Secrets Manager**, integrated with Kubernetes via the External Secrets Operator, so no secret ever lives in a config file or environment variable checked into source control.
- **API Gateway — Kong or AWS API Gateway** in front of the NestJS services (detailed in Phase 4) for centralized auth, rate limiting, and request routing.

## 17. Explicit Rejections (and why)

- **React Native instead of Flutter**: rejected — Flutter's rendering engine gives more consistent 60fps performance across the wide range of low-to-mid-range Android devices dominant in the target market; React Native's reliance on the native bridge/JS thread has historically shown more jank on exactly this device profile.
- **MongoDB instead of PostgreSQL as primary store**: rejected for the primary transactional store — user accounts, subscriptions, and payments need strong relational integrity and ACID guarantees; MongoDB remains a candidate for specific high-write, loosely-structured logs if ever needed, but is not the system of record.
- **GraphQL instead of REST as the primary API style**: rejected for the public API surface per the explicit REST requirement in the brief; a GraphQL gateway may be reconsidered later purely for the mobile BFF layer if over-fetching becomes a measured problem, but is not part of the v1 architecture.
- **Self-managed Kafka instead of SQS/SNS**: rejected for v1 — SQS/SNS gives us 90% of the decoupling benefit with a fraction of the operational overhead; Kafka is a credible future upgrade if event-sourcing/replay requirements grow beyond what SQS offers, and this is captured as a roadmap item, not a v1 dependency.

---

*This stack is the foundation for Phase 4 (Backend Microservices Architecture). Proceeding to Phase 4 upon your approval.*
