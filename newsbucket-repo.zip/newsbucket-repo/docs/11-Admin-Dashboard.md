# NewsBucket — Phase 11: Admin Dashboard
**Version 1.0 | Phase 11 of 16**
**Owners: React/Next.js Lead, Product Manager**

---

## 1. Purpose & Access Model

- A separate Next.js application (`admin.newsbucket.com`), not a hidden route inside the consumer app — different auth flow, different deployment lifecycle, different threat model.
- Access strictly role-gated (`admin`, `moderator`, `publisher_partner` — read-only publisher view) via the JWT role claims defined in Phase 4/5.
- Every action taken in the dashboard writes to `audit_logs` (Phase 5 schema) automatically via a shared middleware — no admin mutation path bypasses audit logging.
- Enforced IP allow-listing + mandatory hardware-key 2FA for `admin` role, per Phase 12 security requirements.

## 2. Screen Inventory

**User Management**
- User search/list with filters (subscription tier, signup date, country, activity status).
- User detail view: profile, subscription history, device list, notification preferences, moderation history.
- Ban/suspend/reinstate actions with mandatory reason field (audit-logged).

**News & Content Management**
- Article browse/search across all ingested content, with status filters (published, corrected, retracted, removed).
- Manual article correction/retraction workflow, with public-facing correction note (feeds `article_corrections` table).
- Manual "mark as breaking" override for editorial judgment calls the automated pipeline missed.

**Category Management**
- CRUD for categories and their translations across all 12+ languages.
- Reorder category display priority per the Phase 2 category browse screen.

**Publisher Management**
- Publisher onboarding workflow (Tier 1/2/3 assignment per Phase 9 policy).
- Trust score and bias rating override (with required justification note, since this is the platform's most sensitive editorial lever).
- Revenue-share configuration and payout history per publisher.

**Moderation**
- Moderation queue (Phase 5 `moderation_queue` table) with filters by flag reason, status, assignee.
- Bulk-resolve tooling for high-confidence, low-risk categories (e.g., auto-approve items where the AI Service's fake-news-confidence score is below 0.1 and no user report exists), always with a supervisor override available.
- Full audit trail viewer per article: every AI score, every human decision, every correction, in chronological order.

**Advertisements**
- Ad campaign creation/scheduling, native-ad-card preview matching the exact in-feed rendering (WYSIWYG, not a generic ad-manager mockup).
- Frequency capping configuration per the PRD's non-intrusive ad policy.
- Fill-rate and eCPM reporting per placement.

**Analytics**
- KPI dashboard: DAU/MAU, retention cohorts, session metrics, feed engagement, matching the Phase 1 KPI definitions exactly (single source of truth, no dashboard-specific metric redefinition).
- AI-quality dashboard: factual-consistency scores, Chat-with-News grounded-response rate, moderation-queue resolution SLA.
- Revenue dashboard: subscription MRR/ARR, churn, ad revenue, blended ARPU.

**Notifications**
- Manual breaking-news broadcast composer (for editorially significant events the automated pipeline under-flagged), with a preview of estimated recipient count before send.
- Notification performance reporting (open rate, opt-out rate) per category.

**Reports**
- Scheduled/exportable reports (CSV/PDF) for exec/board reporting, generated from the same underlying KPI data as the live dashboard.

**Revenue & Subscriptions**
- Subscription plan management (pricing tiers, regional pricing per PRD monetization strategy).
- Individual subscription lookup/refund-initiation tooling, integrated with the Play Store/App Store/Stripe webhooks from Phase 6.

## 3. Moderation Queue Screen (Representative Implementation)

```tsx
// admin-app/app/moderation/queue/page.tsx
'use client';

import { useState } from 'react';
import { useModerationQueue } from '@/hooks/use-moderation-queue';
import { ModerationItemRow } from '@/components/moderation/moderation-item-row';
import { RoleGuard } from '@/components/auth/role-guard';

export default function ModerationQueuePage() {
  const [statusFilter, setStatusFilter] = useState<'pending' | 'reviewing'>('pending');
  const { items, isLoading, resolveItem, refetch } = useModerationQueue(statusFilter);

  return (
    <RoleGuard allowedRoles={['admin', 'moderator']}>
      <div className="p-6">
        <h1 className="text-lg font-medium">Moderation queue</h1>
        <div className="mt-4 flex gap-2">
          {(['pending', 'reviewing'] as const).map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={statusFilter === status ? 'font-medium underline' : ''}
            >
              {status}
            </button>
          ))}
        </div>
        {isLoading ? (
          <div className="mt-6 text-sm text-neutral-500">Loading queue…</div>
        ) : (
          <div className="mt-6 divide-y">
            {items.map((item) => (
              <ModerationItemRow
                key={item.id}
                item={item}
                onResolve={async (resolution, note) => {
                  await resolveItem(item.id, resolution, note);
                  await refetch();
                }}
              />
            ))}
          </div>
        )}
      </div>
    </RoleGuard>
  );
}
```

```tsx
// admin-app/components/auth/role-guard.tsx
'use client';

import { useSession } from '@/hooks/use-session';
import { redirect } from 'next/navigation';

interface RoleGuardProps {
  allowedRoles: string[];
  children: React.ReactNode;
}

// Client-side guard is UX-only (fast redirect); the actual security
// boundary is enforced server-side by every /v1/admin/* endpoint checking
// the JWT role claim independently, per Phase 6 auth requirements. This
// component must never be treated as the authorization mechanism itself.
export function RoleGuard({ allowedRoles, children }: RoleGuardProps) {
  const { user, isLoading } = useSession();

  if (isLoading) return null;
  if (!user || !allowedRoles.some((role) => user.roles.includes(role))) {
    redirect('/unauthorized');
  }
  return <>{children}</>;
}
```

## 4. Design Note

- The Admin Dashboard reuses the Phase 2 design token system (colors, spacing, type) for internal consistency and reduced maintenance, but is information-density-optimized rather than premium-consumer-optimized — dense tables, keyboard shortcuts, and bulk actions take priority over the marketing polish of the consumer app.

---

*Proceeding to Phase 12 (Security Hardening).*
