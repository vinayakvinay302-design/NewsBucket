# NewsBucket — Phase 8: AI Feature Implementation
**Version 1.0 | Phase 8 of 16**
**Owners: AI Engineer, Machine Learning Engineer**

---

## 1. AI Feature Map

| Feature | Model Approach | Latency Target | Trigger |
|---|---|---|---|
| One-line / bullet / ELI5 summary | Managed LLM (prompt-engineered, structured output) | Async, within 30s of ingestion | `article.ingested` event |
| Timeline generation | LLM + cluster history retrieval | Async, on cluster update | `article_cluster.updated` event |
| Entity recognition | Fine-tuned NER model (self-hosted) | Async, <2s per article | `article.ingested` event |
| Topic detection | Embedding + clustering (self-hosted) | Async, <2s per article | `article.ingested` event |
| Related articles | Vector similarity (pgvector/OpenSearch k-NN) | Sync, <100ms | On article-detail request |
| Fake-news detection | Ensemble: source-reputation + claim-checking LLM + ML classifier | Async, <60s | `article.ingested` event |
| Bias detection | Self-hosted classifier + publisher prior | Async, <10s | `article.ingested` event |
| Sentiment analysis | Self-hosted classifier | Async, <2s | `article.ingested` event |
| Translation | Managed LLM with glossary-constrained decoding | Async pre-generation for top languages; on-demand for long-tail | `article.ingested` event + on-demand |
| Voice reading (TTS) | Managed TTS API | On-demand, streamed | User taps "Listen" |
| Podcast generation | LLM script-writing + TTS | Scheduled (daily briefing) | Kubernetes CronJob |
| Chat with News (RAG) | Managed LLM, strictly grounded, tool-free | Sync, streamed, <3s to first token | User query |
| Recommendation engine | Hybrid: collaborative filtering + content embeddings + learned ranker | Sync, <50ms (precomputed features) | Every feed request |
| Trending prediction | Time-series model on engagement velocity | Batch, every 5 min | Scheduled job |

## 2. Grounding & Anti-Hallucination Architecture (Core Trust Requirement)

- Every AI-generated claim about a specific article must be traceable to that article's `body_html` or its cluster's source set — never generated from the model's general world knowledge.
- Summarization prompts explicitly instruct: "Only include facts present in the provided text. Do not add outside context, predictions, or unstated inferences."
- A post-generation **factual-consistency check** runs a separate, smaller verification model that re-reads the summary against the source text and flags any unsupported sentence; flagged summaries are regenerated once, then routed to the moderation queue if still failing, rather than shipped.
- Chat-with-News uses Retrieval-Augmented Generation exclusively against: (a) the current article's full text, (b) the other articles in its cluster, (c) nothing else. The system prompt instructs a hard refusal — "I don't have enough information in these sources to answer that" — when retrieved context doesn't cover the question, and this refusal path is tested in CI with adversarial prompts (see Phase 13).
- Every AI-generated sentence surfaced to a user carries a `model_version` and `generated_at` stamp in `article_ai_metadata` (Phase 5 schema) for auditability and rollback if a model version is later found to be unreliable.

## 3. Chat-with-News Service (NestJS, RAG Implementation)

```typescript
// ai-service/src/chat/chat.service.ts
import { Injectable } from '@nestjs/common';
import { ArticleRepository } from '../articles/article.repository';
import { EmbeddingService } from '../embeddings/embedding.service';
import { LlmClient } from '../llm/llm.client';

interface ChatResult {
  answer: string;
  citations: { sourceArticleId: string; excerpt: string }[];
  grounded: boolean;
}

@Injectable()
export class ChatService {
  constructor(
    private readonly articles: ArticleRepository,
    private readonly embeddings: EmbeddingService,
    private readonly llm: LlmClient,
  ) {}

  async answerQuestion(articleId: string, question: string, userId: string): Promise<ChatResult> {
    const article = await this.articles.findByIdWithCluster(articleId);
    if (!article) {
      throw new Error('ARTICLE_NOT_FOUND');
    }

    // Retrieve grounding context: this article + top-3 clustered sources by
    // embedding similarity to the question, never the open web or model memory.
    const clusterArticles = await this.articles.findClusterMembers(article.clusterId, {
      excludeId: articleId,
      limit: 3,
    });
    const candidates = [article, ...clusterArticles];
    const ranked = await this.embeddings.rankBySimilarity(question, candidates);

    const context = ranked
      .map((a, i) => `[Source ${i + 1}: ${a.publisherName}]\n${a.bodyText}`)
      .join('\n\n---\n\n');

    const systemPrompt = [
      'You are NewsBucket\'s Chat with News assistant.',
      'Answer the user\'s question using ONLY the sources provided below.',
      'Every claim in your answer must cite a source number, e.g. [Source 1].',
      'If the sources do not contain enough information to answer, respond exactly:',
      '"I don\'t have enough information in these sources to answer that."',
      'Never use outside knowledge, predictions, or unstated inference.',
    ].join(' ');

    const completion = await this.llm.complete({
      system: systemPrompt,
      user: `Sources:\n\n${context}\n\nQuestion: ${question}`,
      maxTokens: 500,
      temperature: 0.1, // low temperature: factual grounding over creativity
    });

    const grounded = !completion.text.includes(
      "I don't have enough information in these sources to answer that",
    );

    return {
      answer: completion.text,
      citations: grounded ? this.extractCitations(completion.text, ranked) : [],
      grounded,
    };
  }

  private extractCitations(
    answerText: string,
    sources: { id: string; bodyText: string; publisherName: string }[],
  ) {
    const citations: { sourceArticleId: string; excerpt: string }[] = [];
    const matches = answerText.matchAll(/\[Source (\d+)\]/g);
    const seen = new Set<number>();
    for (const match of matches) {
      const idx = parseInt(match[1], 10) - 1;
      if (!seen.has(idx) && sources[idx]) {
        seen.add(idx);
        citations.push({
          sourceArticleId: sources[idx].id,
          excerpt: sources[idx].bodyText.slice(0, 180),
        });
      }
    }
    return citations;
  }
}
```

## 4. Recommendation Engine — Ranking Signal Composition

```python
# recommendation-service/ranking/feature_composer.py
"""
Combines explicit + implicit signals into a single ranking score per
candidate article for a given user. Runs against precomputed Redis
feature vectors -- no live model inference on the request path, to hit
the <50ms feed-ranking latency budget.
"""

from dataclasses import dataclass


@dataclass
class RankingWeights:
    explicit_interest: float = 0.30
    implicit_affinity: float = 0.25
    freshness: float = 0.20
    engagement_velocity: float = 0.15
    diversity_penalty: float = 0.10  # subtracted, not added


def score_article(user_features: dict, article_features: dict, weights: RankingWeights) -> float:
    explicit = user_features["category_weights"].get(article_features["category_id"], 0.0)
    implicit = cosine_similarity(user_features["embedding"], article_features["embedding"])
    freshness = freshness_decay(article_features["published_at_epoch"])
    velocity = article_features["engagement_velocity_percentile"]
    diversity_penalty = recent_category_repetition_penalty(
        user_features["recent_categories_shown"], article_features["category_id"]
    )

    score = (
        weights.explicit_interest * explicit
        + weights.implicit_affinity * implicit
        + weights.freshness * freshness
        + weights.engagement_velocity * velocity
        - weights.diversity_penalty * diversity_penalty
    )
    return score


def freshness_decay(published_at_epoch: float, half_life_hours: float = 6.0) -> float:
    import time
    import math
    age_hours = (time.time() - published_at_epoch) / 3600
    return math.exp(-age_hours * (math.log(2) / half_life_hours))


def recent_category_repetition_penalty(recent_categories: list[str], category_id: str) -> float:
    """Explicit diversity-injection mechanism referenced in the PRD --
    prevents the feed from collapsing into a single-category filter bubble."""
    count = recent_categories.count(category_id)
    return min(count / 5.0, 1.0)


def cosine_similarity(vec_a: list[float], vec_b: list[float]) -> float:
    dot = sum(a * b for a, b in zip(vec_a, vec_b))
    norm_a = sum(a * a for a in vec_a) ** 0.5
    norm_b = sum(b * b for b in vec_b) ** 0.5
    return dot / (norm_a * norm_b + 1e-9)
```

## 5. Fake-News & Bias Detection Pipeline

- **Stage 1 — Source prior:** every publisher carries a rolling `trust_score` (0–10) and `bias_rating`, updated monthly from a blend of third-party media-bias datasets and NewsBucket's own correction-rate history — never computed from a single article in isolation.
- **Stage 2 — Content classifier:** a self-hosted fine-tuned classifier scores the specific article for sensationalism markers, unsupported-claim density, and emotional-language intensity.
- **Stage 3 — Claim-check LLM pass:** for articles scoring above a risk threshold in Stage 2, an LLM pass extracts discrete factual claims and cross-references them against the other articles in the same cluster; claims contradicted by multiple independent sources are flagged.
- **Stage 4 — Human-in-the-loop:** any article with a combined fake-news confidence above 0.7, or any claim flagged in Stage 3, routes to `moderation_queue` (Phase 5 schema) rather than being auto-labeled — the model never unilaterally brands something "fake," it escalates for a human moderator decision, logged with full audit trail.
- Bias and factuality scores are always displayed with a link to the published methodology (PRD Section 12, Risk mitigation) so the scoring itself is falsifiable and auditable by users and researchers.

## 6. Model Governance

- Every model (summarizer, classifier, embedding model, LLM prompt version) is versioned and referenced by `model_version` in stored outputs — allows targeted rollback of a specific model's outputs without touching others.
- A held-out evaluation set of 2,000+ hand-labeled articles (updated quarterly) is scored against every candidate model version before promotion to production; promotion requires meeting or exceeding the current production model on factual-consistency, bias-neutrality, and latency benchmarks simultaneously.
- Shadow deployment: new model versions run in parallel on live traffic without being shown to users for a minimum 72 hours, comparing output divergence against the current production model before cutover.

---

*AI outputs from this phase feed directly into Phase 9 (Live News Ingestion). Proceeding to Phase 9.*
