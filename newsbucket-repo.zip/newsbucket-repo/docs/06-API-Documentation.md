# NewsBucket — Phase 6: REST API Documentation
**Version 1.0 | Phase 6 of 16**
**Owner: Backend Architect**

---

## 1. API Conventions (apply to every endpoint)

- Base path: `https://api.newsbucket.com/v1/...` — major version in the URL path; breaking changes ship as `/v2` with `/v1` supported for a minimum 12-month deprecation window.
- Auth: `Authorization: Bearer <JWT>` header on all authenticated endpoints; anonymous read-only endpoints explicitly marked below.
- Pagination: cursor-based (`?cursor=<opaque_token>&limit=20`, max `limit=50`), not offset-based — required for stable pagination on a feed that changes in real time.
- Filtering: `?category=technology&language=hi&from=2026-07-01`.
- Sorting: `?sort=published_at:desc` (default) or `sort=relevance:desc` (search only).
- Response envelope (success):
```json
{
  "data": { },
  "meta": { "next_cursor": "opaque_token_or_null", "request_id": "uuid" }
}
```
- Response envelope (error):
```json
{
  "error": {
    "code": "ARTICLE_NOT_FOUND",
    "message": "The requested article does not exist or has been removed.",
    "request_id": "uuid"
  }
}
```
- Standard HTTP status codes: 200, 201, 204, 400, 401, 403, 404, 409, 422, 429, 500, 503.
- Every response includes `X-Request-Id` header, propagated through logs/traces for cross-service debugging.
- Rate-limit headers on every response: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`.
- Full interactive documentation published via Swagger/OpenAPI at `https://api.newsbucket.com/v1/docs`, generated directly from NestJS decorators (`@ApiTags`, `@ApiOperation`, `@ApiResponse`) so the spec can never drift from the actual implementation.

## 2. Authentication Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/v1/auth/verify-firebase-token` | None | Exchange a Firebase ID token for a NewsBucket JWT access + refresh token pair. |
| POST | `/v1/auth/refresh` | Refresh token | Rotate a refresh token for a new access token. |
| POST | `/v1/auth/logout` | Bearer | Revoke the current refresh token. |
| GET | `/v1/auth/me` | Bearer | Return the current user's profile, roles, and subscription status. |
| DELETE | `/v1/auth/me` | Bearer | Initiate account deletion (DPDP/GDPR right-to-erasure workflow). |

## 3. Feed & Article Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/v1/feed/home` | Bearer (optional) | Personalized "For You" feed; falls back to editorial/trending ranking for anonymous users. |
| GET | `/v1/feed/breaking` | None | Current breaking-news items, sorted by published_at desc. |
| GET | `/v1/feed/trending` | None | Trending articles by engagement velocity. |
| GET | `/v1/feed/local` | Bearer (optional) | Location-based feed; requires `?lat=&lng=` or resolves from IP if omitted. |
| GET | `/v1/feed/category/:slug` | None | Category feed (e.g., `technology`, `cricket`). |
| GET | `/v1/articles/:id` | None | Full article detail including AI metadata, bias/factuality scores, and cluster info. |
| GET | `/v1/articles/:id/related` | None | Related articles via entity/embedding similarity. |
| GET | `/v1/articles/:id/sources` | None | Other outlets covering the same clustered story. |
| GET | `/v1/articles/:id/corrections` | None | Correction/retraction history for the article. |
| POST | `/v1/articles/:id/chat` | Bearer | Ask a question about the article (Chat with News, RAG-grounded). Rate-limited per Phase 4 Section 5. |
| POST | `/v1/articles/:id/report` | Bearer | User-initiated content report, feeds the moderation queue. |

## 4. Personalization Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/v1/users/me/interests` | Bearer | List current explicit + implicit interest weights. |
| PUT | `/v1/users/me/interests` | Bearer | Set explicit category interests (onboarding + settings). |
| GET | `/v1/users/me/bookmarks` | Bearer | Paginated bookmarks. |
| POST | `/v1/users/me/bookmarks` | Bearer | Add a bookmark. |
| DELETE | `/v1/users/me/bookmarks/:articleId` | Bearer | Remove a bookmark. |
| GET | `/v1/users/me/history` | Bearer | Paginated read history. |
| DELETE | `/v1/users/me/history` | Bearer | Clear read history. |
| GET | `/v1/users/me/notifications/preferences` | Bearer | Get notification settings. |
| PUT | `/v1/users/me/notifications/preferences` | Bearer | Update notification settings. |

## 5. Search Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/v1/search` | None | `?q=&category=&language=&from=&to=&sort=` full-text search. |
| GET | `/v1/search/suggestions` | None | AI-assisted query autocomplete. |

## 6. Sports Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/v1/sports/:sport/matches/live` | None | Currently live matches for a sport (`cricket`, `football`, `nba`, etc.). |
| GET | `/v1/sports/:sport/matches/:matchId` | None | Full match detail: scorecard, commentary, stats. |
| GET | `/v1/sports/:sport/fixtures` | None | Upcoming fixtures. |
| GET | `/v1/sports/:sport/standings/:competitionId` | None | League/tournament standings table. |
| GET | `/v1/sports/players/:playerId` | None | Player profile and career stats. |
| GET | `/v1/sports/clubs/:clubId` | None | Club/team profile. |
| GET | `/v1/sports/:sport/fantasy/:matchId` | Bearer | Fantasy-relevant player stats for a live/recent match. |
| WS | `/v1/ws/sports/:matchId` | Bearer (optional) | WebSocket channel for live score/commentary push. |

## 7. Notification Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/v1/notifications/register-device` | Bearer | Register an FCM device token against the user. |
| DELETE | `/v1/notifications/register-device/:token` | Bearer | Deregister a device token (logout/uninstall). |
| WS | `/v1/ws/breaking-news` | Bearer (optional) | WebSocket channel for real-time breaking-news alerts. |

## 8. Subscription & Billing Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/v1/subscriptions/plans` | None | Available Premium plans and regional pricing. |
| POST | `/v1/subscriptions/verify-receipt` | Bearer | Verify a Play Store/App Store purchase receipt and activate Premium. |
| GET | `/v1/subscriptions/me` | Bearer | Current subscription status. |
| POST | `/v1/subscriptions/cancel` | Bearer | Cancel auto-renewal. |

## 9. Admin Endpoints (all require `admin` or `moderator` role claim)

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/v1/admin/moderation/queue` | Admin/Mod | Paginated moderation queue with filters. |
| POST | `/v1/admin/moderation/:id/resolve` | Admin/Mod | Resolve a flagged item (approve/correct/remove). |
| GET | `/v1/admin/publishers` | Admin | List/manage publisher partners and trust scores. |
| PUT | `/v1/admin/publishers/:id` | Admin | Update publisher trust score, bias rating, revenue share. |
| GET | `/v1/admin/users` | Admin | Search/manage users (ban, role changes). |
| GET | `/v1/admin/analytics/kpis` | Admin | Aggregated KPI dashboard data (DAU/MAU, retention, revenue). |
| GET | `/v1/admin/audit-logs` | Admin | Searchable audit log of all admin/moderation actions. |

## 10. Sample OpenAPI Excerpt (Article Detail Endpoint)

```yaml
/v1/articles/{id}:
  get:
    tags: [Articles]
    summary: Get full article detail with AI metadata
    parameters:
      - name: id
        in: path
        required: true
        schema: { type: string, format: uuid }
      - name: lang
        in: query
        required: false
        description: Preferred translation language (ISO 639-1)
        schema: { type: string, example: "hi" }
    responses:
      '200':
        description: Article found
        content:
          application/json:
            schema:
              type: object
              properties:
                data:
                  type: object
                  properties:
                    id: { type: string, format: uuid }
                    headline: { type: string }
                    body_html: { type: string }
                    publisher: { $ref: '#/components/schemas/Publisher' }
                    published_at: { type: string, format: date-time }
                    factuality_score: { type: number, minimum: 0, maximum: 10 }
                    bias_rating: { type: string, enum: [left, lean_left, center, lean_right, right, unrated] }
                    ai_summary:
                      type: object
                      properties:
                        one_line: { type: string }
                        bullets: { type: array, items: { type: string } }
                        eli5: { type: string }
      '404':
        description: Article not found or removed
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ErrorResponse' }
      '429':
        description: Rate limit exceeded
```

## 11. Error Code Reference (excerpt)

| Code | HTTP Status | Meaning |
|---|---|---|
| `AUTH_TOKEN_EXPIRED` | 401 | Access token expired; client should refresh. |
| `AUTH_TOKEN_INVALID` | 401 | Malformed or tampered token. |
| `FORBIDDEN_ROLE` | 403 | Authenticated but lacks required role. |
| `ARTICLE_NOT_FOUND` | 404 | Article missing, deleted, or removed by moderation. |
| `RATE_LIMIT_EXCEEDED` | 429 | Too many requests; see `X-RateLimit-Reset`. |
| `VALIDATION_ERROR` | 422 | Request body failed schema validation; `details` array included. |
| `CHAT_INSUFFICIENT_SOURCES` | 200 (not an error) | Chat-with-News explicitly declined to answer — surfaced as a normal response state, not an error, per Phase 8 grounding rules. |
| `SUBSCRIPTION_RECEIPT_INVALID` | 409 | Store receipt failed verification. |
| `INTERNAL_ERROR` | 500 | Unhandled server error; `request_id` included for support lookup. |

---

*These APIs are the contract for Phase 7 (Mobile & Web App Implementation). Proceeding to Phase 7.*
