# NewsBucket — Phase 9: Live News Ingestion Pipeline
**Version 1.0 | Phase 9 of 16**
**Owners: Data Engineer, Backend Architect**

---

## 1. Ingestion Sources

- **RSS/Atom feeds:** direct publisher feeds, polled on a per-source interval (30s for high-velocity sources, 5 min for low-velocity).
- **Official publisher APIs:** direct partnership integrations (preferred over RSS scraping wherever a partnership exists — cleaner data, licensing clarity, revenue-share eligibility per PRD monetization strategy).
- **Government/PIB APIs:** official government press releases and PIB (Press Information Bureau) feeds for high-trust civic/policy news.
- **Sports data providers:** dedicated real-time sports data APIs (see Phase 10) for scores/commentary, separate from the general news ingestion path due to much higher update frequency.
- **Weather APIs:** national meteorological department + commercial weather API blend for hyperlocal accuracy.
- **Finance APIs:** market-data providers for stock/crypto/gold-silver pricing, on a separate low-latency streaming path (not the batch news pipeline).

## 2. Ingestion Pipeline Architecture

```
Source Pollers/Webhooks → Raw Ingestion Queue (SQS) → Normalization Worker
   → Duplicate Detection → Source Verification → AI Enrichment Queue (Phase 8)
   → Search Indexing + Cache Warm → Publish Event → Notification Fan-out
```

## 3. Ingestion Worker (Normalization)

```typescript
// ingestion-service/src/workers/normalization.worker.ts
import { Injectable, Logger } from '@nestjs/common';
import { SqsConsumer } from '../queue/sqs-consumer';
import { DuplicateDetectionService } from './duplicate-detection.service';
import { SourceVerificationService } from './source-verification.service';
import { ArticleRepository } from '../articles/article.repository';
import { EventPublisher } from '../events/event-publisher';

interface RawIngestedArticle {
  sourceType: 'rss' | 'publisher_api' | 'government_api';
  publisherSlug: string;
  canonicalUrl: string;
  headline: string;
  bodyHtml: string;
  heroImageUrl?: string;
  authorName?: string;
  publishedAtRaw: string;
  language: string;
}

@Injectable()
export class NormalizationWorker {
  private readonly logger = new Logger(NormalizationWorker.name);

  constructor(
    private readonly dupeDetection: DuplicateDetectionService,
    private readonly sourceVerification: SourceVerificationService,
    private readonly articles: ArticleRepository,
    private readonly events: EventPublisher,
  ) {}

  @SqsConsumer('ingestion-raw-queue', { batchSize: 10, visibilityTimeout: 60 })
  async handle(raw: RawIngestedArticle): Promise<void> {
    // 1. Source verification -- reject unknown/unverified publishers outright,
    // route borderline/new sources to a manual onboarding review queue rather
    // than auto-publishing unverified content.
    const publisher = await this.sourceVerification.resolvePublisher(raw.publisherSlug);
    if (!publisher) {
      this.logger.warn(`Rejected article from unverified source: ${raw.publisherSlug}`);
      await this.sourceVerification.queueForReview(raw);
      return;
    }

    // 2. Duplicate detection -- canonical URL exact match first (cheap),
    // then near-duplicate detection via title+body simhash against a rolling
    // 48-hour window before falling back to expensive embedding similarity.
    const exactDuplicate = await this.dupeDetection.findByCanonicalUrl(raw.canonicalUrl);
    if (exactDuplicate) {
      this.logger.debug(`Skipping exact duplicate: ${raw.canonicalUrl}`);
      return;
    }
    const nearDuplicateClusterId = await this.dupeDetection.findNearDuplicateCluster(
      raw.headline,
      raw.bodyHtml,
    );

    // 3. Sanitize + normalize HTML body (strip scripts/trackers/ads embedded
    // by source, normalize to a constrained safe-HTML subset).
    const sanitizedBody = this.sanitizeHtml(raw.bodyHtml);

    // 4. Persist as a new article, attaching to an existing cluster if a
    // near-duplicate was found (this is how "Other outlets covering this"
    // source-comparison clustering, per Phase 5/6, gets populated).
    const article = await this.articles.create({
      publisherId: publisher.id,
      headline: raw.headline,
      bodyHtml: sanitizedBody,
      canonicalUrl: raw.canonicalUrl,
      heroImageUrl: raw.heroImageUrl,
      authorName: raw.authorName,
      originalLanguage: raw.language,
      publishedAt: new Date(raw.publishedAtRaw),
      clusterId: nearDuplicateClusterId ?? undefined,
      status: 'published',
    });

    // 5. Emit event -- triggers AI enrichment (Phase 8), search indexing,
    // and notification evaluation in parallel, decoupled consumers.
    await this.events.publish('news.article.published', {
      articleId: article.id,
      publisherId: publisher.id,
      isPotentiallyBreaking: this.isLikelyBreaking(raw, publisher),
    });
  }

  private isLikelyBreaking(raw: RawIngestedArticle, publisher: { trustScore: number }): boolean {
    const breakingKeywords = ['breaking', 'urgent', 'alert', 'just in'];
    const headlineLower = raw.headline.toLowerCase();
    return (
      publisher.trustScore >= 7.0 &&
      breakingKeywords.some((kw) => headlineLower.includes(kw))
    );
  }

  private sanitizeHtml(html: string): string {
    // Production implementation uses a strict allow-list sanitizer
    // (e.g. sanitize-html with a locked-down config: p, a, strong, em, ul,
    // li, blockquote, img[src,alt] only -- no script, style, iframe, on*).
    return html; // sanitizer invocation omitted for brevity of this excerpt
  }
}
```

## 4. Duplicate Detection Service

```typescript
// ingestion-service/src/workers/duplicate-detection.service.ts
import { Injectable } from '@nestjs/common';
import { createHash } from 'crypto';
import { RedisClient } from '../cache/redis.client';
import { EmbeddingClient } from '../ai/embedding.client';

@Injectable()
export class DuplicateDetectionService {
  constructor(
    private readonly redis: RedisClient,
    private readonly embeddings: EmbeddingClient,
  ) {}

  async findByCanonicalUrl(url: string): Promise<{ id: string } | null> {
    const normalized = this.normalizeUrl(url);
    return this.redis.get(`article:url:${this.hash(normalized)}`);
  }

  /**
   * Two-stage near-duplicate detection:
   * 1. Cheap simhash comparison against a rolling 48h Redis-backed index --
   *    catches near-identical wire-service republishes across outlets.
   * 2. If simhash is inconclusive, fall back to embedding cosine similarity
   *    against the small candidate set simhash already narrowed down --
   *    never runs embedding comparison against the full historical corpus.
   */
  async findNearDuplicateCluster(headline: string, bodyHtml: string): Promise<string | null> {
    const simhash = this.computeSimhash(`${headline} ${this.stripHtml(bodyHtml)}`);
    const candidates = await this.redis.getSimhashCandidates(simhash, {
      maxHammingDistance: 6,
      windowHours: 48,
    });

    if (candidates.length === 0) return null;
    if (candidates.length === 1) return candidates[0].clusterId;

    const embedding = await this.embeddings.embed(`${headline}\n${this.stripHtml(bodyHtml)}`);
    let bestMatch: { clusterId: string; score: number } | null = null;
    for (const candidate of candidates) {
      const score = this.cosineSimilarity(embedding, candidate.embedding);
      if (score > 0.88 && (!bestMatch || score > bestMatch.score)) {
        bestMatch = { clusterId: candidate.clusterId, score };
      }
    }
    return bestMatch?.clusterId ?? null;
  }

  private computeSimhash(text: string): bigint {
    // Production implementation: 64-bit simhash over shingled tokens.
    // Omitted here -- standard simhash algorithm, not NewsBucket-specific.
    return BigInt(0);
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    const dot = a.reduce((sum, val, i) => sum + val * b[i], 0);
    const normA = Math.sqrt(a.reduce((s, v) => s + v * v, 0));
    const normB = Math.sqrt(b.reduce((s, v) => s + v * v, 0));
    return dot / (normA * normB + 1e-9);
  }

  private normalizeUrl(url: string): string {
    const u = new URL(url);
    u.search = '';
    u.hash = '';
    return u.toString().toLowerCase().replace(/\/$/, '');
  }

  private stripHtml(html: string): string {
    return html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  }

  private hash(input: string): string {
    return createHash('sha256').update(input).digest('hex');
  }
}
```

## 5. Source Verification Policy

- Every publisher must be manually onboarded once (legal/licensing check, trust-score baseline assignment) before its content flows past the ingestion pipeline automatically — no source auto-publishes on first contact.
- Verified publishers are tiered: **Tier 1** (revenue-share partners, highest trust prior, eligible for "Breaking" designation), **Tier 2** (verified but standard trust prior), **Tier 3** (probationary — new partnerships, output routed through moderation review for the first 30 days / 500 articles before graduating to Tier 2).
- Any publisher whose fake-news-confidence rate (Phase 8) exceeds a threshold over a rolling 30-day window is automatically demoted a tier and flagged for manual review — trust scores are dynamic, not "set once."

## 6. Content Moderation Integration

- Every ingested article passes through the Phase 8 fake-news/bias pipeline before being eligible for personalized-feed placement (it can still be searchable/visible on the publisher's own page immediately, satisfying speed, but is held back from algorithmic promotion until Stage 2 scoring completes — typically under 60 seconds).
- Breaking-news candidates (Section 3, `isLikelyBreaking`) get an expedited moderation lane: automated Stage 1+2 checks only (skipping the slower Stage 3 claim-check LLM pass) to hit the sub-30-second breaking-news latency NFR, with Stage 3 running asynchronously afterward and able to retract/correct if it later fails.

---

*Ingested, verified content flows into the feed and search systems built in Phases 4–6, and into the sports-specific pipeline detailed next in Phase 10.*
