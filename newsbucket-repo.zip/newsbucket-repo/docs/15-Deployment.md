# NewsBucket — Phase 15: Deployment
**Version 1.0 | Phase 15 of 16**
**Owners: DevOps Engineer, Cloud Architect**

---

## 1. Environment Topology

- Three environments: `dev` (shared, ephemeral namespaces per feature branch), `staging` (production-parity, used for load tests and E2E per Phase 13), `production` (multi-AZ, ap-south-1 primary + us-east-1 disaster-recovery standby).
- Every environment provisioned from the same Terraform modules with environment-specific variable files — no environment is hand-built or drifted from the module definitions.

## 2. Infrastructure as Code (Terraform Excerpt)

```hcl
# infra/modules/eks-cluster/main.tf
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 20.0"

  cluster_name    = "newsbucket-${var.environment}"
  cluster_version = "1.30"

  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnet_ids

  eks_managed_node_groups = {
    general = {
      instance_types = ["m6i.xlarge"]
      min_size       = var.environment == "production" ? 6 : 2
      max_size       = var.environment == "production" ? 60 : 6
      desired_size   = var.environment == "production" ? 8 : 2
      labels         = { workload = "general" }
    }
    ai_workers = {
      instance_types = ["c6i.2xlarge"]
      min_size       = var.environment == "production" ? 3 : 1
      max_size       = var.environment == "production" ? 30 : 3
      desired_size   = var.environment == "production" ? 4 : 1
      labels         = { workload = "ai-processing" }
      taints = [{
        key    = "workload"
        value  = "ai-processing"
        effect = "NO_SCHEDULE"
      }]
    }
  }

  cluster_endpoint_private_access = true
  cluster_endpoint_public_access  = var.environment != "production"

  tags = {
    Environment = var.environment
    Project     = "newsbucket"
    ManagedBy   = "terraform"
  }
}

module "aurora_postgresql" {
  source  = "terraform-aws-modules/rds-aurora/aws"
  version = "~> 9.0"

  name              = "newsbucket-${var.environment}"
  engine            = "aurora-postgresql"
  engine_version    = "16.3"
  instance_class    = var.environment == "production" ? "db.r6g.2xlarge" : "db.r6g.large"
  instances = var.environment == "production" ? {
    writer = {}
    reader1 = {}
    reader2 = {}
  } : { writer = {} }

  storage_encrypted   = true
  kms_key_id          = module.kms.key_arn
  backup_retention_period = 35
  preferred_backup_window = "17:00-18:00" # UTC, low-traffic window for IST users
  deletion_protection = var.environment == "production"

  vpc_id               = module.vpc.vpc_id
  db_subnet_group_name = module.vpc.database_subnet_group_name

  tags = { Environment = var.environment, Project = "newsbucket" }
}
```

## 3. Kubernetes Deployment Manifest (News Service Example)

```yaml
# k8s/news-service/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: news-service
  namespace: newsbucket-production
  labels: { app: news-service }
spec:
  replicas: 8
  strategy:
    type: RollingUpdate
    rollingUpdate: { maxSurge: 2, maxUnavailable: 0 }
  selector:
    matchLabels: { app: news-service }
  template:
    metadata:
      labels: { app: news-service }
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "9090"
    spec:
      containers:
        - name: news-service
          image: 123456789.dkr.ecr.ap-south-1.amazonaws.com/news-service:__IMAGE_TAG__
          ports:
            - { containerPort: 3000, name: http }
            - { containerPort: 9090, name: metrics }
          envFrom:
            - secretRef: { name: news-service-secrets }
            - configMapRef: { name: news-service-config }
          resources:
            requests: { cpu: "500m", memory: "512Mi" }
            limits: { cpu: "1000m", memory: "1Gi" }
          readinessProbe:
            httpGet: { path: /health/ready, port: 3000 }
            initialDelaySeconds: 5
            periodSeconds: 10
          livenessProbe:
            httpGet: { path: /health/live, port: 3000 }
            initialDelaySeconds: 15
            periodSeconds: 20
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: news-service-hpa
  namespace: newsbucket-production
spec:
  scaleTargetRef: { apiVersion: apps/v1, kind: Deployment, name: news-service }
  minReplicas: 8
  maxReplicas: 80
  metrics:
    - type: Resource
      resource: { name: cpu, target: { type: Utilization, averageUtilization: 65 } }
    - type: Pods
      pods:
        metric: { name: http_request_duration_p99_seconds }
        target: { type: AverageValue, averageValue: "200m" }
```

## 4. CI/CD Pipeline (GitHub Actions)

```yaml
# .github/workflows/news-service-deploy.yml
name: news-service-ci-cd

on:
  push:
    branches: [main]
    paths: ["services/news-service/**"]
  pull_request:
    paths: ["services/news-service/**"]

permissions:
  id-token: write   # required for AWS OIDC federation, no static keys
  contents: read

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: "20", cache: "npm" }
      - run: npm ci
        working-directory: services/news-service
      - run: npm run lint
        working-directory: services/news-service
      - run: npm run test:unit -- --coverage
        working-directory: services/news-service
      - run: npm run test:integration
        working-directory: services/news-service
      - name: Enforce coverage threshold
        run: npm run test:coverage-check -- --min 85
        working-directory: services/news-service
      - name: SAST scan
        uses: semgrep/semgrep-action@v1
      - name: Dependency scan
        uses: snyk/actions/node@master
        env: { SNYK_TOKEN: "${{ secrets.SNYK_TOKEN }}" }

  build-and-push:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789:role/github-actions-ecr-push
          aws-region: ap-south-1
      - uses: aws-actions/amazon-ecr-login@v2
        id: ecr
      - run: |
          docker build -t ${{ steps.ecr.outputs.registry }}/news-service:${{ github.sha }} \
            services/news-service
          docker push ${{ steps.ecr.outputs.registry }}/news-service:${{ github.sha }}

  deploy-staging:
    needs: build-and-push
    runs-on: ubuntu-latest
    environment: staging
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789:role/github-actions-eks-deploy-staging
          aws-region: ap-south-1
      - run: |
          aws eks update-kubeconfig --name newsbucket-staging
          kubectl set image deployment/news-service \
            news-service=${{ steps.ecr.outputs.registry }}/news-service:${{ github.sha }} \
            -n newsbucket-staging
          kubectl rollout status deployment/news-service -n newsbucket-staging --timeout=180s

  e2e-and-load-test:
    needs: deploy-staging
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npx playwright test --config=e2e/playwright.config.ts
      - run: k6 run performance/news-service-load-test.js

  deploy-production:
    needs: e2e-and-load-test
    runs-on: ubuntu-latest
    environment: production   # requires manual approval, configured in repo settings
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789:role/github-actions-eks-deploy-production
          aws-region: ap-south-1
      - run: |
          aws eks update-kubeconfig --name newsbucket-production
          kubectl set image deployment/news-service \
            news-service=${{ steps.ecr.outputs.registry }}/news-service:${{ github.sha }} \
            -n newsbucket-production
          kubectl rollout status deployment/news-service -n newsbucket-production --timeout=300s
```

## 5. CDN & Edge — Cloudflare

- Cloudflare sits in front of CloudFront/ALB for an additional DDoS-mitigation and WAF layer, plus Cloudflare's Argo Smart Routing for reduced latency to Indian users on last-mile ISPs where AWS's direct edge presence is thinner.
- Cloudflare Workers used for lightweight edge logic: geo/language redirect resolution before the request even reaches Next.js middleware, shaving additional milliseconds off the performance budget defined in Phase 14.

## 6. Monitoring, Logging, Alerting Stack

- **Prometheus:** scrapes every pod's `/metrics` endpoint (Section 3 annotation); federated across the general and AI-worker node pools.
- **Grafana:** dashboards per service plus a unified "Golden Signals" dashboard (latency, traffic, errors, saturation) for on-call use during incidents.
- **Loki:** structured JSON logs shipped via a Fluent Bit DaemonSet on every node, queryable alongside Grafana metrics in the same UI for correlated debugging.
- **Alertmanager rules (excerpt):**

```yaml
groups:
  - name: news-service-slo
    rules:
      - alert: NewsServiceHighErrorRate
        expr: |
          sum(rate(http_requests_total{service="news-service", status=~"5.."}[5m]))
          / sum(rate(http_requests_total{service="news-service"}[5m])) > 0.01
        for: 5m
        labels: { severity: page }
        annotations:
          summary: "news-service error rate above 1% for 5 minutes"

      - alert: BreakingNewsLatencyBudgetBreached
        expr: histogram_quantile(0.95, breaking_news_publish_to_delivery_seconds) > 30
        for: 2m
        labels: { severity: page }
        annotations:
          summary: "Breaking news p95 delivery latency exceeds the 30s NFR"

      - alert: AuroraReplicaLagHigh
        expr: aws_rds_replica_lag_seconds > 5
        for: 3m
        labels: { severity: warn }
```

## 7. Release Strategy

- Rolling deployments (`maxUnavailable: 0`) as the default, giving zero-downtime releases for standard changes.
- Canary releases for ranking-algorithm and AI-model version changes specifically (a small percentage of traffic first, per Phase 8's shadow-deployment policy), gated on the same Golden Signals dashboard plus AI-quality metrics before full rollout.
- Automatic rollback: if the post-deploy error-rate or latency SLO alert fires within 15 minutes of a production deploy, the pipeline automatically reverts to the previous image tag and pages the on-call engineer, rather than waiting for manual detection.

---

*Deployment automation is documented for long-term operability in Phase 16. Proceeding to Phase 16.*
