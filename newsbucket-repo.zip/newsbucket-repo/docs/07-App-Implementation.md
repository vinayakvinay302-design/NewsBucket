# NewsBucket — Phase 7: Mobile & Web App Implementation
**Version 1.0 | Phase 7 of 16**
**Owners: Flutter Lead, React/Next.js Lead**

---

## 1. Scope Note

Phase 2 specified all 81 screens; this phase implements the **shared architecture** and a **representative vertical slice** (Home Feed → Article Detail → Chat with News) at full production quality. Every other screen in the inventory (category feeds, sports hubs, bookmarks, settings, etc.) is built on the exact same three layers shown below — repository → provider/state → widget — so the pattern here is the actual template engineering uses for the remaining 78 screens, not a simplified stand-in.

## 2. Flutter App — Folder Structure

```
lib/
├── main.dart
├── app/
│   ├── app.dart                    # MaterialApp.router root widget
│   ├── router.dart                 # go_router route table
│   └── theme/
│       ├── design_tokens.dart      # generated from Phase 2 token JSON
│       └── app_theme.dart          # Light / Dark / AMOLED ThemeData
├── core/
│   ├── network/
│   │   ├── api_client.dart         # Dio instance, interceptors
│   │   └── auth_interceptor.dart   # attaches JWT, handles refresh-on-401
│   ├── errors/
│   │   └── failure.dart
│   └── storage/
│       └── secure_token_storage.dart
├── features/
│   ├── auth/...
│   ├── feed/
│   │   ├── data/
│   │   │   ├── models/article_model.dart
│   │   │   └── repositories/feed_repository.dart
│   │   ├── application/
│   │   │   └── feed_providers.dart  # Riverpod state
│   │   └── presentation/
│   │       ├── home_feed_screen.dart
│   │       └── widgets/article_card.dart
│   ├── article_detail/...
│   ├── chat_with_news/...
│   ├── sports/...
│   └── settings/...
└── shared/
    └── widgets/
        ├── skeleton_loader.dart
        └── factuality_badge.dart
```

## 3. Networking Layer (Dio + Auth Interceptor)

```dart
// core/network/api_client.dart
import 'package:dio/dio.dart';
import 'auth_interceptor.dart';

class ApiClient {
  final Dio dio;

  ApiClient._(this.dio);

  factory ApiClient.create({required String baseUrl}) {
    final dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 5),
      receiveTimeout: const Duration(seconds: 8),
      headers: {'Content-Type': 'application/json'},
    ));
    dio.interceptors.add(AuthInterceptor(dio));
    dio.interceptors.add(LogInterceptor(
      requestBody: false,
      responseBody: false,
      logPrint: (obj) {}, // routed to structured logger in prod, not stdout
    ));
    return ApiClient._(dio);
  }
}
```

```dart
// core/network/auth_interceptor.dart
import 'package:dio/dio.dart';
import '../storage/secure_token_storage.dart';

/// Attaches the current access token to every request, and transparently
/// refreshes + retries once on a 401 before surfacing the error upstream.
class AuthInterceptor extends Interceptor {
  final Dio _dio;
  final SecureTokenStorage _storage = SecureTokenStorage();
  bool _isRefreshing = false;

  AuthInterceptor(this._dio);

  @override
  Future<void> onRequest(RequestOptions options, RequestInterceptorHandler handler) async {
    final token = await _storage.readAccessToken();
    if (token != null) {
      options.headers['Authorization'] = 'Bearer $token';
    }
    handler.next(options);
  }

  @override
  Future<void> onError(DioException err, ErrorInterceptorHandler handler) async {
    final isAuthError = err.response?.statusCode == 401;
    final alreadyRetried = err.requestOptions.extra['retried'] == true;

    if (isAuthError && !alreadyRetried && !_isRefreshing) {
      _isRefreshing = true;
      try {
        final refreshToken = await _storage.readRefreshToken();
        if (refreshToken == null) {
          _isRefreshing = false;
          return handler.next(err);
        }
        final response = await _dio.post('/v1/auth/refresh',
            data: {'refresh_token': refreshToken});
        await _storage.saveTokens(
          accessToken: response.data['data']['access_token'],
          refreshToken: response.data['data']['refresh_token'],
        );
        final retryOptions = err.requestOptions;
        retryOptions.extra['retried'] = true;
        retryOptions.headers['Authorization'] =
            'Bearer ${response.data['data']['access_token']}';
        final retryResponse = await _dio.fetch(retryOptions);
        _isRefreshing = false;
        return handler.resolve(retryResponse);
      } catch (_) {
        _isRefreshing = false;
        await _storage.clearTokens();
        return handler.next(err); // caller routes to login screen
      }
    }
    handler.next(err);
  }
}
```

## 4. Data Model & Repository

```dart
// features/feed/data/models/article_model.dart
class ArticleSummary {
  final String id;
  final String headline;
  final String? heroImageUrl;
  final String categorySlug;
  final String publisherName;
  final DateTime publishedAt;
  final double? factualityScore;
  final String? biasRating;
  final String oneLineSummary;

  ArticleSummary({
    required this.id,
    required this.headline,
    required this.categorySlug,
    required this.publisherName,
    required this.publishedAt,
    required this.oneLineSummary,
    this.heroImageUrl,
    this.factualityScore,
    this.biasRating,
  });

  factory ArticleSummary.fromJson(Map<String, dynamic> json) {
    return ArticleSummary(
      id: json['id'] as String,
      headline: json['headline'] as String,
      heroImageUrl: json['hero_image_url'] as String?,
      categorySlug: json['category_slug'] as String,
      publisherName: json['publisher_name'] as String,
      publishedAt: DateTime.parse(json['published_at'] as String),
      factualityScore: (json['factuality_score'] as num?)?.toDouble(),
      biasRating: json['bias_rating'] as String?,
      oneLineSummary: json['ai_summary']?['one_line'] as String? ?? '',
    );
  }
}
```

```dart
// features/feed/data/repositories/feed_repository.dart
import '../../../../core/network/api_client.dart';
import '../models/article_model.dart';

class FeedPage {
  final List<ArticleSummary> articles;
  final String? nextCursor;
  FeedPage({required this.articles, required this.nextCursor});
}

class FeedRepository {
  final ApiClient _client;
  FeedRepository(this._client);

  Future<FeedPage> getHomeFeed({String? cursor}) async {
    final response = await _client.dio.get('/v1/feed/home',
        queryParameters: {if (cursor != null) 'cursor': cursor, 'limit': 20});
    final items = (response.data['data'] as List)
        .map((json) => ArticleSummary.fromJson(json as Map<String, dynamic>))
        .toList();
    return FeedPage(
      articles: items,
      nextCursor: response.data['meta']['next_cursor'] as String?,
    );
  }
}
```

## 5. State Management (Riverpod — paginated feed)

```dart
// features/feed/application/feed_providers.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/repositories/feed_repository.dart';
import '../data/models/article_model.dart';

final feedRepositoryProvider = Provider<FeedRepository>((ref) {
  throw UnimplementedError('Overridden in ProviderScope at app bootstrap');
});

class FeedState {
  final List<ArticleSummary> articles;
  final String? nextCursor;
  final bool isLoadingMore;
  final bool isRefreshing;
  final String? errorMessage;

  const FeedState({
    this.articles = const [],
    this.nextCursor,
    this.isLoadingMore = false,
    this.isRefreshing = false,
    this.errorMessage,
  });

  FeedState copyWith({
    List<ArticleSummary>? articles,
    String? nextCursor,
    bool? isLoadingMore,
    bool? isRefreshing,
    String? errorMessage,
  }) {
    return FeedState(
      articles: articles ?? this.articles,
      nextCursor: nextCursor ?? this.nextCursor,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
      isRefreshing: isRefreshing ?? this.isRefreshing,
      errorMessage: errorMessage,
    );
  }
}

class HomeFeedNotifier extends StateNotifier<FeedState> {
  final FeedRepository _repository;
  bool _hasMore = true;

  HomeFeedNotifier(this._repository) : super(const FeedState()) {
    loadInitial();
  }

  Future<void> loadInitial() async {
    state = state.copyWith(isRefreshing: true, errorMessage: null);
    try {
      final page = await _repository.getHomeFeed();
      _hasMore = page.nextCursor != null;
      state = FeedState(
        articles: page.articles,
        nextCursor: page.nextCursor,
        isRefreshing: false,
      );
    } catch (e) {
      state = state.copyWith(isRefreshing: false, errorMessage: e.toString());
    }
  }

  Future<void> loadMore() async {
    if (!_hasMore || state.isLoadingMore) return;
    state = state.copyWith(isLoadingMore: true);
    try {
      final page = await _repository.getHomeFeed(cursor: state.nextCursor);
      _hasMore = page.nextCursor != null;
      state = state.copyWith(
        articles: [...state.articles, ...page.articles],
        nextCursor: page.nextCursor,
        isLoadingMore: false,
      );
    } catch (e) {
      state = state.copyWith(isLoadingMore: false, errorMessage: e.toString());
    }
  }
}

final homeFeedProvider =
    StateNotifierProvider<HomeFeedNotifier, FeedState>((ref) {
  return HomeFeedNotifier(ref.watch(feedRepositoryProvider));
});
```

## 6. Home Feed Screen (Production Widget)

```dart
// features/feed/presentation/home_feed_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../application/feed_providers.dart';
import 'widgets/article_card.dart';
import '../../../shared/widgets/skeleton_loader.dart';

class HomeFeedScreen extends ConsumerStatefulWidget {
  const HomeFeedScreen({super.key});

  @override
  ConsumerState<HomeFeedScreen> createState() => _HomeFeedScreenState();
}

class _HomeFeedScreenState extends ConsumerState<HomeFeedScreen> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (_scrollController.position.pixels >
        _scrollController.position.maxScrollExtent - 800) {
      ref.read(homeFeedProvider.notifier).loadMore();
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final feedState = ref.watch(homeFeedProvider);

    if (feedState.isRefreshing && feedState.articles.isEmpty) {
      return const SkeletonLoader(itemCount: 6);
    }

    if (feedState.errorMessage != null && feedState.articles.isEmpty) {
      return _ErrorState(
        onRetry: () => ref.read(homeFeedProvider.notifier).loadInitial(),
      );
    }

    return RefreshIndicator(
      onRefresh: () => ref.read(homeFeedProvider.notifier).loadInitial(),
      child: ListView.separated(
        controller: _scrollController,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        itemCount: feedState.articles.length + (feedState.isLoadingMore ? 1 : 0),
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          if (index >= feedState.articles.length) {
            return const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
            );
          }
          final article = feedState.articles[index];
          return ArticleCard(
            article: article,
            heroTag: 'article-hero-${article.id}',
            onTap: () => Navigator.of(context).pushNamed(
              '/article/${article.id}',
              arguments: {'heroTag': 'article-hero-${article.id}'},
            ),
          );
        },
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final VoidCallback onRetry;
  const _ErrorState({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off_rounded, size: 48),
          const SizedBox(height: 12),
          Text('Couldn\'t load your feed', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          FilledButton(onPressed: onRetry, child: const Text('Retry')),
        ],
      ),
    );
  }
}
```

## 7. Article Card Widget (Trust-Transparent Feed Card, per Phase 2 spec)

```dart
// features/feed/presentation/widgets/article_card.dart
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../data/models/article_model.dart';
import '../../../../shared/widgets/factuality_badge.dart';

class ArticleCard extends StatelessWidget {
  final ArticleSummary article;
  final String heroTag;
  final VoidCallback onTap;

  const ArticleCard({
    super.key,
    required this.article,
    required this.heroTag,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Semantics(
      button: true,
      label: '${article.headline}, from ${article.publisherName}',
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (article.heroImageUrl != null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Hero(
                    tag: heroTag,
                    child: AspectRatio(
                      aspectRatio: 16 / 9,
                      child: CachedNetworkImage(
                        imageUrl: article.heroImageUrl!,
                        fit: BoxFit.cover,
                        placeholder: (_, __) => Container(color: theme.colorScheme.surfaceVariant),
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              Text(
                article.categorySlug.toUpperCase(),
                style: theme.textTheme.labelSmall?.copyWith(
                  letterSpacing: 0.6,
                  color: theme.colorScheme.primary,
                ),
              ),
              const SizedBox(height: 4),
              Text(article.headline, style: theme.textTheme.titleLarge, maxLines: 3),
              const SizedBox(height: 6),
              Text(article.oneLineSummary,
                  style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant)),
              const SizedBox(height: 10),
              Row(
                children: [
                  Text(article.publisherName, style: theme.textTheme.labelMedium),
                  const SizedBox(width: 8),
                  Text('•', style: theme.textTheme.labelMedium),
                  const SizedBox(width: 8),
                  Text(_relativeTime(article.publishedAt), style: theme.textTheme.labelMedium),
                  const Spacer(),
                  if (article.factualityScore != null)
                    FactualityBadge(score: article.factualityScore!),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _relativeTime(DateTime time) {
    final diff = DateTime.now().difference(time);
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}
```

## 8. Next.js Web — Article Detail Page (App Router, Server Component)

```tsx
// app/[lang]/article/[id]/page.tsx
import { notFound } from 'next/navigation';
import { ArticleHeader } from '@/components/article/article-header';
import { AiSummaryPanel } from '@/components/article/ai-summary-panel';
import { ChatWithNewsButton } from '@/components/article/chat-with-news-button';
import { SourceComparisonRail } from '@/components/article/source-comparison-rail';
import { fetchArticle } from '@/lib/api/articles';

interface PageProps {
  params: { lang: string; id: string };
}

export async function generateMetadata({ params }: PageProps) {
  const article = await fetchArticle(params.id, params.lang);
  if (!article) return {};
  return {
    title: `${article.headline} | NewsBucket`,
    description: article.aiSummary.oneLine,
    openGraph: {
      images: article.heroImageUrl ? [article.heroImageUrl] : [],
    },
  };
}

export default async function ArticleDetailPage({ params }: PageProps) {
  const article = await fetchArticle(params.id, params.lang);
  if (!article) notFound();

  return (
    <article className="mx-auto max-w-[720px] px-4 py-6">
      <ArticleHeader article={article} />
      <AiSummaryPanel summary={article.aiSummary} />
      <div
        className="prose prose-neutral mt-6 dark:prose-invert"
        dangerouslySetInnerHTML={{ __html: article.bodyHtml }}
      />
      <ChatWithNewsButton articleId={article.id} />
      <SourceComparisonRail clusterId={article.clusterId} />
    </article>
  );
}
```

```ts
// lib/api/articles.ts
import { cache } from 'react';

export interface AiSummary {
  oneLine: string;
  bullets: string[];
  eli5: string;
}

export interface Article {
  id: string;
  headline: string;
  bodyHtml: string;
  heroImageUrl?: string;
  clusterId: string;
  aiSummary: AiSummary;
  factualityScore?: number;
  biasRating?: string;
}

// react `cache()` dedupes this fetch across generateMetadata + the page render
export const fetchArticle = cache(async (id: string, lang: string): Promise<Article | null> => {
  const res = await fetch(`${process.env.NEWSBUCKET_API_URL}/v1/articles/${id}?lang=${lang}`, {
    next: { revalidate: 300 }, // 5-minute ISR, matches Phase 4 cache policy
  });
  if (res.status === 404) return null;
  if (!res.ok) throw new Error(`Failed to fetch article ${id}: ${res.status}`);
  const json = await res.json();
  return {
    id: json.data.id,
    headline: json.data.headline,
    bodyHtml: json.data.body_html,
    heroImageUrl: json.data.hero_image_url,
    clusterId: json.data.cluster_id,
    aiSummary: {
      oneLine: json.data.ai_summary.one_line,
      bullets: json.data.ai_summary.bullets,
      eli5: json.data.ai_summary.eli5,
    },
    factualityScore: json.data.factuality_score,
    biasRating: json.data.bias_rating,
  };
});
```

## 9. Cross-Platform Consistency Rule

- Both clients consume the exact same `/v1/articles/:id` contract from Phase 6 — no client-specific backend endpoints, preventing feature drift between mobile and web.
- Design tokens (Section 2 folder structure) are generated from the same source JSON referenced in Phase 2, so `theme.colorScheme.primary` in Flutter and the Tailwind `primary` class in Next.js resolve to the identical hex value.

---

*This vertical slice is the implementation template for Phase 8 (AI Feature Integration) to build against. Proceeding to Phase 8.*
