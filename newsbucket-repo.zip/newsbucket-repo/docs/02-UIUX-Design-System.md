# NewsBucket — Phase 2: UI/UX Planning & Design System
**Version 1.0 | Phase 2 of 16 | Line-by-Line Format**
**Owners: Senior UI/UX Designer, Brand Designer, Product Manager**

---

## 1. Design Philosophy

- Premium feels like Apple: generous white space, restrained color, confident typography, no visual clutter.
- Structure feels like Material Design 3: adaptive color system, elevation, motion with purpose.
- Trust feels visible: sourcing, bias, and factuality are never hidden behind menus.
- Speed feels like a design decision, not just an engineering one: skeleton screens, optimistic UI, no spinners longer than 300ms.
- Every screen has one primary action — never two competing calls-to-action.
- Never make the user think. Every icon has a label the first time it appears.
- Motion always has meaning: it shows relationship, hierarchy, or causality — never decoration for its own sake.

## 2. Complete Screen Inventory

**Onboarding & Auth**
1. Splash screen (animated logo, brand reveal, under 400ms).
2. Onboarding carousel (3 screens: Personalized, Trustworthy, Multilingual).
3. Language selection screen.
4. Interest selection screen (category chips, minimum 5 selections).
5. Login screen.
6. Signup screen.
7. OTP verification screen.
8. Forgot password / account recovery screen.

**Core Navigation**
9. Home feed (For You).
10. Breaking News feed.
11. Trending feed.
12. Local News feed (location-based).
13. Following feed (followed topics/sources/authors).
14. Category browse screen (grid of all categories).
15. Search screen (with AI-assisted query suggestions).
16. Search results screen.

**Category Feeds** (each uses the shared Category Feed template)
17. India.
18. World.
19. Technology.
20. AI.
21. Science.
22. Business.
23. Politics.
24. Education.
25. Jobs.
26. Weather.
27. Entertainment.
28. Movies.
29. OTT.
30. Crypto.
31. Stock Market.
32. Gold & Silver.

**Sports Hub** (shared Sports template + sport-specific stat layouts)
33. Sports home (all sports overview).
34. Cricket hub (matches, series, IPL).
35. Football hub (FIFA, UEFA, Champions League, Premier League).
36. NBA hub.
37. NFL hub.
38. Formula 1 hub.
39. Kabaddi hub.
40. Chess hub.
41. Tennis hub.
42. Gaming/esports hub.
43. Live match detail screen (scorecard, commentary, stats tabs).
44. Player profile screen.
45. Club/team profile screen.
46. Standings/table screen.
47. Fixtures & results screen.
48. Fantasy stats screen.

**Article Experience**
49. Article detail screen (full read).
50. AI Summary panel (1-line / bullets / full / ELI5 toggle).
51. Timeline view (for evolving stories).
52. Source comparison view ("Other outlets covering this").
53. Chat with News screen (RAG Q&A on the article).
54. Bias & Factuality detail sheet.
55. Related articles rail.
56. Share sheet.
57. Audio/podcast player (mini + full-screen).

**Personal**
58. Bookmarks screen.
59. Read history screen.
60. Downloads (offline reading) screen.
61. Profile screen.
62. Edit profile screen.
63. Notification preferences screen.
64. Settings home.
65. Theme settings (Light / Dark / AMOLED).
66. Language & translation settings.
67. Accessibility settings (font size, contrast, screen reader).
68. Data & privacy settings.
69. Premium/subscription screen.
70. Subscription management screen.
71. Payment method screen.
72. Help & support screen.
73. Feedback screen.
74. About screen.
75. Privacy policy screen.
76. Terms of service screen.

**System States** (apply to every screen)
77. Empty state.
78. Error state (network, server, not found).
79. Offline state.
80. Loading/skeleton state.
81. Permission request state (location, notifications).

## 3. Navigation Architecture

- Primary navigation: bottom tab bar on mobile, left rail on tablet/desktop.
- 5 primary tabs: Home, Discover (categories), Sports, Bookmarks, Profile.
- Search is globally accessible via a persistent top-bar icon, not a 6th tab.
- Article detail opens as a full-screen push (mobile) or a right-side panel (desktop/tablet, master-detail pattern).
- Chat with News opens as a bottom sheet that expands to full screen — keeps article context visible during the transition.
- Settings is nested under Profile, never a top-level tab.
- Breaking news alerts appear as a dismissible top banner, not a full-screen interrupt.
- Back navigation is always predictable: system back always returns to the previous scroll position, never resets to top.

## 4. Design System — Color Palette

**Light theme**
- Background: #FFFFFF (primary), #F7F8FA (secondary/surface).
- Text: #1A1D21 (primary), #5B6470 (secondary), #8B93A1 (tertiary/hint).
- Brand primary: #1652F0 (NewsBucket Blue) — used for primary actions and active states only.
- Brand accent: #FF6B35 (Signal Orange) — reserved exclusively for Breaking News and live indicators.

**Dark theme**
- Background: #121316 (primary), #1B1D21 (secondary/surface).
- Text: #F2F3F5 (primary), #A6ADB8 (secondary), #6E7580 (tertiary/hint).
- Brand primary: #5B8CFF (lightened for dark-mode contrast).
- Brand accent: #FF8659 (lightened Signal Orange).

**AMOLED theme**
- Background: #000000 (true black, all surfaces).
- Elevation is shown via a 1px hairline border (#232323), never a lighter fill — preserves true black for OLED power savings.
- Text and accent colors: same as Dark theme.

**Semantic / trust colors** (identical across all themes for consistency of meaning)
- Factuality — High: #1B9E5B. Medium: #E8A93A. Low: #E5484D.
- Bias meter — Left: #3B82F6. Center: #8B93A1. Right: #E5484D.
- Success: #1B9E5B. Warning: #E8A93A. Error: #E5484D. Info: #1652F0.

**Accessibility rule**
- Every text/background pair meets WCAG 2.1 AA contrast (4.5:1 for body text, 3:1 for large text) in all three themes.

## 5. Typography

- Primary typeface: Inter (Latin scripts) — geometric, highly legible at small sizes, wide language support.
- Vernacular typeface: Noto Sans (per-script variants: Devanagari, Tamil, Telugu, Kannada, Malayalam, Bengali, Gujarati, Gurmukhi) — ensures visual consistency across scripts.
- Display / headline (article titles, hero cards): 28px / 34px line-height / weight 700.
- Title (section headers, card titles): 20px / 26px / weight 600.
- Body (article text, feed summaries): 16px / 24px / weight 400.
- Caption (metadata, timestamps, source labels): 13px / 18px / weight 500.
- Overline (category tags, labels): 11px / 14px / weight 600 / uppercase / letter-spacing 0.06em.
- All type scales support dynamic scaling from 85% to 200% via OS-level accessibility settings without breaking layout.

## 6. Spacing & Layout Grid

- Base spacing unit: 4px.
- Standard spacing scale: 4, 8, 12, 16, 24, 32, 48, 64px.
- Mobile content margin: 16px from screen edge.
- Card internal padding: 16px.
- Vertical rhythm between feed cards: 12px.
- Tablet: 2-column grid, 24px gutters, 24px margins.
- Desktop: 12-column grid, max content width 1280px, 32px gutters, master-detail split at 60/40.
- Touch targets: minimum 48x48px on mobile, no exceptions (WCAG + Material 3 requirement).

## 7. Iconography

- Icon style: single-weight line icons at rest, filled/duotone on active state — mirrors iOS/Material 3 hybrid convention.
- Icon grid: 24x24px standard, 20x20px compact (inline with text), 32x32px for primary tab bar.
- Custom icon set required for: Breaking News (pulse/signal mark), Factuality meter, Bias meter, Chat-with-News (distinct from generic chat), Trust Score badge.
- All icons ship as SVG with semantic ARIA labels; no icon-only buttons without an accessible label.

## 8. Motion & Micro-interactions

- Standard transition duration: 200ms for small UI changes, 300ms for screen transitions, easing: standard Material 3 emphasized curve.
- Card entry animation: subtle fade + 8px upward slide, staggered 40ms per card, capped at first 6 visible cards (avoid jank on long lists).
- Bookmark action: icon fill animates with a small bounce (120ms) — confirms action without a toast.
- Pull-to-refresh: custom NewsBucket mark animates (not a generic spinner) — reinforces brand at the single most-repeated gesture in the app.
- Live score / breaking updates: number changes animate with a brief highlight flash (background pulse, 400ms) so the update is noticed but not jarring.
- Skeleton loading: shimmer effect on placeholder cards, matches exact final layout dimensions to prevent layout shift (CLS = 0).
- Page transitions: shared-element transition from feed card image/title to article detail hero — reduces perceived load time.
- Respect OS "reduce motion" accessibility setting: all non-essential animation disables automatically.

## 9. Accessibility (WCAG 2.1 AA)

- Full screen-reader support (VoiceOver / TalkBack) with semantic labels on every interactive element.
- Dynamic Type / font scaling support from 85%–200% without truncation or overlap.
- Minimum contrast ratios enforced across all three themes (see Color Palette).
- All touch targets ≥ 48x48px.
- Focus order follows logical reading order; visible focus indicators for keyboard/switch-control navigation on web and tablet.
- Captions/transcripts provided for all audio (TTS briefings, podcasts) and video content.
- Color is never the only signal — bias/factuality indicators always pair color with an icon and text label.
- "Reduce motion" and "high contrast" OS settings respected app-wide.
- Voice narration available as a first-class feature, not an accessibility afterthought — benefits Persona 2 (Sunita) and Persona 5 (Mahesh) alike.

## 10. Theming — Light / Dark / AMOLED

- Theme selectable manually in Settings, or set to "Follow System."
- AMOLED mode is a distinct third option (not just "Dark"), specifically for OLED battery savings and true-black preference.
- Theme switch applies instantly with a smooth 200ms cross-fade, no flash of unstyled content.
- All brand and semantic colors are defined as design tokens (not hardcoded), so a 4th theme (e.g., a future seasonal or high-contrast theme) can be added without re-touching component code.

## 11. Responsive Layouts

- **Mobile (< 600px):** single-column feed, bottom tab bar, full-screen article push.
- **Tablet (600–1024px):** 2-column feed grid, side navigation rail (collapsible), master-detail article view.
- **Desktop / Web (> 1024px):** 3-zone layout — left nav rail, center feed (max 720px reading width for typography comfort), right rail for trending/market widgets.
- **Foldable devices:** feed reflows to use the full unfolded width as a 2-pane master-detail layout automatically.
- All breakpoints defined as design tokens shared between Flutter and Next.js teams to guarantee visual parity.

## 12. Key Screen Specifications

**Home Feed**
- Top: persistent search bar + location/language quick-switch + notification bell.
- Below top bar: horizontally scrollable rail — Breaking, For You, Trending, Local, Following.
- Feed cards: image (16:9), category tag (overline style), headline (title style), 1-line AI summary, source + timestamp + factuality badge, action row (bookmark, share, chat-with-news icon).
- Every 5th card: a "Why am I seeing this" ghost-link in caption style — low-emphasis but always present.

**Article Detail**
- Hero image with shared-element transition from the feed card.
- Headline, byline, publish/updated timestamp, source logo, factuality + bias badges inline.
- AI Summary panel pinned near the top with a 3-way toggle: Bullets / Full / ELI5.
- Full article body below, with inline "Chat with News" floating action button.
- "Other outlets covering this" horizontal rail before related articles.
- Bottom: audio narration mini-player, persistent while scrolling.

**Chat with News**
- Opens as a bottom sheet anchored to the article, expandable to full screen.
- Every AI answer shows inline citation markers linking back to the exact source sentence.
- Explicit "Not enough information in the sources to answer that" state — never a fabricated answer.

**Live Match Detail (Sports)**
- Sticky scoreboard header while scrolling through commentary/stats tabs.
- Real-time updates via WebSocket with the number-flash micro-interaction described in Section 8.

## 13. Design System Governance

- All tokens (color, type, spacing, motion durations, breakpoints) stored in a single shared JSON design-token source.
- Tokens consumed by Flutter (via generated Dart theme classes) and Next.js (via generated CSS variables / Tailwind config) — guarantees pixel-parity across platforms, single source of truth.
- Figma component library mirrors the token source exactly; no designer manually picks a color/spacing value outside the token set.
- Every new component requires: light/dark/AMOLED variants, RTL variant (for Urdu), and an accessibility annotation before dev handoff.

---

*This design system is the visual and structural foundation for Phase 3 (Technology Stack) and Phase 7 (Mobile App Screens). Proceeding to Phase 3 upon your approval.*
