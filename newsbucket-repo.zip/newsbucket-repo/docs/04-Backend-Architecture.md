# NewsBucket — Phase 4: Backend Microservices Architecture
**Version 1.0 | Phase 4 of 16**
**Owners: Backend Architect, Cloud Architect, Security Engineer**

---

## 1. Architecture Style

- Domain-driven microservices, each owning its own database schema (schema-per-service within shared Postgres clusters, not shared tables across services).
- Communication: synchronous REST/gRPC for request/response paths, asynchronous SQS/SNS events for cross-service side effects.
- Every service is independently deployable, independently scalable, and owns its own CI/CD pipeline stage.
- Services never call another service's database directly — only through its published API or events.

## 2. Service Inventory & Responsibilities

**API Gateway**
- Single entry point for all client traffic (Flutter, Next.js, Admin dashboard).
- Responsibilities: JWT validation, rate limiting, request routing, request/response logging, API versioning (`/v1/...`), CORS policy enforcement.
- Technology: Kong on EKS, backed by AWS WAF for L7 protection (SQLi/XSS/bot patterns) in front of it.

**Authentication Service**
- Verifies Firebase ID tokens on first login, issues NewsBucket JWT access tokens (15 min TTL) and refresh tokens (30 day TTL, rotated on use).
- Manages user roles/claims (user, premium_user, moderator, admin).
- Owns: `users`, `refresh_tokens`, `user_roles` tables.

**News Service**
- System of record for articles, sources, categories, and source clusters.
- Exposes CRUD for internal ingestion/admin use, and read APIs for the feed.
- Owns: `articles`, `sources`, `categories`, `article_clusters` tables.

**Recommendation Service**
- Computes personalized feed ranking per user request.
- Combines: explicit interests, implicit behavior signals (from Analytics Service via event stream), freshness decay, and diversity injection.
- Stateless compute layer reading precomputed features from Redis/feature store; retrains ranking model offline (see Phase 8).

**AI Service**
- Wraps all AI capabilities: summarization, timeline generation, entity extraction, bias/factuality scoring, translation, Chat-with-News (RAG), fake-news detection.
- Internally decomposed into sub-workers consuming from SQS queues (see Phase 8 for full pipeline detail); exposes a synchronous API for on-demand chat queries only.

**Sports Service**
- Ingests third-party sports data providers (see Phase 10), normalizes into a common schema, serves live scores/fixtures/standings/player-club profiles.
- Publishes live-update events to the Notification Service's WebSocket layer.

**Notification Service**
- Owns the WebSocket gateway (Socket.IO + Redis adapter for multi-instance pub/sub) for real-time breaking news and live scores.
- Owns FCM topic/token management for push notifications.
- Consumes events from News, Sports, and AI services to decide what to push and to whom, respecting user notification preferences.

**Analytics Service**
- Ingests client-side and server-side events (feed impressions, clicks, dwell time, shares) via a lightweight event-collection API, batches into Kinesis Firehose → S3 → data warehouse (see Phase 6 Data Engineer notes / Phase 9).
- Serves aggregated KPIs to the Admin Dashboard.

**Search Service**
- Thin API layer over Elasticsearch/OpenSearch for full-text search, related-article queries, and trending-topic aggregation.
- Consumes an index-update event whenever News Service publishes/updates an article.

**Media Service**
- Handles image upload/processing (resize, format conversion to WebP/AVIF, moderation scan) and audio file generation/storage for TTS and podcasts.
- Owns S3 buckets and CloudFront signed-URL issuance for access-controlled media.

**Admin Service**
- Backs the Admin Dashboard (Phase 11): user management, publisher management, ad management, moderation queue, revenue/subscription views.
- Enforces role-based access control strictly separate from the consumer-facing Authentication Service's token scope.

**Moderation Service**
- Consumes flagged-content events (from AI Service's fake-news/bias detectors, or user reports) into a moderation queue.
- Provides moderator workflows: approve, correct, retract, ban-source, with a full audit trail.

**Logging Service (cross-cutting, not a domain service)**
- Every service ships structured JSON logs to Grafana Loki via a sidecar/Fluent Bit DaemonSet — not a bespoke service to call.

**Monitoring Service (cross-cutting, not a domain service)**
- Prometheus scrapes `/metrics` from every pod; Grafana dashboards and Alertmanager rules live in a shared, version-controlled repo.

## 3. Communication Patterns

- **Synchronous (REST/gRPC):** client-facing reads (feed, article detail, search, chat) — needs immediate response.
- **Asynchronous (SQS/SNS events):** article-ingested → triggers AI Service (summarize, extract entities, score) and Search Service (index) in parallel; user-action events → Analytics Service; moderation-flag events → Moderation Service.
- **Event naming convention:** `domain.entity.action` (e.g., `news.article.published`, `sports.match.score_updated`) — versioned schema registry (JSON Schema) enforced at publish time to prevent breaking consumers.
- **Idempotency:** every event carries a unique `event_id`; consumers deduplicate via a short-TTL Redis SETNX check before processing, protecting against SQS at-least-once delivery causing double-processing.

## 4. Caching Strategy

- **Feed responses:** cached per-user for 30 seconds in Redis (short TTL — balances personalization freshness against read load during traffic spikes).
- **Article detail:** cached for 5 minutes, invalidated immediately on correction/retraction events (correctness overrides cache TTL).
- **Category/trending pages:** cached at CDN edge (CloudFront) for 60 seconds, since these are not user-personalized.
- **Search results:** cached for 60 seconds keyed by normalized query + filters.
- **Live scores:** never cached server-side beyond the in-memory pub/sub fanout; always pushed, not polled, to connected clients.

## 5. Rate Limiting

- Per-user, per-IP, and per-API-key tiers enforced at the API Gateway using a token-bucket algorithm backed by Redis.
- Anonymous/unauthenticated reads: 60 requests/minute/IP.
- Authenticated users: 300 requests/minute/user.
- Chat-with-News (AI-cost-sensitive endpoint): 20 requests/minute/user on free tier, 100/minute on Premium.
- Admin/internal service-to-service calls: exempted from public rate limits via mTLS-authenticated internal network path, but still subject to circuit-breaker protection.

## 6. Load Balancing & Auto-Scaling

- AWS Application Load Balancer in front of the API Gateway layer; Kubernetes Service (ClusterIP) + Ingress for internal routing to each microservice's pods.
- Horizontal Pod Autoscaler per service, scaling on CPU/memory plus custom Prometheus metrics (queue depth for AI Service workers, WebSocket connection count for Notification Service).
- Breaking-news traffic spike playbook: pre-warmed scaling policy triggers on a "breaking news published" event itself (proactive scale-up), not just reactive metric breach, since breaking-news read spikes happen faster than standard HPA reaction time.
- Database read scaling via Aurora PostgreSQL read replicas, with the Recommendation and News read paths routed to replicas; all writes go to the primary.

## 7. Background Workers & Queues

- **Ingestion workers:** pull from RSS/publisher/government/sports/weather/finance sources on schedules (see Phase 9), push raw articles to an SQS ingestion queue.
- **AI processing workers:** consume the ingestion queue, run summarization/entity-extraction/bias-scoring/translation, publish `article.enriched` event.
- **Notification fan-out workers:** consume `article.published` (breaking-priority) events, resolve subscriber topics, dispatch via FCM in batches.
- **Digest/briefing workers:** scheduled (cron-based, via Kubernetes CronJob) daily/weekly job that generates each user's personalized audio briefing and podcast feed.
- Dead-letter queues configured on every SQS queue; failed messages older than 3 retries route to a DLQ monitored by an Alertmanager rule paging on-call.

## 8. Data Consistency Model

- Strong consistency (synchronous transaction) within a single service's own database — e.g., subscription state changes in the Authentication/Admin domain.
- Eventual consistency across services via the event bus — e.g., an article being flagged by Moderation Service takes up to a few seconds to disappear from Search/Recommendation results; acceptable per the NFRs, and monitored via a consistency-lag SLO.
- Saga pattern (choreography-based, event-driven) used for the one genuinely multi-service transaction in the system: Premium subscription purchase (Admin/Billing → Authentication role update → Notification welcome message), with compensating events on failure at any step.

---

*This architecture is the foundation for Phase 5 (Database Schema). Proceeding to Phase 5.*
