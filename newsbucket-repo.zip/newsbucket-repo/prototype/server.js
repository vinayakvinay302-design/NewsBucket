// server.js
// A dependency-free Node.js HTTP server that implements a real, working
// subset of the Phase 6 API contract against the Phase 5-shaped seed data,
// and serves the Phase 2 design-system UI. Run with: node server.js
// No npm install required -- uses only Node's standard library on purpose,
// so this runs identically in any environment without a package registry.

const http = require('http');
const fs = require('fs');
const path = require('path');
const { articles, publishers } = require('./data/seed');

const PORT = process.env.PORT || 8080;
const PUBLIC_DIR = path.join(__dirname, 'public');

// ---- Small helpers -------------------------------------------------------

function sendJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload),
    'Access-Control-Allow-Origin': '*',
  });
  res.end(payload);
}

function envelope(data, meta = {}) {
  return { data, meta: { request_id: cryptoRandomId(), ...meta } };
}

function errorEnvelope(code, message) {
  return { error: { code, message, request_id: cryptoRandomId() } };
}

function cryptoRandomId() {
  return 'req_' + Math.random().toString(36).slice(2, 12);
}

function articleToFeedCard(a) {
  return {
    id: a.id,
    headline: a.headline,
    hero_image_url: a.hero_image_url,
    category_slug: a.category.slug,
    publisher_name: a.publisher.name,
    published_at: a.published_at,
    factuality_score: a.factuality_score,
    bias_rating: a.bias_rating,
    is_breaking: a.is_breaking,
    ai_summary: { one_line: a.ai_summary.one_line },
  };
}

function articleToDetail(a) {
  return {
    id: a.id,
    headline: a.headline,
    body_html: '<p>' + a.body_text.replace(/\n\n/g, '</p><p>') + '</p>',
    hero_image_url: a.hero_image_url,
    author_name: a.author_name,
    publisher: {
      id: a.publisher.id,
      name: a.publisher.name,
      trust_score: a.publisher.trust_score,
      bias_rating: a.publisher.bias_rating,
      is_verified_partner: a.publisher.is_verified_partner,
    },
    cluster_id: a.cluster_id,
    published_at: a.published_at,
    factuality_score: a.factuality_score,
    bias_rating: a.bias_rating,
    ai_summary: a.ai_summary,
  };
}

// ---- Grounded "Chat with News" logic -------------------------------------
// This is a real, working implementation of the grounding + refusal
// contract defined in Phase 8/13: it only answers from the article's own
// body_text (plus its cluster siblings), and explicitly refuses when the
// text doesn't contain information relevant to the question, rather than
// fabricating an answer. In production this role is played by an LLM with
// the system prompt from Phase 8 Section 3; here the same *contract* is
// implemented with transparent, inspectable keyword-grounding so the
// behavior is genuinely real and genuinely runnable without an API key.

function answerFromSources(question, sourceArticles) {
  const REFUSAL = "I don't have enough information in these sources to answer that.";
  const questionWords = question
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 3 && !STOPWORDS.has(w));

  if (questionWords.length === 0) {
    return { answer: REFUSAL, citations: [], grounded: false };
  }

  const scored = sourceArticles.map((src, idx) => {
    const sentences = src.body_text.split(/(?<=[.!?])\s+/);
    const hits = sentences
      .map((s) => ({
        sentence: s,
        score: questionWords.reduce(
          (acc, w) => acc + (s.toLowerCase().includes(w) ? 1 : 0),
          0,
        ),
      }))
      .filter((h) => h.score > 0)
      .sort((a, b) => b.score - a.score);
    return { idx, src, hits };
  });

  // Require at least 2 distinct keyword matches in a single sentence (or all
  // of the question's keywords, if the question only has 1) before treating
  // it as real grounding -- a single incidental word overlap (e.g. "next" in
  // both the question and an unrelated sentence) must not be enough to
  // fabricate a confident-looking answer. This mirrors the production LLM
  // grounding contract in Phase 8: prefer an honest refusal over a shaky,
  // weakly-supported answer.
  const minScore = Math.min(2, questionWords.length);
  const withHits = scored
    .map((s) => ({ ...s, hits: s.hits.filter((h) => h.score >= minScore) }))
    .filter((s) => s.hits.length > 0);

  if (withHits.length === 0) {
    return { answer: REFUSAL, citations: [], grounded: false };
  }

  const parts = [];
  const citations = [];
  withHits.forEach(({ idx, src, hits }) => {
    const best = hits[0].sentence.trim();
    parts.push(`${best} [Source ${idx + 1}]`);
    citations.push({
      source_article_id: src.id,
      publisher_name: src.publisher.name,
      excerpt: best.slice(0, 180),
    });
  });

  return { answer: parts.join(' '), citations, grounded: true };
}

const STOPWORDS = new Set([
  'what', 'when', 'where', 'which', 'this', 'that', 'about', 'will', 'does',
  'have', 'their', 'they', 'there', 'from', 'with', 'been', 'were', 'happen',
]);

// ---- Static file serving --------------------------------------------------

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml' };

function serveStatic(req, res) {
  let filePath = req.url === '/' ? '/index.html' : req.url;
  filePath = path.join(PUBLIC_DIR, filePath.split('?')[0]);
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }
  fs.readFile(filePath, (err, content) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

// ---- Route handling ---------------------------------------------------

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const parts = url.pathname.split('/').filter(Boolean);

  // GET /v1/feed/home
  if (req.method === 'GET' && url.pathname === '/v1/feed/home') {
    const cards = articles
      .slice()
      .sort((a, b) => new Date(b.published_at) - new Date(a.published_at))
      .map(articleToFeedCard);
    return sendJson(res, 200, envelope(cards, { next_cursor: null }));
  }

  // GET /v1/articles/:id
  if (req.method === 'GET' && parts[0] === 'v1' && parts[1] === 'articles' && parts.length === 3) {
    const article = articles.find((a) => a.id === parts[2]);
    if (!article) return sendJson(res, 404, errorEnvelope('ARTICLE_NOT_FOUND', 'Article not found.'));
    return sendJson(res, 200, envelope(articleToDetail(article)));
  }

  // GET /v1/articles/:id/sources
  if (req.method === 'GET' && parts[0] === 'v1' && parts[1] === 'articles' && parts[3] === 'sources') {
    const article = articles.find((a) => a.id === parts[2]);
    if (!article) return sendJson(res, 404, errorEnvelope('ARTICLE_NOT_FOUND', 'Article not found.'));
    const cluster = article.cluster_id
      ? articles.filter((a) => a.cluster_id === article.cluster_id && a.id !== article.id)
      : [];
    return sendJson(res, 200, envelope(cluster.map(articleToFeedCard)));
  }

  // POST /v1/articles/:id/chat
  if (req.method === 'POST' && parts[0] === 'v1' && parts[1] === 'articles' && parts[3] === 'chat') {
    const article = articles.find((a) => a.id === parts[2]);
    if (!article) return sendJson(res, 404, errorEnvelope('ARTICLE_NOT_FOUND', 'Article not found.'));

    let body = '';
    req.on('data', (chunk) => (body += chunk));
    req.on('end', () => {
      let question = '';
      try { question = JSON.parse(body || '{}').question || ''; } catch (_) {}
      const clusterSiblings = article.cluster_id
        ? articles.filter((a) => a.cluster_id === article.cluster_id && a.id !== article.id)
        : [];
      const sources = [article, ...clusterSiblings];
      const result = answerFromSources(question, sources);
      return sendJson(res, 200, envelope(result));
    });
    return;
  }

  // Fallback to static file serving for the UI
  return serveStatic(req, res);
});

server.listen(PORT, () => {
  console.log(`NewsBucket prototype running at http://localhost:${PORT}`);
  console.log(`API:  http://localhost:${PORT}/v1/feed/home`);
  console.log(`UI:   http://localhost:${PORT}/`);
});
