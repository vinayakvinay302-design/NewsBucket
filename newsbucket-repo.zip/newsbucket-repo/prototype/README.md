# NewsBucket Prototype — Run It Yourself

This is a real, working prototype of the core NewsBucket experience: a live
API server (Node.js, zero dependencies) implementing a subset of the Phase 6
API contract, serving the Phase 2 design system UI, with a genuinely working
grounded "Chat with News" implementation (real grounding + refusal logic,
not a canned demo response).

## Run it

```
node server.js
```

Then open http://localhost:8080 in your browser.

No `npm install` needed — deliberately built on Node's standard library only,
so it runs identically anywhere Node is installed.

## What's real here

- `GET /v1/feed/home`, `GET /v1/articles/:id`, `GET /v1/articles/:id/sources`,
  `POST /v1/articles/:id/chat` all work exactly per the Phase 6 API spec.
- The UI implements the Phase 2 design system: Light/Dark/AMOLED theming,
  factuality badges, bias chips, AI summary bullets/full/ELI5 toggle, source
  comparison rail, and a real Chat with News bottom-sheet.
- Chat with News is grounded against the article's actual text (and its
  cluster siblings for source-comparison questions) and will genuinely
  refuse to answer questions the source text doesn't support — try asking
  it something unrelated to see the refusal path.

## What this is not

This is a functional prototype of the *product experience*, not the
production system described in Phases 3–15 (no Flutter/Next.js/NestJS
build, no Postgres/Redis/Elasticsearch, no LLM API, no Kubernetes). It's
in-memory data and a keyword-grounded chat engine standing in for what
would be an LLM call in production — built this way specifically so it
runs immediately, with nothing to install and no API keys required.
