// data/seed.js
// In-memory seed data shaped exactly like the Phase 5 Postgres schema and
// the Phase 6 API contracts, so this prototype's responses are structurally
// identical to what the real News/AI services would return.

const publishers = [
  { id: 'pub-1', name: 'The Daily Ledger', slug: 'daily-ledger', trust_score: 8.7, bias_rating: 'center', is_verified_partner: true },
  { id: 'pub-2', name: 'National Herald Wire', slug: 'herald-wire', trust_score: 7.9, bias_rating: 'lean_left', is_verified_partner: true },
  { id: 'pub-3', name: 'Bharat Business Post', slug: 'bbp', trust_score: 8.2, bias_rating: 'lean_right', is_verified_partner: true },
  { id: 'pub-4', name: 'Sportsline India', trust_score: 8.9, bias_rating: 'center', slug: 'sportsline', is_verified_partner: true },
];

const categories = [
  { id: 'cat-tech', slug: 'technology', label: 'Technology' },
  { id: 'cat-business', slug: 'business', label: 'Business' },
  { id: 'cat-world', slug: 'world', label: 'World' },
  { id: 'cat-cricket', slug: 'cricket', label: 'Cricket' },
];

const now = Date.now();
const minutesAgo = (m) => new Date(now - m * 60 * 1000).toISOString();

const articles = [
  {
    id: 'art-1001',
    cluster_id: 'cluster-501',
    publisher: publishers[0],
    category: categories[0],
    headline: 'India unveils national AI compute grid to cut research costs for startups',
    hero_image_url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800',
    author_name: 'Ritu Sharma',
    published_at: minutesAgo(42),
    is_breaking: true,
    factuality_score: 9.1,
    bias_rating: 'center',
    body_text:
      "The Ministry of Electronics and IT announced Tuesday a new national AI compute grid, giving startups and university labs subsidized access to GPU clusters previously out of reach for smaller teams. The program allocates an initial 10,000 GPUs across four data centers in Pune, Hyderabad, Bengaluru, and Noida. Officials said the first allocations will go to 200 startups selected through a competitive application process opening next month. The initiative is funded through a public-private partnership with three domestic cloud providers, with total committed funding of 4,500 crore rupees over three years. Industry groups welcomed the move, noting that compute costs have been the single largest barrier for Indian AI startups compared to well-funded counterparts in the US and China.",
    ai_summary: {
      one_line: 'India launches a subsidized national GPU grid to lower AI compute costs for startups.',
      bullets: [
        '10,000 GPUs across 4 cities allocated to startups and university labs.',
        'First cohort of 200 startups selected via application starting next month.',
        '₹4,500 crore committed over three years via public-private partnership.',
      ],
      eli5: "The government is buying a lot of powerful computers and letting small AI companies use them cheaply, so they don't have to spend huge amounts of money to build their own.",
    },
  },
  {
    id: 'art-1002',
    cluster_id: 'cluster-501',
    publisher: publishers[1],
    category: categories[0],
    headline: 'Startups cautiously optimistic about new government AI compute program',
    hero_image_url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800',
    author_name: 'Devansh Rao',
    published_at: minutesAgo(35),
    is_breaking: false,
    factuality_score: 8.4,
    bias_rating: 'lean_left',
    body_text:
      "Founders reacted with cautious optimism to Tuesday's announcement of a national AI compute grid, though several raised concerns about how the 200 initial allocation slots will be judged. 'The devil will be in the selection criteria,' said one Bengaluru-based founder who requested anonymity. The Ministry has not yet published detailed eligibility rules. Some critics also questioned whether four data center locations are sufficient given the geographic spread of India's startup ecosystem, with several hubs in the northeast and other regions left without a nearby facility.",
    ai_summary: {
      one_line: 'Founders welcome the AI compute program but want clearer selection criteria.',
      bullets: [
        'Concerns raised about how the 200 startup slots will be selected.',
        'Eligibility rules not yet published by the Ministry.',
        'Some question geographic coverage of the four data center locations.',
      ],
      eli5: 'Some AI company founders are happy about the free computer access but worried the rules for who gets picked are not clear yet.',
    },
  },
  {
    id: 'art-2001',
    cluster_id: null,
    publisher: publishers[2],
    category: categories[1],
    headline: 'Gold prices ease as investors book profits ahead of RBI policy meeting',
    hero_image_url: 'https://images.unsplash.com/photo-1610375461369-d613b564f4c4?w=800',
    author_name: 'Meera Iyer',
    published_at: minutesAgo(90),
    is_breaking: false,
    factuality_score: 8.0,
    bias_rating: 'lean_right',
    body_text:
      "Gold prices in domestic markets eased 0.8% on Tuesday as investors booked profits ahead of the Reserve Bank of India's monetary policy announcement expected Thursday. Analysts said a pause or cut in interest rates could renew demand for gold as a hedge, but near-term profit-booking dominated trading. Silver moved in tandem, down 1.1% for the session. Jewellers reported steady retail demand ahead of the upcoming festival season despite the price pullback.",
    ai_summary: {
      one_line: 'Gold eased 0.8% on profit booking ahead of Thursday\'s RBI rate decision.',
      bullets: [
        'Domestic gold prices fell 0.8%, silver down 1.1%.',
        'Traders positioning ahead of Thursday\'s RBI policy announcement.',
        'Retail jewellery demand reported steady ahead of festival season.',
      ],
      eli5: 'The price of gold went down a little bit because traders are waiting to see what the bank decides about interest rates later this week.',
    },
  },
  {
    id: 'art-3001',
    cluster_id: null,
    publisher: publishers[3],
    category: categories[3],
    headline: 'India seal series win with dominant seven-wicket victory in decider',
    hero_image_url: 'https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=800',
    author_name: 'Karan Mehta',
    published_at: minutesAgo(15),
    is_breaking: true,
    factuality_score: 9.3,
    bias_rating: 'center',
    body_text:
      "India completed a comprehensive seven-wicket win in the series decider on Tuesday, chasing down a target of 214 with 22 balls to spare. A composed 78 not out anchored the chase after early wickets put the innings under pressure. The bowlers had earlier restricted the opposition to 213 all out, with a career-best five-wicket haul doing the early damage. The result seals a 2-1 series victory and continues India's unbeaten home record this season.",
    ai_summary: {
      one_line: 'India won the series decider by seven wickets, taking the series 2-1.',
      bullets: [
        'Chased down 214 with 22 balls remaining.',
        'An unbeaten 78 anchored the run chase after early wickets fell.',
        'Bowler took a career-best five-wicket haul to restrict the opposition to 213.',
      ],
      eli5: 'The Indian cricket team won the last and most important match of the series, finishing the series ahead 2 wins to 1.',
    },
  },
];

module.exports = { publishers, categories, articles };
