-- NewsBucket sports data model -- generated from docs/10-Sports-Module.md

CREATE TABLE sports_competitions (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sport         VARCHAR(30) NOT NULL,  -- cricket, football, nba, nfl, f1, kabaddi, chess, tennis
    name          VARCHAR(200) NOT NULL,
    season        VARCHAR(20),
    provider_ref  VARCHAR(100) NOT NULL, -- external provider's competition id
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sports_teams (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sport         VARCHAR(30) NOT NULL,
    name          VARCHAR(200) NOT NULL,
    short_name    VARCHAR(20),
    logo_url      TEXT,
    provider_ref  VARCHAR(100) NOT NULL
);

CREATE TABLE sports_players (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sport         VARCHAR(30) NOT NULL,
    team_id       UUID REFERENCES sports_teams(id),
    full_name     VARCHAR(200) NOT NULL,
    photo_url     TEXT,
    provider_ref  VARCHAR(100) NOT NULL,
    career_stats  JSONB NOT NULL DEFAULT '{}'
);

CREATE TABLE sports_matches (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sport            VARCHAR(30) NOT NULL,
    competition_id   UUID NOT NULL REFERENCES sports_competitions(id),
    home_team_id     UUID NOT NULL REFERENCES sports_teams(id),
    away_team_id     UUID NOT NULL REFERENCES sports_teams(id),
    status           VARCHAR(20) NOT NULL CHECK (status IN ('scheduled','live','completed','postponed','abandoned')),
    scheduled_at     TIMESTAMPTZ NOT NULL,
    venue            VARCHAR(200),
    current_state    JSONB NOT NULL DEFAULT '{}',  -- sport-specific live state, e.g. score/overs/innings
    provider_ref     VARCHAR(100) NOT NULL,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sports_matches_status ON sports_matches(sport, status, scheduled_at);
CREATE UNIQUE INDEX idx_sports_matches_provider_ref ON sports_matches(sport, provider_ref);

CREATE TABLE sports_standings (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    competition_id   UUID NOT NULL REFERENCES sports_competitions(id),
    team_id          UUID NOT NULL REFERENCES sports_teams(id),
    rank             INT NOT NULL,
    points           INT NOT NULL,
    stats            JSONB NOT NULL DEFAULT '{}',
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (competition_id, team_id)
);
