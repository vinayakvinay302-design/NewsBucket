import { Body, Controller, Post, UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';
import { VerifyFirebaseTokenDto } from './dto/verify-firebase-token.dto';
import { RefreshTokenDto } from './dto/refresh-token.dto';

@Controller('v1/auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('verify-firebase-token')
  async verifyFirebaseToken(@Body() dto: VerifyFirebaseTokenDto) {
    const decoded = await this.authService.verifyFirebaseIdToken(dto.idToken);
    // Production: look up or create the local `users` row for decoded.uid
    // (docs/05-Database-Schema.md `users` table), then issue a session
    // scoped to that user's actual roles.
    const session = await this.authService.issueSessionForUser(decoded.uid, ['user']);
    return {
      data: {
        access_token: session.accessToken,
        refresh_token: session.refreshToken,
        refresh_token_expires_at: session.refreshTokenExpiresAt,
      },
      meta: {},
    };
  }

  @Post('refresh')
  async refresh(@Body() dto: RefreshTokenDto) {
    // Production: look up refresh_tokens by token_hash, verify not revoked
    // and not expired, then rotate per docs/12-Security.md Section 1.
    throw new UnauthorizedException('AUTH_TOKEN_INVALID');
  }
}
