import { IsString, MinLength } from 'class-validator';

export class VerifyFirebaseTokenDto {
  @IsString()
  @MinLength(20)
  idToken: string;

  @IsString()
  deviceId: string;
}
