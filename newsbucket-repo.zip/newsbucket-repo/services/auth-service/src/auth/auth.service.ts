import { Injectable, UnauthorizedException } from '@nestjs/common';
import { TokenService, TokenPair } from './token.service';

export interface FirebaseDecodedToken {
  uid: string;
  phone_number?: string;
  email?: string;
}

/**
 * Verifies a Firebase ID token, then issues NewsBucket's own JWT pair.
 * Firebase is the credential/OTP authority (docs/03-Tech-Stack.md Section 13);
 * this service never sees or stores raw passwords or OTP codes.
 */
@Injectable()
export class AuthService {
  constructor(private readonly tokens: TokenService) {}

  async verifyFirebaseIdToken(idToken: string): Promise<FirebaseDecodedToken> {
    // Production implementation calls the Firebase Admin SDK's
    // getAuth().verifyIdToken(idToken). Omitted here since it requires the
    // deployed Firebase service-account credentials.
    if (!idToken || idToken.length < 20) {
      throw new UnauthorizedException('AUTH_TOKEN_INVALID');
    }
    throw new Error('Wire up Firebase Admin SDK verifyIdToken() here.');
  }

  async issueSessionForUser(userId: string, roles: string[]): Promise<TokenPair> {
    const accessToken = this.tokens.issueAccessToken({ userId, roles });
    const { token: refreshToken, expiresAt } = this.tokens.issueRefreshToken();
    return { accessToken, refreshToken, refreshTokenExpiresAt: expiresAt };
  }
}
