import { Injectable } from '@nestjs/common';
import { randomBytes, createHash } from 'crypto';

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  refreshTokenExpiresAt: Date;
}

/**
 * Issues short-lived JWT access tokens (RS256) and long-lived, single-use,
 * rotated refresh tokens, per docs/12-Security.md Section 1. Refresh token
 * reuse detection ("reuse of an already-rotated refresh token revokes the
 * entire token family") is enforced by the caller checking `revoked_at`
 * and the `token_hash` chain in the refresh_tokens table before rotating.
 */
@Injectable()
export class TokenService {
  private readonly accessTokenTtlSeconds = 15 * 60;
  private readonly refreshTokenTtlDays = 30;

  issueAccessToken(payload: { userId: string; roles: string[] }): string {
    const header = this.base64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
    const now = Math.floor(Date.now() / 1000);
    const body = this.base64url(
      JSON.stringify({
        sub: payload.userId,
        roles: payload.roles,
        iat: now,
        exp: now + this.accessTokenTtlSeconds,
        iss: 'newsbucket-auth-service',
      }),
    );
    // Production signs with the service's RSA private key loaded from
    // Secrets Manager (docs/12-Security.md Section 5); signature generation
    // omitted from this excerpt since it depends on deployed key material.
    const signature = this.base64url(createHash('sha256').update(`${header}.${body}`).digest());
    return `${header}.${body}.${signature}`;
  }

  issueRefreshToken(): { token: string; tokenHash: string; expiresAt: Date } {
    const token = randomBytes(48).toString('base64url');
    const tokenHash = createHash('sha256').update(token).digest('hex');
    const expiresAt = new Date(Date.now() + this.refreshTokenTtlDays * 24 * 60 * 60 * 1000);
    return { token, tokenHash, expiresAt };
  }

  private base64url(input: string | Buffer): string {
    return Buffer.from(input).toString('base64url');
  }
}
