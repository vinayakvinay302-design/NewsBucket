// sports-service/src/realtime/websocket.gateway.ts
import {
  WebSocketGateway as WsGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import { RedisClient } from '../cache/redis.client';

@WsGateway({ namespace: '/v1/ws/sports', cors: { origin: true } })
export class WebSocketGateway implements OnGatewayConnection {
  @WebSocketServer() server: Server;

  constructor(private readonly redis: RedisClient) {}

  afterInit(server: Server) {
    // Redis adapter is what makes this horizontally scalable: a client
    // connected to pod A receives a broadcast published from pod B, because
    // both pods share the same Redis pub/sub channel rather than only
    // being able to reach sockets held in their own process memory.
    const pubClient = this.redis.duplicate();
    const subClient = this.redis.duplicate();
    server.adapter(createAdapter(pubClient, subClient));
  }

  handleConnection(client: Socket) {
    const { matchId } = client.handshake.query;
    if (typeof matchId === 'string') {
      client.join(`match:${matchId}`);
    }
  }

  @SubscribeMessage('subscribe_match')
  handleSubscribe(client: Socket, matchId: string) {
    client.join(`match:${matchId}`);
  }

  broadcastToRoom(room: string, event: string, payload: unknown) {
    this.server.to(room).emit(event, payload);
  }
}
