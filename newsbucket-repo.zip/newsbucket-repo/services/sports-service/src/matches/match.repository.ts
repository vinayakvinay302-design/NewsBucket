import { Injectable } from '@nestjs/common';

export interface MatchEntity {
  id: string;
  providerRef: string;
  status: 'scheduled' | 'live' | 'completed' | 'postponed' | 'abandoned';
  currentState: Record<string, unknown>;
}

// Repository over `sports_matches` (database/sports_schema.sql).
@Injectable()
export class MatchRepository {
  async findByStatus(status: MatchEntity['status']): Promise<MatchEntity[]> {
    throw new Error('Wire up Prisma/TypeORM client against database/sports_schema.sql here.');
  }

  async updateState(id: string, state: Record<string, unknown>, status: string): Promise<void> {
    throw new Error('Wire up Prisma/TypeORM client against database/sports_schema.sql here.');
  }
}
