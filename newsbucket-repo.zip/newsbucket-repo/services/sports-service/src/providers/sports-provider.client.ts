import { Injectable } from '@nestjs/common';

export interface LiveStateUpdate {
  providerRef: string;
  state: Record<string, unknown>;
  status: 'scheduled' | 'live' | 'completed' | 'postponed' | 'abandoned';
}

/**
 * Wraps the third-party sports data providers listed in
 * docs/10-Sports-Module.md Section 1, normalizing each provider's payload
 * shape into the common LiveStateUpdate contract so the rest of the
 * service never needs per-sport parsing logic.
 */
@Injectable()
export class SportsProviderClient {
  async fetchLiveStates(providerRefs: string[]): Promise<LiveStateUpdate[]> {
    throw new Error('Wire up the per-sport provider API clients here.');
  }
}
