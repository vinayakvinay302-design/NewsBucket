// sports-service/src/workers/live-score-poller.worker.ts
import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { SportsProviderClient } from '../providers/sports-provider.client';
import { MatchRepository } from '../matches/match.repository';
import { WebSocketGateway } from '../realtime/websocket.gateway';
import { EventPublisher } from '../events/event-publisher';

@Injectable()
export class LiveScorePoller {
  private readonly logger = new Logger(LiveScorePoller.name);

  constructor(
    private readonly provider: SportsProviderClient,
    private readonly matches: MatchRepository,
    private readonly gateway: WebSocketGateway,
    private readonly events: EventPublisher,
  ) {}

  // Runs every 5 seconds for matches currently marked 'live'; a separate,
  // much slower cron (60s) handles 'scheduled' matches to detect kickoff.
  @Cron('*/5 * * * * *')
  async pollLiveMatches(): Promise<void> {
    const liveMatches = await this.matches.findByStatus('live');
    if (liveMatches.length === 0) return;

    const updates = await this.provider.fetchLiveStates(liveMatches.map((m) => m.providerRef));

    for (const update of updates) {
      const match = liveMatches.find((m) => m.providerRef === update.providerRef);
      if (!match) continue;

      const hasChanged = JSON.stringify(match.currentState) !== JSON.stringify(update.state);
      if (!hasChanged) continue;

      await this.matches.updateState(match.id, update.state, update.status);

      // Push only the diff over WebSocket, not the full match object --
      // keeps the real-time payload small for the number-flash micro-
      // interaction defined in the Phase 2 design system to feel instant.
      this.gateway.broadcastToRoom(`match:${match.id}`, 'score_update', {
        matchId: match.id,
        state: update.state,
        status: update.status,
      });

      if (update.status === 'completed' && match.status !== 'completed') {
        await this.events.publish('sports.match.completed', { matchId: match.id });
      }
    }
  }
}
