import { Module } from '@nestjs/common';
import { LiveScorePoller } from './workers/live-score-poller.worker';
import { WebSocketGateway } from './realtime/websocket.gateway';
import { SportsProviderClient } from './providers/sports-provider.client';
import { MatchRepository } from './matches/match.repository';
import { EventPublisher } from './events/event-publisher';
import { RedisClient } from './cache/redis.client';

@Module({
  providers: [
    LiveScorePoller,
    WebSocketGateway,
    SportsProviderClient,
    MatchRepository,
    EventPublisher,
    RedisClient,
  ],
})
export class SportsModule {}
