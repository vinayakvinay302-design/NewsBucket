import { Injectable } from '@nestjs/common';

/**
 * Redis client whose `duplicate()` connections back the Socket.IO Redis
 * adapter in websocket.gateway.ts, per docs/10-Sports-Module.md Section 4 --
 * this is what makes the WebSocket layer horizontally scalable across pods.
 */
@Injectable()
export class RedisClient {
  duplicate(): unknown {
    throw new Error('Wire up ioredis client (with .duplicate() support) here.');
  }
}
