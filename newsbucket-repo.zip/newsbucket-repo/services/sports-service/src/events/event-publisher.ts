import { Injectable } from '@nestjs/common';

@Injectable()
export class EventPublisher {
  async publish(eventName: string, payload: Record<string, unknown>): Promise<void> {
    throw new Error('Wire up the AWS SNS client here.');
  }
}
