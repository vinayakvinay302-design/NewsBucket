import { Injectable } from '@nestjs/common';

export interface ArticleEntity {
  id: string;
  clusterId: string | null;
  headline: string;
  bodyText: string;
  bodyHtml: string;
  publisherId: string;
  publisherName: string;
  categoryId: string;
  publishedAt: Date;
  factualityScore: number | null;
  biasRating: string | null;
}

/**
 * Repository over the `articles` table defined in docs/05-Database-Schema.md.
 * Queries route through the read/write-split connection pool described in
 * docs/04-Backend-Architecture.md Section 6 -- reads default to the replica
 * pool, writes always use the primary pool. The actual Prisma/TypeORM
 * client wiring is intentionally left as an integration point: this
 * repository's method signatures are the real, stable contract the rest of
 * the codebase (including ai-service's ChatService) is written against.
 */
@Injectable()
export class ArticleRepository {
  async findByIdWithCluster(id: string): Promise<ArticleEntity | null> {
    throw new Error('Wire up Prisma/TypeORM client against database/schema.sql here.');
  }

  async findClusterMembers(
    clusterId: string,
    opts: { excludeId: string; limit: number },
  ): Promise<ArticleEntity[]> {
    throw new Error('Wire up Prisma/TypeORM client against database/schema.sql here.');
  }

  async findHomeFeed(opts: { cursor?: string; limit: number }): Promise<{
    articles: ArticleEntity[];
    nextCursor: string | null;
  }> {
    throw new Error('Wire up Prisma/TypeORM client against database/schema.sql here.');
  }

  /**
   * Inserts a new article row. Called by ingestion-service's
   * NormalizationWorker (docs/09-News-Ingestion.md Section 3) after source
   * verification, duplicate detection, and HTML sanitization have all
   * passed. `clusterId` is set when the duplicate-detection service found
   * a near-duplicate match, so this is also how a story's
   * "Other outlets covering this" clustering gets populated.
   */
  async create(input: {
    publisherId: string;
    headline: string;
    bodyHtml: string;
    canonicalUrl: string;
    heroImageUrl?: string;
    authorName?: string;
    originalLanguage: string;
    publishedAt: Date;
    clusterId?: string;
    status: 'draft' | 'published' | 'corrected' | 'retracted' | 'removed';
  }): Promise<ArticleEntity> {
    throw new Error('Wire up Prisma/TypeORM client against database/schema.sql here.');
  }
}
