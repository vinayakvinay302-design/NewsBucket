import { Module } from '@nestjs/common';
import { ArticlesController } from './articles.controller';
import { ArticleRepository } from './article.repository';

@Module({
  controllers: [ArticlesController],
  providers: [ArticleRepository],
  exports: [ArticleRepository],
})
export class ArticlesModule {}
