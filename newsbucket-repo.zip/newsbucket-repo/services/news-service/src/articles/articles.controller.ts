import { Controller, Get, NotFoundException, Param, Query } from '@nestjs/common';
import { ArticleRepository } from './article.repository';

@Controller('v1')
export class ArticlesController {
  constructor(private readonly articles: ArticleRepository) {}

  // GET /v1/feed/home -- see docs/06-API-Documentation.md Section 3
  @Get('feed/home')
  async homeFeed(@Query('cursor') cursor?: string, @Query('limit') limit = 20) {
    const page = await this.articles.findHomeFeed({ cursor, limit: Number(limit) });
    return { data: page.articles, meta: { next_cursor: page.nextCursor } };
  }

  // GET /v1/articles/:id -- see docs/06-API-Documentation.md Section 3
  @Get('articles/:id')
  async getArticle(@Param('id') id: string) {
    const article = await this.articles.findByIdWithCluster(id);
    if (!article) {
      throw new NotFoundException({ error: { code: 'ARTICLE_NOT_FOUND', message: 'Article not found.' } });
    }
    return { data: article, meta: {} };
  }

  // GET /v1/articles/:id/sources -- see docs/06-API-Documentation.md Section 3
  @Get('articles/:id/sources')
  async getSources(@Param('id') id: string) {
    const article = await this.articles.findByIdWithCluster(id);
    if (!article) {
      throw new NotFoundException({ error: { code: 'ARTICLE_NOT_FOUND', message: 'Article not found.' } });
    }
    if (!article.clusterId) return { data: [], meta: {} };
    const members = await this.articles.findClusterMembers(article.clusterId, { excludeId: id, limit: 5 });
    return { data: members, meta: {} };
  }
}
