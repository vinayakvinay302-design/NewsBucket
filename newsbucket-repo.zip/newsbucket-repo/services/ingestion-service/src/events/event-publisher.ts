import { Injectable } from '@nestjs/common';

/**
 * Publishes domain events (e.g. `news.article.published`) to SNS, per the
 * naming convention and idempotency rules in docs/04-Backend-Architecture.md
 * Section 3. Every event carries a unique event_id so consumers can
 * deduplicate against at-least-once delivery.
 */
@Injectable()
export class EventPublisher {
  async publish(eventName: string, payload: Record<string, unknown>): Promise<void> {
    throw new Error('Wire up the AWS SNS client here.');
  }
}
