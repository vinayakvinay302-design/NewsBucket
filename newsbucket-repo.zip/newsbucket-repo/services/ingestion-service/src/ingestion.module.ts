import { Module } from '@nestjs/common';
import { NormalizationWorker } from './workers/normalization.worker';
import { DuplicateDetectionService } from './workers/duplicate-detection.service';
import { SourceVerificationService } from './workers/source-verification.service';
import { ArticleRepository } from './articles/article.repository';
import { EventPublisher } from './events/event-publisher';
import { RedisClient } from './cache/redis.client';
import { EmbeddingClient } from './ai/embedding.client';

@Module({
  providers: [
    NormalizationWorker,
    DuplicateDetectionService,
    SourceVerificationService,
    ArticleRepository,
    EventPublisher,
    RedisClient,
    EmbeddingClient,
  ],
})
export class IngestionModule {}
