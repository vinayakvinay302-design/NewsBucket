// ingestion-service/src/workers/normalization.worker.ts
import { Injectable, Logger } from '@nestjs/common';
import { SqsConsumer } from '../queue/sqs-consumer';
import { DuplicateDetectionService } from './duplicate-detection.service';
import { SourceVerificationService } from './source-verification.service';
import { ArticleRepository } from '../articles/article.repository';
import { EventPublisher } from '../events/event-publisher';

interface RawIngestedArticle {
  sourceType: 'rss' | 'publisher_api' | 'government_api';
  publisherSlug: string;
  canonicalUrl: string;
  headline: string;
  bodyHtml: string;
  heroImageUrl?: string;
  authorName?: string;
  publishedAtRaw: string;
  language: string;
}

@Injectable()
export class NormalizationWorker {
  private readonly logger = new Logger(NormalizationWorker.name);

  constructor(
    private readonly dupeDetection: DuplicateDetectionService,
    private readonly sourceVerification: SourceVerificationService,
    private readonly articles: ArticleRepository,
    private readonly events: EventPublisher,
  ) {}

  @SqsConsumer('ingestion-raw-queue', { batchSize: 10, visibilityTimeout: 60 })
  async handle(raw: RawIngestedArticle): Promise<void> {
    // 1. Source verification -- reject unknown/unverified publishers outright,
    // route borderline/new sources to a manual onboarding review queue rather
    // than auto-publishing unverified content.
    const publisher = await this.sourceVerification.resolvePublisher(raw.publisherSlug);
    if (!publisher) {
      this.logger.warn(`Rejected article from unverified source: ${raw.publisherSlug}`);
      await this.sourceVerification.queueForReview(raw);
      return;
    }

    // 2. Duplicate detection -- canonical URL exact match first (cheap),
    // then near-duplicate detection via title+body simhash against a rolling
    // 48-hour window before falling back to expensive embedding similarity.
    const exactDuplicate = await this.dupeDetection.findByCanonicalUrl(raw.canonicalUrl);
    if (exactDuplicate) {
      this.logger.debug(`Skipping exact duplicate: ${raw.canonicalUrl}`);
      return;
    }
    const nearDuplicateClusterId = await this.dupeDetection.findNearDuplicateCluster(
      raw.headline,
      raw.bodyHtml,
    );

    // 3. Sanitize + normalize HTML body (strip scripts/trackers/ads embedded
    // by source, normalize to a constrained safe-HTML subset).
    const sanitizedBody = this.sanitizeHtml(raw.bodyHtml);

    // 4. Persist as a new article, attaching to an existing cluster if a
    // near-duplicate was found (this is how "Other outlets covering this"
    // source-comparison clustering, per Phase 5/6, gets populated).
    const article = await this.articles.create({
      publisherId: publisher.id,
      headline: raw.headline,
      bodyHtml: sanitizedBody,
      canonicalUrl: raw.canonicalUrl,
      heroImageUrl: raw.heroImageUrl,
      authorName: raw.authorName,
      originalLanguage: raw.language,
      publishedAt: new Date(raw.publishedAtRaw),
      clusterId: nearDuplicateClusterId ?? undefined,
      status: 'published',
    });

    // 5. Emit event -- triggers AI enrichment (Phase 8), search indexing,
    // and notification evaluation in parallel, decoupled consumers.
    await this.events.publish('news.article.published', {
      articleId: article.id,
      publisherId: publisher.id,
      isPotentiallyBreaking: this.isLikelyBreaking(raw, publisher),
    });
  }

  private isLikelyBreaking(raw: RawIngestedArticle, publisher: { trustScore: number }): boolean {
    const breakingKeywords = ['breaking', 'urgent', 'alert', 'just in'];
    const headlineLower = raw.headline.toLowerCase();
    return (
      publisher.trustScore >= 7.0 &&
      breakingKeywords.some((kw) => headlineLower.includes(kw))
    );
  }

  private sanitizeHtml(html: string): string {
    // Production implementation uses a strict allow-list sanitizer
    // (e.g. sanitize-html with a locked-down config: p, a, strong, em, ul,
    // li, blockquote, img[src,alt] only -- no script, style, iframe, on*).
    return html; // sanitizer invocation omitted for brevity of this excerpt
  }
}
