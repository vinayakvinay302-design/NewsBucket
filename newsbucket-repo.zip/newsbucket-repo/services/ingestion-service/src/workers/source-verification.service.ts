import { Injectable } from '@nestjs/common';

export interface VerifiedPublisher {
  id: string;
  trustScore: number;
  tier: 1 | 2 | 3;
}

/**
 * Implements the publisher onboarding/tiering policy from
 * docs/09-News-Ingestion.md Section 5: every publisher is manually
 * onboarded once before content flows through automatically, and trust
 * tiers are dynamic based on a rolling fake-news-confidence rate.
 */
@Injectable()
export class SourceVerificationService {
  async resolvePublisher(slug: string): Promise<VerifiedPublisher | null> {
    throw new Error('Wire up the publishers table lookup here (database/schema.sql).');
  }

  async queueForReview(raw: unknown): Promise<void> {
    throw new Error('Wire up the Tier-3 manual review queue here.');
  }
}
