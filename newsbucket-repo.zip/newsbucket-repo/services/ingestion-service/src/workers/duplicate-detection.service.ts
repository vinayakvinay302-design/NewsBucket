// ingestion-service/src/workers/duplicate-detection.service.ts
import { Injectable } from '@nestjs/common';
import { createHash } from 'crypto';
import { RedisClient } from '../cache/redis.client';
import { EmbeddingClient } from '../ai/embedding.client';

@Injectable()
export class DuplicateDetectionService {
  constructor(
    private readonly redis: RedisClient,
    private readonly embeddings: EmbeddingClient,
  ) {}

  async findByCanonicalUrl(url: string): Promise<{ id: string } | null> {
    const normalized = this.normalizeUrl(url);
    return this.redis.get(`article:url:${this.hash(normalized)}`);
  }

  /**
   * Two-stage near-duplicate detection:
   * 1. Cheap simhash comparison against a rolling 48h Redis-backed index --
   *    catches near-identical wire-service republishes across outlets.
   * 2. If simhash is inconclusive, fall back to embedding cosine similarity
   *    against the small candidate set simhash already narrowed down --
   *    never runs embedding comparison against the full historical corpus.
   */
  async findNearDuplicateCluster(headline: string, bodyHtml: string): Promise<string | null> {
    const simhash = this.computeSimhash(`${headline} ${this.stripHtml(bodyHtml)}`);
    const candidates = await this.redis.getSimhashCandidates(simhash, {
      maxHammingDistance: 6,
      windowHours: 48,
    });

    if (candidates.length === 0) return null;
    if (candidates.length === 1) return candidates[0].clusterId;

    const embedding = await this.embeddings.embed(`${headline}\n${this.stripHtml(bodyHtml)}`);
    let bestMatch: { clusterId: string; score: number } | null = null;
    for (const candidate of candidates) {
      const score = this.cosineSimilarity(embedding, candidate.embedding);
      if (score > 0.88 && (!bestMatch || score > bestMatch.score)) {
        bestMatch = { clusterId: candidate.clusterId, score };
      }
    }
    return bestMatch?.clusterId ?? null;
  }

  private computeSimhash(text: string): bigint {
    // Production implementation: 64-bit simhash over shingled tokens.
    // Omitted here -- standard simhash algorithm, not NewsBucket-specific.
    return BigInt(0);
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    const dot = a.reduce((sum, val, i) => sum + val * b[i], 0);
    const normA = Math.sqrt(a.reduce((s, v) => s + v * v, 0));
    const normB = Math.sqrt(b.reduce((s, v) => s + v * v, 0));
    return dot / (normA * normB + 1e-9);
  }

  private normalizeUrl(url: string): string {
    const u = new URL(url);
    u.search = '';
    u.hash = '';
    return u.toString().toLowerCase().replace(/\/$/, '');
  }

  private stripHtml(html: string): string {
    return html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  }

  private hash(input: string): string {
    return createHash('sha256').update(input).digest('hex');
  }
}
