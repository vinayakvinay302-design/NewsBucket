// Re-exports the shared ArticleRepository contract (see docs/05-Database-Schema.md
// `articles` table). In production, ingestion-service creates articles via
// news-service's internal API rather than writing to the table directly,
// per the "services never call another service's database directly" rule
// in docs/04-Backend-Architecture.md Section 1.
export { ArticleRepository, ArticleEntity } from '../../../news-service/src/articles/article.repository';
