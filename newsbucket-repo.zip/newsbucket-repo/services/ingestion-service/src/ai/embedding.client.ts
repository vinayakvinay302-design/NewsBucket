import { Injectable } from '@nestjs/common';

@Injectable()
export class EmbeddingClient {
  async embed(text: string): Promise<number[]> {
    throw new Error('Wire up the managed embedding API client here.');
  }
}
