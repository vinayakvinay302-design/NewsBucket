import 'reflect-metadata';

/**
 * Method decorator marking a handler as an SQS consumer, per
 * docs/04-Backend-Architecture.md Section 7 (background workers & queues).
 * Production implementation wires this to the AWS SDK SQS client with the
 * given queue name, batch size, and visibility timeout, polling in a loop
 * and invoking the decorated method per message with automatic ack/nack
 * and dead-letter routing after 3 failed attempts.
 */
export function SqsConsumer(
  queueName: string,
  opts: { batchSize: number; visibilityTimeout: number },
): MethodDecorator {
  return (target, propertyKey, descriptor: PropertyDescriptor) => {
    Reflect.defineMetadata('sqs:queue', { queueName, ...opts }, target, propertyKey);
    return descriptor;
  };
}
