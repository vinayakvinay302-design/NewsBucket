# recommendation-service/ranking/feature_composer.py
"""
Combines explicit + implicit signals into a single ranking score per
candidate article for a given user. Runs against precomputed Redis
feature vectors -- no live model inference on the request path, to hit
the <50ms feed-ranking latency budget.
"""

from dataclasses import dataclass


@dataclass
class RankingWeights:
    explicit_interest: float = 0.30
    implicit_affinity: float = 0.25
    freshness: float = 0.20
    engagement_velocity: float = 0.15
    diversity_penalty: float = 0.10  # subtracted, not added


def score_article(user_features: dict, article_features: dict, weights: RankingWeights) -> float:
    explicit = user_features["category_weights"].get(article_features["category_id"], 0.0)
    implicit = cosine_similarity(user_features["embedding"], article_features["embedding"])
    freshness = freshness_decay(article_features["published_at_epoch"])
    velocity = article_features["engagement_velocity_percentile"]
    diversity_penalty = recent_category_repetition_penalty(
        user_features["recent_categories_shown"], article_features["category_id"]
    )

    score = (
        weights.explicit_interest * explicit
        + weights.implicit_affinity * implicit
        + weights.freshness * freshness
        + weights.engagement_velocity * velocity
        - weights.diversity_penalty * diversity_penalty
    )
    return score


def freshness_decay(published_at_epoch: float, half_life_hours: float = 6.0) -> float:
    import time
    import math
    age_hours = (time.time() - published_at_epoch) / 3600
    return math.exp(-age_hours * (math.log(2) / half_life_hours))


def recent_category_repetition_penalty(recent_categories: list[str], category_id: str) -> float:
    """Explicit diversity-injection mechanism referenced in the PRD --
    prevents the feed from collapsing into a single-category filter bubble."""
    count = recent_categories.count(category_id)
    return min(count / 5.0, 1.0)


def cosine_similarity(vec_a: list[float], vec_b: list[float]) -> float:
    dot = sum(a * b for a, b in zip(vec_a, vec_b))
    norm_a = sum(a * a for a in vec_a) ** 0.5
    norm_b = sum(b * b for b in vec_b) ** 0.5
    return dot / (norm_a * norm_b + 1e-9)
