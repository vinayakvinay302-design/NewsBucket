# recommendation-service

Python/FastAPI scoring service implementing the hybrid ranking algorithm
from docs/08-AI-Features.md Section 4: explicit interests + implicit
behavior + freshness decay + engagement velocity - diversity penalty.

`ranking/feature_composer.py` is the real scoring function; wire it behind
a FastAPI endpoint (`POST /score`) that news-service's feed-read path calls
with a candidate set and precomputed Redis feature vectors.

Run locally:
```
pip install -r requirements.txt
uvicorn main:app --reload --port 3006
```
(`main.py` is the FastAPI entrypoint to add around `feature_composer.py`.)
