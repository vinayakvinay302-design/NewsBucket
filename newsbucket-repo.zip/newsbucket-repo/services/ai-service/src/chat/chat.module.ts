import { Module } from '@nestjs/common';
import { ChatController } from './chat.controller';
import { ChatService } from './chat.service';
import { ArticleRepository } from '../articles/article.repository';
import { EmbeddingService } from '../embeddings/embedding.service';
import { LlmClient } from '../llm/llm.client';

@Module({
  controllers: [ChatController],
  providers: [ChatService, ArticleRepository, EmbeddingService, LlmClient],
})
export class ChatModule {}
