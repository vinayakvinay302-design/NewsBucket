// ai-service/src/chat/chat.service.ts
import { Injectable } from '@nestjs/common';
import { ArticleRepository } from '../articles/article.repository';
import { EmbeddingService } from '../embeddings/embedding.service';
import { LlmClient } from '../llm/llm.client';

interface ChatResult {
  answer: string;
  citations: { sourceArticleId: string; excerpt: string }[];
  grounded: boolean;
}

@Injectable()
export class ChatService {
  constructor(
    private readonly articles: ArticleRepository,
    private readonly embeddings: EmbeddingService,
    private readonly llm: LlmClient,
  ) {}

  async answerQuestion(articleId: string, question: string, userId: string): Promise<ChatResult> {
    const article = await this.articles.findByIdWithCluster(articleId);
    if (!article) {
      throw new Error('ARTICLE_NOT_FOUND');
    }

    // Retrieve grounding context: this article + top-3 clustered sources by
    // embedding similarity to the question, never the open web or model memory.
    const clusterArticles = await this.articles.findClusterMembers(article.clusterId, {
      excludeId: articleId,
      limit: 3,
    });
    const candidates = [article, ...clusterArticles];
    const ranked = await this.embeddings.rankBySimilarity(question, candidates);

    const context = ranked
      .map((a, i) => `[Source ${i + 1}: ${a.publisherName}]\n${a.bodyText}`)
      .join('\n\n---\n\n');

    const systemPrompt = [
      'You are NewsBucket\'s Chat with News assistant.',
      'Answer the user\'s question using ONLY the sources provided below.',
      'Every claim in your answer must cite a source number, e.g. [Source 1].',
      'If the sources do not contain enough information to answer, respond exactly:',
      '"I don\'t have enough information in these sources to answer that."',
      'Never use outside knowledge, predictions, or unstated inference.',
    ].join(' ');

    const completion = await this.llm.complete({
      system: systemPrompt,
      user: `Sources:\n\n${context}\n\nQuestion: ${question}`,
      maxTokens: 500,
      temperature: 0.1, // low temperature: factual grounding over creativity
    });

    const grounded = !completion.text.includes(
      "I don't have enough information in these sources to answer that",
    );

    return {
      answer: completion.text,
      citations: grounded ? this.extractCitations(completion.text, ranked) : [],
      grounded,
    };
  }

  private extractCitations(
    answerText: string,
    sources: { id: string; bodyText: string; publisherName: string }[],
  ) {
    const citations: { sourceArticleId: string; excerpt: string }[] = [];
    const matches = answerText.matchAll(/\[Source (\d+)\]/g);
    const seen = new Set<number>();
    for (const match of matches) {
      const idx = parseInt(match[1], 10) - 1;
      if (!seen.has(idx) && sources[idx]) {
        seen.add(idx);
        citations.push({
          sourceArticleId: sources[idx].id,
          excerpt: sources[idx].bodyText.slice(0, 180),
        });
      }
    }
    return citations;
  }
}
