import { Body, Controller, Param, Post, Req } from '@nestjs/common';
import { ChatService } from './chat.service';

// POST /v1/articles/:id/chat -- docs/06-API-Documentation.md Section 3.
// Rate limited at the API Gateway per docs/04-Backend-Architecture.md
// Section 5 (20/min free tier, 100/min Premium) before requests reach here.
@Controller('v1/articles')
export class ChatController {
  constructor(private readonly chat: ChatService) {}

  @Post(':id/chat')
  async askQuestion(@Param('id') articleId: string, @Body('question') question: string, @Req() req: any) {
    const userId = req.user?.id ?? 'anonymous';
    const result = await this.chat.answerQuestion(articleId, question, userId);
    return { data: result, meta: {} };
  }
}
