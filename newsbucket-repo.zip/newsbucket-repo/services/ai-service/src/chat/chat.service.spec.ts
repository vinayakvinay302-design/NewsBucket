// ai-service/src/chat/chat.service.spec.ts
import { Test } from '@nestjs/testing';
import { ChatService } from './chat.service';
import { ArticleRepository } from '../articles/article.repository';
import { EmbeddingService } from '../embeddings/embedding.service';
import { LlmClient } from '../llm/llm.client';

describe('ChatService — grounding and refusal behavior', () => {
  let service: ChatService;
  let llmClient: jest.Mocked<LlmClient>;
  let articleRepo: jest.Mocked<ArticleRepository>;
  let embeddingService: jest.Mocked<EmbeddingService>;

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [
        ChatService,
        { provide: ArticleRepository, useValue: { findByIdWithCluster: jest.fn(), findClusterMembers: jest.fn() } },
        { provide: EmbeddingService, useValue: { rankBySimilarity: jest.fn() } },
        { provide: LlmClient, useValue: { complete: jest.fn() } },
      ],
    }).compile();

    service = module.get(ChatService);
    llmClient = module.get(LlmClient);
    articleRepo = module.get(ArticleRepository);
    embeddingService = module.get(EmbeddingService);
  });

  it('returns grounded=false and no citations when the model issues the refusal string', async () => {
    articleRepo.findByIdWithCluster.mockResolvedValue({
      id: 'a1', clusterId: 'c1', bodyText: 'Article about local elections.', publisherName: 'Times',
    } as any);
    articleRepo.findClusterMembers.mockResolvedValue([]);
    embeddingService.rankBySimilarity.mockResolvedValue([
      { id: 'a1', bodyText: 'Article about local elections.', publisherName: 'Times' } as any,
    ]);
    llmClient.complete.mockResolvedValue({
      text: "I don't have enough information in these sources to answer that.",
    } as any);

    const result = await service.answerQuestion('a1', 'What will happen in next year\'s election?', 'user1');

    expect(result.grounded).toBe(false);
    expect(result.citations).toHaveLength(0);
  });

  it('extracts citations only for source numbers actually referenced in the answer', async () => {
    articleRepo.findByIdWithCluster.mockResolvedValue({ id: 'a1', clusterId: 'c1', bodyText: 'x', publisherName: 'Times' } as any);
    articleRepo.findClusterMembers.mockResolvedValue([]);
    embeddingService.rankBySimilarity.mockResolvedValue([
      { id: 'a1', bodyText: 'Turnout was 62 percent.', publisherName: 'Times' } as any,
      { id: 'a2', bodyText: 'The result was contested.', publisherName: 'Herald' } as any,
    ]);
    llmClient.complete.mockResolvedValue({
      text: 'Turnout was 62 percent [Source 1]. The result was contested [Source 2].',
    } as any);

    const result = await service.answerQuestion('a1', 'What was turnout?', 'user1');

    expect(result.grounded).toBe(true);
    expect(result.citations.map((c) => c.sourceArticleId)).toEqual(['a1', 'a2']);
  });

  it('never fabricates a citation for a source number the model did not cite', async () => {
    articleRepo.findByIdWithCluster.mockResolvedValue({ id: 'a1', clusterId: 'c1', bodyText: 'x', publisherName: 'Times' } as any);
    articleRepo.findClusterMembers.mockResolvedValue([]);
    embeddingService.rankBySimilarity.mockResolvedValue([
      { id: 'a1', bodyText: 'Text A', publisherName: 'Times' } as any,
    ]);
    llmClient.complete.mockResolvedValue({ text: 'A general statement with no citation marker.' } as any);

    const result = await service.answerQuestion('a1', 'Something', 'user1');
    expect(result.citations).toHaveLength(0);
  });
});
