import { Injectable } from '@nestjs/common';

export interface CompletionRequest {
  system: string;
  user: string;
  maxTokens: number;
  temperature: number;
}

export interface CompletionResult {
  text: string;
}

/**
 * Thin wrapper over the managed LLM API used for summarization, translation,
 * and Chat with News (docs/03-Tech-Stack.md Section 16, docs/08-AI-Features.md).
 * Kept as a single narrow interface so the underlying provider can be
 * swapped without touching ChatService or the summarization workers.
 */
@Injectable()
export class LlmClient {
  async complete(request: CompletionRequest): Promise<CompletionResult> {
    throw new Error('Wire up the managed LLM API client here (see docs/08-AI-Features.md).');
  }
}
