import { Injectable } from '@nestjs/common';

export interface Embeddable {
  id: string;
  bodyText: string;
  publisherName: string;
}

/**
 * Wraps the managed embedding API used for `article_ai_metadata.embedding`
 * (pgvector, docs/05-Database-Schema.md) and for Chat with News source
 * ranking (docs/08-AI-Features.md Section 3).
 */
@Injectable()
export class EmbeddingService {
  async embed(text: string): Promise<number[]> {
    throw new Error('Wire up the managed embedding API client here.');
  }

  async rankBySimilarity<T extends Embeddable>(query: string, candidates: T[]): Promise<T[]> {
    // Production: embed(query), embed each candidate (or read precomputed
    // embeddings from article_ai_metadata), rank by cosine similarity.
    // Falls back to input order here so the module is at least runnable
    // end-to-end before the embedding client is wired up.
    return candidates;
  }
}
