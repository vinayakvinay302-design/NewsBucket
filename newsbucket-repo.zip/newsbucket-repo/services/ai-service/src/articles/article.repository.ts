// ai-service consumes the same ArticleRepository contract that news-service
// implements, since Chat with News needs to read article + cluster data.
// In the deployed system this is a call to news-service's API (service
// boundary, docs/04-Backend-Architecture.md Section 1: "services never call
// another service's database directly"), not a shared Node import -- this
// re-export exists purely so the code in this monorepo type-checks and the
// real contract is visible in one place during local development.
export { ArticleRepository, ArticleEntity } from '../../../news-service/src/articles/article.repository';
