# NewsBucket AWS infrastructure -- generated from docs/15-Deployment.md

# infra/modules/eks-cluster/main.tf
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 20.0"

  cluster_name    = "newsbucket-${var.environment}"
  cluster_version = "1.30"

  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnet_ids

  eks_managed_node_groups = {
    general = {
      instance_types = ["m6i.xlarge"]
      min_size       = var.environment == "production" ? 6 : 2
      max_size       = var.environment == "production" ? 60 : 6
      desired_size   = var.environment == "production" ? 8 : 2
      labels         = { workload = "general" }
    }
    ai_workers = {
      instance_types = ["c6i.2xlarge"]
      min_size       = var.environment == "production" ? 3 : 1
      max_size       = var.environment == "production" ? 30 : 3
      desired_size   = var.environment == "production" ? 4 : 1
      labels         = { workload = "ai-processing" }
      taints = [{
        key    = "workload"
        value  = "ai-processing"
        effect = "NO_SCHEDULE"
      }]
    }
  }

  cluster_endpoint_private_access = true
  cluster_endpoint_public_access  = var.environment != "production"

  tags = {
    Environment = var.environment
    Project     = "newsbucket"
    ManagedBy   = "terraform"
  }
}

module "aurora_postgresql" {
  source  = "terraform-aws-modules/rds-aurora/aws"
  version = "~> 9.0"

  name              = "newsbucket-${var.environment}"
  engine            = "aurora-postgresql"
  engine_version    = "16.3"
  instance_class    = var.environment == "production" ? "db.r6g.2xlarge" : "db.r6g.large"
  instances = var.environment == "production" ? {
    writer = {}
    reader1 = {}
    reader2 = {}
  } : { writer = {} }

  storage_encrypted   = true
  kms_key_id          = module.kms.key_arn
  backup_retention_period = 35
  preferred_backup_window = "17:00-18:00" # UTC, low-traffic window for IST users
  deletion_protection = var.environment == "production"

  vpc_id               = module.vpc.vpc_id
  db_subnet_group_name = module.vpc.database_subnet_group_name

  tags = { Environment = var.environment, Project = "newsbucket" }
}
