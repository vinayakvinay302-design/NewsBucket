# NewsBucket -- one-shot GitHub upload script (Windows PowerShell)
#
# Copy-paste this whole thing into PowerShell from inside the
# newsbucket-repo\ folder, or run: .\upload_to_github.ps1
#
# What it does, in order:
#   1. Initializes git (if not already a repo) and makes the first commit.
#   2. If the GitHub CLI (gh) is installed and logged in, creates the
#      GitHub repo for you and pushes automatically -- fully hands-off.
#   3. If gh isn't available, tells you the two commands to run after
#      creating an empty repo on github.com (no code writing required).
#
# Safe to re-run: it detects an existing git repo/remote and skips steps
# that are already done instead of failing.

param(
    [string]$RepoName = "newsbucket",
    [string]$Visibility = "private"   # pass "public" for a public repo
)

Write-Host "== NewsBucket GitHub upload =="
Write-Host "Repo name : $RepoName"
Write-Host "Visibility: $Visibility"
Write-Host ""

# ---- Step 1: git init + commit ----
if (-not (Test-Path ".git")) {
    Write-Host "-> Initializing git repository..."
    git init -q
    git branch -M main
} else {
    Write-Host "-> Git repository already initialized, skipping init."
}

git add -A

$staged = git diff --cached --name-only
if (-not $staged) {
    Write-Host "-> Nothing new to commit (working tree already matches last commit)."
} else {
    Write-Host "-> Committing..."
    git commit -q -m "Initial commit: NewsBucket monorepo (docs, backend services, apps, infra)"
}

# ---- Step 2: push to GitHub ----
$hasOrigin = git remote get-url origin 2>$null
if ($LASTEXITCODE -eq 0 -and $hasOrigin) {
    Write-Host "-> Remote 'origin' already set, pushing..."
    git push -u origin main
    Write-Host "Done. Pushed to $hasOrigin"
    exit 0
}

$ghInstalled = Get-Command gh -ErrorAction SilentlyContinue
if ($ghInstalled) {
    gh auth status 2>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "-> GitHub CLI detected and authenticated. Creating repo and pushing..."
        gh repo create $RepoName --$Visibility --source=. --remote=origin --push
        Write-Host "Done. Run 'gh repo view --web' to open it in the browser."
        exit 0
    } else {
        Write-Host "-> GitHub CLI is installed but not logged in."
        Write-Host "   Run: gh auth login"
        Write-Host "   Then re-run this script."
        exit 1
    }
}

# ---- Fallback: no gh CLI available ----
Write-Host ""
Write-Host "-> GitHub CLI (gh) not found, so this last step needs one manual click:"
Write-Host ""
Write-Host "   1. Go to https://github.com/new"
Write-Host "   2. Repository name: $RepoName"
Write-Host "   3. Do NOT initialize with a README, .gitignore, or license (this repo already has them)"
Write-Host "   4. Click 'Create repository'"
Write-Host "   5. Then paste these two lines into PowerShell:"
Write-Host ""
Write-Host "      git remote add origin https://github.com/<your-username>/$RepoName.git"
Write-Host "      git push -u origin main"
Write-Host ""
Write-Host "(Tip: installing the GitHub CLI -- https://cli.github.com -- lets this"
Write-Host "script do step 5 for you automatically next time.)"
