#!/usr/bin/env bash
# NewsBucket — one-shot GitHub upload script
#
# Copy-paste this whole thing into your terminal from inside the
# newsbucket-repo/ folder, or run: bash upload_to_github.sh
#
# What it does, in order:
#   1. Initializes git (if not already a repo) and makes the first commit.
#   2. If the GitHub CLI (`gh`) is installed and logged in, creates the
#      GitHub repo for you and pushes automatically -- fully hands-off.
#   3. If `gh` isn't available, tells you the two commands to run after
#      creating an empty repo on github.com (no code writing required).
#
# Safe to re-run: it detects an existing git repo/remote and skips steps
# that are already done instead of failing.

set -euo pipefail

REPO_NAME="${1:-newsbucket}"
VISIBILITY="${2:-private}"   # pass "public" as the 2nd argument if you want a public repo

echo "== NewsBucket GitHub upload =="
echo "Repo name : $REPO_NAME"
echo "Visibility: $VISIBILITY"
echo

# ---- Step 1: git init + commit -------------------------------------------
if [ ! -d ".git" ]; then
  echo "-> Initializing git repository..."
  git init -q
  git branch -M main
else
  echo "-> Git repository already initialized, skipping init."
fi

git add -A

if git diff --cached --quiet; then
  echo "-> Nothing new to commit (working tree already matches last commit)."
else
  echo "-> Committing..."
  git commit -q -m "Initial commit: NewsBucket monorepo (docs, backend services, apps, infra)"
fi

# ---- Step 2: push to GitHub ------------------------------------------------
if git remote get-url origin >/dev/null 2>&1; then
  echo "-> Remote 'origin' already set, pushing..."
  git push -u origin main
  echo "Done. Pushed to $(git remote get-url origin)"
  exit 0
fi

if command -v gh >/dev/null 2>&1; then
  if gh auth status >/dev/null 2>&1; then
    echo "-> GitHub CLI detected and authenticated. Creating repo and pushing..."
    gh repo create "$REPO_NAME" --"$VISIBILITY" --source=. --remote=origin --push
    echo "Done. Your repo is live -- run 'gh repo view --web' to open it in the browser."
    exit 0
  else
    echo "-> GitHub CLI is installed but not logged in."
    echo "   Run: gh auth login"
    echo "   Then re-run this script."
    exit 1
  fi
fi

# ---- Fallback: no gh CLI available -----------------------------------------
cat << EOF

-> GitHub CLI ('gh') not found, so this last step needs one manual click:

   1. Go to https://github.com/new
   2. Repository name: $REPO_NAME
   3. Do NOT initialize with a README, .gitignore, or license (this repo already has them)
   4. Click "Create repository"
   5. Then paste these two lines into your terminal:

      git remote add origin https://github.com/<your-username>/$REPO_NAME.git
      git push -u origin main

That's it -- your code is already committed locally, this just points it
at GitHub.

(Tip: installing the GitHub CLI -- https://cli.github.com -- lets this
script do step 5 for you automatically next time.)
EOF
